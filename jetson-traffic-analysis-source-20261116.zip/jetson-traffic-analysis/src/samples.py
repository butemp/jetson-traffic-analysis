"""正负样本回流：复核动作 → 复制截图入库；导出 交通视觉智能体 SFT JSONL。"""
import json
import logging
import shutil
import tarfile
import time
from pathlib import Path
from typing import Optional

import config
import db
from prompts import SYSTEM_PROMPT, USER_TEXT

log = logging.getLogger("traffic.samples")

PROMPT = SYSTEM_PROMPT + "\n\n" + USER_TEXT
NEG_GT = {"has_event": False, "event_type": "Normal", "description": "正常路况，无交通事件", "confidence": "高"}


def _gt_json_for(ev: dict, action: str) -> str:
    if action == "confirmed":
        return json.dumps(
            {"has_event": True, "event_type": ev["event_type"],
             "description": ev["description"], "confidence": ev.get("confidence", "高")},
            ensure_ascii=False,
        )
    return json.dumps(NEG_GT, ensure_ascii=False)


def create_sample_from_event(ev: dict, action: str, reviewer: str) -> Optional[int]:
    """confirmed → 正样本；rejected → 负样本。escalated 不产样本。"""
    if action not in ("confirmed", "rejected") or not ev.get("snapshot_path"):
        return None
    label = "pos" if action == "confirmed" else "neg"
    sid = db.insert_sample(
        ev["id"], ev["snapshot_path"], label, ev["event_type"],
        PROMPT, _gt_json_for(ev, action), ev.get("task_id"), reviewer,
    )
    src = config.SNAPSHOT_DIR / ev["snapshot_path"]
    if src.exists():
        shutil.copy(src, config.SAMPLES_IMG_DIR / f"{sid}.jpg")
        db.set_sample_image(sid, f"{sid}.jpg")
    db.set_event_sample(ev["id"], sid)
    log.info("样本 #%d (%s) <- 事件 %s", sid, label, ev["id"])
    return sid


def export_dataset(actor: str, ip: str = None) -> Optional[str]:
    """打包未导出样本为 交通视觉智能体 SFT JSONL + tar.gz，返回文件名。"""
    rows = db.list_samples(exported=False)
    if not rows:
        return None
    ts = time.strftime("%Y%m%d_%H%M%S")
    name = f"dataset_{ts}"
    out_dir = config.EXPORTS_DIR / name
    img_dir = out_dir / "images"
    img_dir.mkdir(parents=True, exist_ok=True)
    jsonl = out_dir / "dataset.jsonl"
    ids = []
    with open(jsonl, "w", encoding="utf-8") as f:
        for s in rows:
            src = config.SAMPLES_IMG_DIR / s["image_path"]
            if not src.exists():
                continue
            fname = f"{s['id']}.jpg"
            shutil.copy(src, img_dir / fname)
            entry = {
                "id": str(s["id"]),
                "image": f"images/{fname}",
                "conversations": [
                    {"from": "user", "value": "<image>\n" + s["prompt"]},
                    {"from": "assistant", "value": s["gt_json"]},
                ],
            }
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
            ids.append(s["id"])
    # 元信息
    (out_dir / "README.txt").write_text(
        f"交通视觉智能体 交通事件 SFT 数据集\n生成时间: {ts}\n样本数: {len(ids)}\n"
        "格式: sharegpt，image 字段相对 images/；可直接用于 交通视觉智能体 的 LoRA/SFT。\n",
        encoding="utf-8",
    )
    tarpath = config.EXPORTS_DIR / f"{name}.tar.gz"
    with tarfile.open(tarpath, "w:gz") as t:
        t.add(out_dir, arcname=name)
    shutil.rmtree(out_dir)
    # 标记已导出（用导出时间戳）
    with db._write_lock, db._connect() as conn:
        conn.execute("UPDATE samples SET exported=1, exported_at=? WHERE id IN (%s)"
                     % ",".join("?" * len(ids)), [ts] + ids)
    import audit
    audit.log_action(actor, "samples.export", "samples", None, {"n": len(ids), "file": tarpath.name}, ip)
    log.info("导出数据集 %s（%d 样本）", tarpath.name, len(ids))
    return tarpath.name


def list_exports() -> list:
    if not config.EXPORTS_DIR.exists():
        return []
    files = sorted(config.EXPORTS_DIR.glob("dataset_*.tar.gz"), reverse=True)
    return [{"name": f.name, "size": f.stat().st_size, "mtime": f.stat().st_mtime} for f in files]


def export_path(filename: str) -> Optional[Path]:
    p = (config.EXPORTS_DIR / filename).resolve()
    # 防路径穿越
    if str(p).startswith(str(config.EXPORTS_DIR.resolve())) and p.name.startswith("dataset_") and p.name.endswith(".tar.gz"):
        return p if p.exists() else None
    return None
