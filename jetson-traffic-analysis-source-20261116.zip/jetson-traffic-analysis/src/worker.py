import logging
import threading
from concurrent.futures import ThreadPoolExecutor

import config
import db
import executor
import vlm

log = logging.getLogger("traffic.worker")
_pool = None
_lock = threading.RLock()
_futures = {}


class QueueFull(RuntimeError):
    pass


def start_pool():
    global _pool
    with _lock:
        if _pool is None:
            if config.MAX_CONCURRENT_ANALYSIS < 1 or config.MAX_PENDING_ANALYSIS < 0:
                raise ValueError("分析并发须大于0，等待队列容量不能为负数")
            executor.STOP_REQUESTED = False
            _pool = ThreadPoolExecutor(max_workers=config.MAX_CONCURRENT_ANALYSIS, thread_name_prefix="analyze")


def _finished(run_id, future):
    with _lock:
        if _futures.get(run_id) is future:
            _futures.pop(run_id)
    executor.STOP_ON_EVENT.discard(run_id)


def submit_analysis(run_id, stop_on_event=False):
    with _lock:
        if run_id in _futures:
            raise ValueError("任务已经提交")
        if len(_futures) >= config.MAX_CONCURRENT_ANALYSIS + config.MAX_PENDING_ANALYSIS:
            raise QueueFull("分析任务已满，请停止任务或稍后重试")
        start_pool()
        if stop_on_event:
            executor.STOP_ON_EVENT.add(run_id)
        future = _pool.submit(executor.run, run_id)
        _futures[run_id] = future
        future.add_done_callback(lambda done: _finished(run_id, done))


def cancel(run_id):
    with _lock:
        future = _futures.get(run_id)
        if future is not None:
            future.cancel()
    vlm.cancel(executor.vlm_owner(run_id))


def is_running(run_id):
    with _lock:
        future = _futures.get(run_id)
        return future is not None and not future.done()


def active_count():
    with _lock:
        return sum(not future.done() for future in _futures.values())


def shutdown():
    global _pool
    with _lock:
        executor.STOP_REQUESTED = True
        run_ids = list(_futures)
        for run_id in run_ids:
            db.update_status(run_id, config.STATUS_FAILED, "服务停止中断")
        for run_id in run_ids:
            cancel(run_id)
        if _pool is not None:
            _pool.shutdown(wait=False, cancel_futures=True)
            _pool = None
