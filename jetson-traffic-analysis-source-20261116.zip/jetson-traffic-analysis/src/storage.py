"""本地存储：目录占用统计 + 配额检查。"""
import shutil
from pathlib import Path

import config
import db


def register_upload(path):
    path = Path(path).resolve()
    if path.parent != config.UPLOAD_DIR.resolve():
        raise ValueError("上传文件必须位于受管理目录")
    with db._write_lock, db._connect() as conn:
        conn.execute("INSERT INTO owned_uploads(path, created_at) VALUES(?, ?)", (str(path), db._now()))


def release_upload(path):
    candidate = Path(path)
    if candidate.is_symlink() or candidate.resolve().parent != config.UPLOAD_DIR.resolve():
        return False
    candidate = candidate.resolve()
    with db._write_lock, db._connect() as conn:
        owned = conn.execute("SELECT 1 FROM owned_uploads WHERE path=?", (str(candidate),)).fetchone()
        referenced = conn.execute(
            "SELECT 1 FROM analysis_tasks WHERE file_path=? UNION ALL SELECT 1 FROM data_sources WHERE uri=? LIMIT 1",
            (str(candidate), str(candidate)),
        ).fetchone()
        if not owned or referenced:
            return False
        candidate.unlink(missing_ok=True)
        conn.execute("DELETE FROM owned_uploads WHERE path=?", (str(candidate),))
        return True


def delete_task_assets(task):
    db.delete_task(task["id"])
    for path in config.SNAPSHOT_DIR.iterdir():
        if path.name.startswith(task["id"] + "_") and path.is_file() and not path.is_symlink():
            path.unlink()
    if task.get("file_path"):
        release_upload(task["file_path"])


def _dir_size(path: Path) -> int:
    if not path.exists():
        return 0
    total = 0
    for root, _, files in _walk(path):
        for f in files:
            try:
                total += (Path(root) / f).stat().st_size
            except OSError:
                pass
    return total


def _walk(path: Path):
    # os.walk 但忽略权限错误
    import os
    for root, dirs, files in os.walk(path):
        yield root, dirs, files


def disk_stats() -> dict:
    usage = shutil.disk_usage(config.DATA_DIR)
    return {
        "base": str(config.DATA_DIR),
        "total_gb": round(usage.total / 1073741824, 2),
        "used_gb": round(usage.used / 1073741824, 2),
        "free_gb": round(usage.free / 1073741824, 2),
        "free_pct": round(usage.free / usage.total * 100, 1),
        "dirs": {
            "uploads_mb": round(_dir_size(config.UPLOAD_DIR) / 1048576, 2),
            "snapshots_mb": round(_dir_size(config.SNAPSHOT_DIR) / 1048576, 2),
            "samples_mb": round(_dir_size(config.SAMPLES_DIR) / 1048576, 2),
        },
        "retention_days": config.RETENTION_DAYS,
        "min_free_gb": config.MIN_FREE_GB,
    }


def has_free_space() -> bool:
    usage = shutil.disk_usage(config.DATA_DIR)
    return (usage.free / 1073741824) >= config.MIN_FREE_GB
