"""Jetson GPU 指标：Orin 为统一内存，显存即系统内存占用。"""
import time

_GPU_LOAD = "/sys/devices/platform/17000000.gpu/load"
_cache = {"ts": 0.0, "data": None}


def _gpu_util():
    with open(_GPU_LOAD) as f:
        return round(int(f.read().strip()) / 10.0, 1)


def _mem():
    info = {}
    with open("/proc/meminfo") as f:
        for line in f:
            key, rest = line.split(":", 1)
            info[key] = int(rest.split()[0])
    total = info["MemTotal"] // 1024
    used = (info["MemTotal"] - info.get("MemAvailable", 0)) // 1024
    return used, total


def read():
    now = time.time()
    if _cache["data"] and now - _cache["ts"] < 1.0:
        return _cache["data"]
    util = used = total = None
    try:
        util = _gpu_util()
    except Exception:
        pass
    try:
        used, total = _mem()
    except Exception:
        pass
    data = {"util_pct": util, "mem_used_mb": used, "mem_total_mb": total}
    _cache["ts"], _cache["data"] = now, data
    return data
