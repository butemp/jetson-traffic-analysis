"""告警生命周期：事件达标→建 alert + 通知；ack/resolve 处置（落审计）。"""
import logging
from typing import Optional

import audit
import config
import db
import notifier
from escalation import LEVEL_LABEL

log = logging.getLogger("traffic.alerts")


def _level_n(level):
    return {"L1": 1, "L2": 2, "L3": 3}.get(level, 0)


def should_alert(severity: Optional[str], gallery_match: Optional[str]) -> bool:
    if gallery_match:
        return True
    return bool(severity) and _level_n(severity) >= config.ALERT_MIN_LEVEL_N


def create_from_event(event_id: int, source_id: Optional[str], det_task_id: Optional[str],
                      severity: str, result: dict, snapshot: Optional[str]) -> int:
    title = f"【{LEVEL_LABEL.get(severity, '告警')}】疑似{result.get('event_type', '异常')}"
    msg = result.get("description", "")
    aid = db.insert_alert(source_id, event_id, det_task_id, severity, title, msg, snapshot)
    # 复用现有通知通道（站内 + Webhook）
    try:
        notifier.notify_event(
            {"id": event_id, "source_id": source_id, "severity": severity,
             "event_type": result.get("event_type"), "description": msg,
             "snapshot_path": snapshot},
            severity, title, msg,
        )
    except Exception as e:
        log.warning("告警通知发送失败 alert=%s: %s", aid, e)
    # External dispatch requires explicit human review through /api/emergency/push.
    log.info("告警 #%s [%s] %s", aid, severity, title)
    return aid


def push_emergency(alert_id: int) -> dict:
    if not config.EMERGENCY_API_URL:
        return {"ok": False, "message": "EMERGENCY_API_URL 未配置"}
    al = db.get_alert(alert_id)
    if not al:
        return {"ok": False, "message": "告警不存在"}
    ev = db.get_event(al["event_id"]) if al.get("event_id") else {}
    payload = {
        "source": "VisionGuard AI",
        "alert_id": alert_id,
        "title": al.get("title"),
        "level": al.get("severity"),
        "description": al.get("message"),
        "event_type": ev.get("event_type") if ev else None,
        "snapshot_path": al.get("snapshot_path"),
    }
    try:
        import httpx
        headers = {"Authorization": f"Bearer {config.EMERGENCY_API_KEY}"} if config.EMERGENCY_API_KEY else {}
        r = httpx.post(config.EMERGENCY_API_URL, json=payload, headers=headers, timeout=10)
        r.raise_for_status()
        return {"ok": True, "status_code": r.status_code}
    except Exception as e:
        log.warning("应急推送失败 alert=%s: %s", alert_id, e)
        return {"ok": False, "message": str(e)}


def ack(alert_id: int, actor: str, comment: str = "", ip: str = None) -> bool:
    ok = db.set_alert_status(alert_id, "acked", actor, comment)
    if ok:
        audit.log_action(actor, "alert.ack", "alert", alert_id, {"comment": comment}, ip)
    return ok


def resolve(alert_id: int, actor: str, comment: str = "", ip: str = None) -> bool:
    ok = db.set_alert_status(alert_id, "resolved", actor, comment)
    if ok:
        audit.log_action(actor, "alert.resolve", "alert", alert_id, {"comment": comment}, ip)
    return ok
