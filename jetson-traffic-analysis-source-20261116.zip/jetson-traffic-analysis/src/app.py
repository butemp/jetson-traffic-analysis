"""城市交通多模态智能体指挥中枢 — FastAPI 入口（Phase 3）。

鉴权：除 login/static/config 外，/api/* 需登录（单管理员 cookie session）；写操作落审计。
Phase 3：数据源 / 检测任务(零样本) / 底库 / 告警生命周期 / 大屏。
"""
import json
import logging
import os
import threading
import uuid

from fastapi import FastAPI, File, HTTPException, Query, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from starlette.concurrency import run_in_threadpool
from starlette.background import BackgroundTask

import alerts
import audit
import auth
import benchmark
import config
import db
import emergency_plan
import executor
import gpu_stats
import presets
import reports
import notifier
import review as review_mod
import samples
import scheduler
import sources
import report_fixes
import traffic_reasoning
from source_public import source_view, task_view, public_uri, PresentationMiddleware, display_archive
import storage
import stress_test
import stream_api
import vlm
import worker
import yolo_detector
from escalation import LEVEL_COLOR, LEVEL_LABEL
from prompts import EVENT_COLOR, EVENT_TYPES
import video
from video import normalize_stream_url

logging.basicConfig(
    level=os.getenv("TRAFFIC_LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s %(levelname)s %(name)s | %(message)s",
)
log = logging.getLogger("traffic.app")

app = FastAPI(title="城市交通多模态智能体指挥中枢", version="3.0", docs_url=None, redoc_url=None, openapi_url=None)
app.add_middleware(PresentationMiddleware)
app.include_router(stream_api.router)
_stream_viewers = 0
_stream_lock = threading.Lock()


# ---------------- 中间件：鉴权 + actor 注入 ----------------
_PUBLIC_PREFIX = ("/static/",)
_PUBLIC_PATH = {"/", "/api/config", "/api/auth/login", "/favicon.ico"}


@app.middleware("http")
async def auth_gate(request: Request, call_next):
    p = request.url.path
    sess = auth.get_session(request)
    request.state.actor = sess.get("user") if sess else None
    request.state.role = sess.get("role") if sess else None
    public = p in _PUBLIC_PATH or any(p.startswith(x) for x in _PUBLIC_PREFIX)
    if request.method in ("POST", "PUT", "PATCH", "DELETE"):
        origin = request.headers.get("origin")
        if origin and origin.rstrip("/") != str(request.base_url).rstrip("/"):
            return JSONResponse({"detail": "拒绝跨站写入请求"}, status_code=403)
    if not public:
        if not sess:
            return JSONResponse({"detail": "未登录或会话过期"}, status_code=401)
        if p.startswith("/api/users") and not auth.can_admin(request.state.role):
            return JSONResponse({"detail": "需要管理员权限"}, status_code=403)
        if request.method in ("POST", "PUT", "PATCH", "DELETE") and p != "/api/auth/logout":
            if not auth.can_write(request.state.role):
                return JSONResponse({"detail": "只读账号无写权限"}, status_code=403)
    response = await call_next(request)
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "same-origin"
    return response


@app.on_event("startup")
def _startup() -> None:
    db.init_db()
    report_fixes.init()
    traffic_reasoning.init()
    stale = db.reset_stale_tasks()
    if stale:
        log.warning("启动时发现 %d 个未完成任务，已标记失败", stale)
    auth.seed_default_admin()
    db.seed_builtin_task()
    db.seed_stream_task()
    n = db.backfill_severity() + db.backfill_det_task()
    if n:
        log.info("迁移回填 %d 条", n)
    worker.start_pool()
    notifier.start()
    scheduler.start()
    log.info(
        "启动完成: VLM_ENABLED=%s backend=%s base_url=%s model=%s 端口=%s",
        config.VLM_ENABLED, config.VLM_BACKEND, config.VLM_BASE_URL,
        config.VLM_MODEL, config.WEB_PORT,
    )
    if config.AUTH_DISABLED:
        log.warning("AUTH_DISABLED=1：免登录模式，所有访问者均以管理员 %s 身份操作", config.ADMIN_USER)


@app.on_event("shutdown")
def _shutdown() -> None:
    traffic_reasoning.shutdown()
    stream_api.shutdown()
    worker.shutdown()
    vlm.shutdown()
    notifier.shutdown()
    scheduler.shutdown()
    video.shutdown_stream_readers()


@app.get("/api/emergency/assessment")
def emergency_assessment(alert_id: int = None, event_id: int = None):
    try:
        return report_fixes.assessment(emergency_plan.build_context(alert_id=alert_id, event_id=event_id))
    except ValueError as e:
        raise HTTPException(409, str(e))


@app.post("/api/emergency/approve")
def emergency_approve(payload: dict, request: Request):
    if payload.get("evidence_reviewed") is not True:
        raise HTTPException(422, "请先查阅影像证据")
    try:
        report_fixes.approve(int(payload["event_id"]), payload.get("severity"), request.state.actor,
                             str(payload.get("comment", "")), payload.get("fingerprint"))
    except (ValueError, KeyError, TypeError) as e:
        raise HTTPException(409, str(e))
    audit.log_action(request.state.actor, "emergency.approve", "event", payload["event_id"],
                     {"severity":payload["severity"], "comment":payload.get("comment","")}, auth.client_ip(request))
    return {"ok":True}


# ---------------- 认证 ----------------
@app.post("/api/auth/login")
async def login(payload: dict, request: Request, response: Response):
    user = str(payload.get("user", "")); plain = str(payload.get("pass", ""))
    ip = auth.client_ip(request)
    token = auth.login(user, plain)
    if not token:
        audit.log_action(None, "auth.login_failed", None, None, {"user": user}, ip)
        raise HTTPException(401, "用户名或密码错误")
    response.set_cookie(auth.COOKIE_NAME, token, httponly=True, max_age=config.SESSION_TTL_SEC,
                        samesite="strict", secure=request.url.scheme == "https")
    audit.log_action(user, "auth.login", None, None, None, ip)
    role = auth.get_role(request) or (db.get_user_by_name(user) or {}).get("role")
    return {"user": user, "role": role}


@app.post("/api/auth/logout")
async def logout(request: Request, response: Response):
    auth.logout(request.cookies.get(auth.COOKIE_NAME))
    response.delete_cookie(auth.COOKIE_NAME)
    return {"ok": True}


@app.get("/api/auth/me")
async def me(request: Request):
    actor = request.state.actor
    return {"user": actor, "role": request.state.role, "authed": bool(actor),
            "auth_disabled": config.AUTH_DISABLED}


# ---------------- 数据源 ----------------
@app.get("/api/sources")
def list_sources():
    return {"items": [source_view(s) for s in db.list_sources()]}


@app.post("/api/sources")
async def create_source(payload: dict, request: Request):
    sid = uuid.uuid4().hex[:12]
    uri = normalize_stream_url(payload.get("uri") or "")
    db.create_source(sid, payload.get("name"), payload.get("kind") or _infer_source_kind(uri), uri,
                     payload.get("lat"), payload.get("lng"), payload.get("address"))
    audit.log_action(request.state.actor, "source.create", "source", sid, {"name": payload.get("name")}, auth.client_ip(request))
    return {"id": sid}


@app.api_route("/api/sources/{sid}/test", methods=["GET", "POST"])
def test_source(sid: str):
    return sources.test_source(sid)


@app.patch("/api/sources/{sid}")
async def update_source(sid: str, payload: dict, request: Request):
    previous = db.get_source(sid)
    if previous is None:
        raise HTTPException(404, "数据源不存在")
    # Editing metadata must not replace the stored credential with its public representation.
    if payload.get("uri") == public_uri(previous["uri"]):
        payload = {k: v for k, v in payload.items() if k != "uri"}
    fields = {}
    for k in ("name", "uri", "lat", "lng", "address", "kind"):
        if k in payload:
            fields[k] = normalize_stream_url(payload[k]) if k == "uri" else payload[k]
    if "uri" in fields and "kind" not in fields:
        fields["kind"] = _infer_source_kind(fields["uri"])
    if not db.update_source(sid, **fields):
        raise HTTPException(404, "数据源不存在或无更新")
    audit.log_action(request.state.actor, "source.update", "source", sid, list(fields.keys()), auth.client_ip(request))
    return {"ok": True}


@app.get("/api/sources/{sid}/frame")
def source_frame(sid: str):
    import cv2
    src = db.get_source(sid)
    if not src:
        raise HTTPException(404, "数据源不存在")
    if config.STREAM_SHARED_READER_ENABLED and video.is_stream_path(src["uri"]):
        reader = video.acquire_stream_reader(src["uri"])
        try:
            _, jpeg = reader.read_jpeg(timeout=5.0)
            if not jpeg:
                raise HTTPException(502, "读不到视频帧")
            return Response(content=jpeg, media_type="image/jpeg")
        finally:
            reader.release()
    cap = video.open_capture(src["uri"])
    try:
        if not cap.isOpened():
            raise HTTPException(502, "无法打开数据源")
        ok, frame = False, None
        for _ in range(5):
            ok, frame = cap.read()
            if ok:
                break
        if not ok:
            raise HTTPException(502, "读不到视频帧")
        frame = vlm.resize_by_max_edge(frame, config.STREAM_PREVIEW_MAX_EDGE)
        ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 85])
        if not ok:
            raise HTTPException(500, "帧编码失败")
        return Response(content=buf.tobytes(), media_type="image/jpeg")
    finally:
        cap.release()


@app.get("/api/sources/{sid}/stream")
def source_stream(sid: str):
    """MJPEG 实时预览：服务端解码后转 JPEG 流，浏览器 img 可直接显示。"""
    import time
    import cv2

    global _stream_viewers
    src = db.get_source(sid)
    if not src:
        raise HTTPException(404, "数据源不存在")
    with _stream_lock:
        if _stream_viewers >= config.STREAM_MAX_VIEWERS:
            raise HTTPException(429, "预览并发已达上限")
        _stream_viewers += 1

    def gen():
        global _stream_viewers
        delay = 1.0 / max(1.0, config.STREAM_PREVIEW_FPS)
        reader = None
        cap = None
        try:
            if config.STREAM_SHARED_READER_ENABLED and video.is_stream_path(src["uri"]):
                reader = video.acquire_stream_reader(src["uri"])
                last_id = None
                fail = 0
                while True:
                    frame_id, jpeg = reader.read_jpeg(after_id=last_id, timeout=5.0)
                    if not jpeg:
                        fail += 1
                        if fail > 6:
                            break
                        continue
                    fail = 0
                    last_id = frame_id
                    yield b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + jpeg + b"\r\n"
                return

            cap = video.open_capture(src["uri"])
            if not cap.isOpened():
                return
            fail = 0
            while True:
                ok, frame = cap.read()
                if not ok:
                    fail += 1
                    if fail > 30:
                        break
                    time.sleep(0.05)
                    continue
                fail = 0
                frame = vlm.resize_by_max_edge(frame, config.STREAM_PREVIEW_MAX_EDGE)
                ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 75])
                if not ok:
                    continue
                yield b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + buf.tobytes() + b"\r\n"
                time.sleep(delay)
        finally:
            if reader is not None:
                reader.release()
            if cap is not None:
                cap.release()
            with _stream_lock:
                _stream_viewers = max(0, _stream_viewers - 1)

    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")


@app.delete("/api/sources/{sid}")
def delete_source(sid: str, request: Request):
    source = db.get_source(sid)
    if not source:
        raise HTTPException(404, "数据源不存在")
    with db._connect() as conn:
        active = conn.execute(
            "SELECT id FROM analysis_tasks WHERE source_id=? AND status IN ('pending','processing')",
            (sid,),
        ).fetchone()
    if active:
        raise HTTPException(409, "请先停止该源的活动任务")
    db.delete_source(sid)
    storage.release_upload(source["uri"])
    audit.log_action(request.state.actor, "source.delete", "source", sid, None, auth.client_ip(request))
    return {"ok": True}


# ---------------- 检测任务（零样本）----------------
@app.get("/api/det-tasks")
def list_det_tasks():
    return {"items": db.list_task_det()}


@app.post("/api/det-tasks")
async def create_det_task(payload: dict, request: Request):
    tid = uuid.uuid4().hex[:12]
    db.create_task_det(
        tid, payload.get("name", "未命名任务"), "zeroshot", payload.get("prompt", ""),
        json.dumps(payload.get("target_objects", []), ensure_ascii=False),
        1 if payload.get("require_review", True) else 0,
        payload.get("min_confidence", "中"),
        json.dumps(payload.get("severity_map", {}), ensure_ascii=False),
        payload.get("interval_sec"),
        json.dumps(payload.get("gallery_ids", []), ensure_ascii=False),
        roi_json=json.dumps(payload.get("roi_json"), ensure_ascii=False) if payload.get("roi_json") else None,
    )
    audit.log_action(request.state.actor, "det_task.create", "det_task", tid, {"name": payload.get("name")}, auth.client_ip(request))
    return {"id": tid}


@app.patch("/api/det-tasks/{tid}")
async def update_det_task(tid: str, payload: dict, request: Request):
    fields = {}
    for k in ("name", "prompt", "require_review", "min_confidence", "interval_sec", "status"):
        if k in payload:
            fields[k] = 1 if (k == "require_review" and isinstance(payload[k], bool)) else payload[k]
    for k in ("target_objects", "severity_map", "gallery_ids", "roi_json"):
        if k in payload:
            fields[k] = json.dumps(payload[k], ensure_ascii=False)
    db.update_task_det(tid, **fields)
    audit.log_action(request.state.actor, "det_task.update", "det_task", tid, list(fields.keys()), auth.client_ip(request))
    return {"ok": True}


@app.delete("/api/det-tasks/{tid}")
def delete_det_task(tid: str, request: Request):
    if tid in (db.BUILTIN_TASK_ID, db.STREAM_TASK_ID):
        raise HTTPException(400, "内置任务不可删除")
    db.delete_task_det(tid)
    audit.log_action(request.state.actor, "det_task.delete", "det_task", tid, None, auth.client_ip(request))
    return {"ok": True}


# ---------------- 运行（analysis_tasks）----------------
@app.post("/api/runs")
async def create_run(payload: dict, request: Request):
    sid = payload.get("source_id")
    tid = payload.get("det_task_id") or db.BUILTIN_TASK_ID
    if not isinstance(tid, str):
        tid = db.BUILTIN_TASK_ID
    src = db.get_source(sid) if sid else None
    uri = normalize_stream_url(payload.get("uri") or payload.get("camera_url") or "")
    if not src and uri:
        sid = uuid.uuid4().hex[:12]
        kind = payload.get("kind") or _infer_source_kind(uri)
        name = payload.get("name") or f"在线摄像头-{sid[:4]}"
        db.create_source(
            sid,
            name,
            kind,
            uri,
            payload.get("lat"),
            payload.get("lng"),
            payload.get("address"),
        )
        src = db.get_source(sid)
    if not src:
        raise HTTPException(404, "数据源不存在")
    if not db.get_task_det(tid):
        raise HTTPException(404, "检测任务不存在")
    if not storage.has_free_space():
        raise HTTPException(507, f"磁盘剩余不足 {config.MIN_FREE_GB}GB")
    run_id = uuid.uuid4().hex[:12]
    db.create_task(run_id, src["name"], src["uri"], 0.0, det_task_id=tid, source_id=sid)
    try:
        worker.submit_analysis(run_id)
    except worker.QueueFull as exc:
        db.update_status(run_id, config.STATUS_FAILED, str(exc))
        raise HTTPException(429, str(exc)) from exc
    audit.log_action(request.state.actor, "run.create", "task", run_id, {"source": sid, "det_task": tid}, auth.client_ip(request))
    return {"run_id": run_id}


def _infer_source_kind(uri: str) -> str:
    u = normalize_stream_url(uri).lower()
    if u.startswith("rtsp://"):
        return "rtsp"
    if u.startswith("rtmp://"):
        return "rtmp"
    if u.startswith(("http://", "https://")):
        return "http"
    return "file"


# Check metadata before accepting a potentially large multipart body.
@app.post("/api/upload/preflight")
def upload_preflight(payload: dict):
    name=payload.get("filename")
    size=payload.get("size")
    tid=payload.get("det_task_id")
    if not isinstance(name,str) or not name.strip() or len(name)>512:
        raise HTTPException(422,"文件名无效")
    if type(size) is not int or size<=0:raise HTTPException(422,"文件为空或大小无效")
    if size>config.MAX_UPLOAD_SIZE:raise HTTPException(413,f"文件超过 {config.MAX_UPLOAD_SIZE//1024//1024}MB")
    if os.path.splitext(name)[1].lower() not in config.ALLOWED_VIDEO_EXTS:
        raise HTTPException(415,"仅支持视频文件")
    if not isinstance(tid,str) or not db.get_task_det(tid):
        raise HTTPException(404,"检测任务不存在")
    if not storage.has_free_space():
        raise HTTPException(507,f"磁盘剩余不足 {config.MIN_FREE_GB}GB")
    duplicate=None
    with db._connect() as conn:
        rows=conn.execute("SELECT id,filename,file_path,source_id,created_at FROM analysis_tasks WHERE filename=? ORDER BY created_at DESC LIMIT 20",(name,)).fetchall()
    from pathlib import Path
    for row in rows:
        path=Path(row['file_path'] or '').resolve()
        if path.parent!=config.UPLOAD_DIR.resolve() or not path.is_file() or not row['source_id']:continue
        source=db.get_source(row['source_id'])
        if not source or source.get('uri')!=str(path):continue
        duplicate={"task_id":row['id'],"source_id":row['source_id'],"filename":row['filename'],
                   "size":path.stat().st_size,"created_at":row['created_at']}
        break
    return {"ok":True,"duplicate":duplicate}

# ---------------- 上传（建文件源 + 跑默认任务）----------------
@app.post("/api/upload")
async def upload(request: Request, file: UploadFile = File(...), det_task_id: str = "", allow_duplicate: bool = False):
    actor = request.state.actor
    ip = auth.client_ip(request)
    if not storage.has_free_space():
        raise HTTPException(507, f"磁盘剩余不足 {config.MIN_FREE_GB}GB")
    ext = os.path.splitext(file.filename or "")[1].lower()
    if ext not in config.ALLOWED_VIDEO_EXTS:
        raise HTTPException(415, f"仅支持视频文件: {sorted(config.ALLOWED_VIDEO_EXTS)}")

    if not db.get_task_det(det_task_id):
        raise HTTPException(404, "检测任务不存在")
    if not allow_duplicate:
        with db._connect() as conn:
            duplicate = conn.execute("SELECT id FROM analysis_tasks WHERE filename=? LIMIT 1", (file.filename,)).fetchone()
        if duplicate:
            await file.close()
            raise HTTPException(409, "已存在同名视频文件，请确认是否再次上传")
    task_id = uuid.uuid4().hex[:12]
    dest = config.UPLOAD_DIR / f"{task_id}{ext}"
    size = 0
    try:
        with open(dest, "wb") as out:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > config.MAX_UPLOAD_SIZE:
                    out.close(); os.remove(dest)
                    raise HTTPException(413, f"文件超过 {config.MAX_UPLOAD_SIZE // 1024 // 1024}MB")
                out.write(chunk)
    except HTTPException:
        raise
    except Exception as e:
        if dest.exists():
            os.remove(dest)
        raise HTTPException(500, f"保存失败: {e}")
    finally:
        await file.close()

    duration = 0.0
    try:
        from video import probe
        _, _, duration = await run_in_threadpool(probe, str(dest))
    except Exception:
        pass

    storage.register_upload(dest)
    src_id = uuid.uuid4().hex[:12]
    db.create_source(src_id, file.filename, "file", str(dest))
    db.update_source_status(src_id, True, db._now())
    db.create_task(task_id, file.filename, str(dest), duration, det_task_id=det_task_id, source_id=src_id)
    try:
        worker.submit_analysis(task_id)
    except worker.QueueFull as exc:
        db.update_status(task_id, config.STATUS_FAILED, str(exc))
        raise HTTPException(429, str(exc)) from exc
    audit.log_action(actor, "task.upload", "task", task_id, {"filename": file.filename, "mb": round(size / 1048576, 1)}, ip)
    log.info("上传 %s (%.1f MB) -> run=%s source=%s by %s", file.filename, size / 1048576, task_id, src_id, actor)
    return {"task_id": task_id, "source_id": src_id, "filename": file.filename, "size": size, "duration_sec": duration}



@app.get("/api/events/{event_id}/reasoning")
def get_event_reasoning(event_id: int):
    event=db.get_event(event_id)
    if not event:raise HTTPException(404,"事件不存在")
    if event['event_type'] not in traffic_reasoning.TRAFFIC_TYPES:
        raise HTTPException(422,"结构化研判目前用于六类交通事件")
    return traffic_reasoning.get(event_id) or traffic_reasoning.basic(event)

@app.post("/api/events/{event_id}/reasoning")
def request_event_reasoning(event_id: int):
    if not db.get_event(event_id):raise HTTPException(404,"事件不存在")
    try:return traffic_reasoning.enqueue(event_id)
    except ValueError as exc:raise HTTPException(409,str(exc))

# ---------------- 运行查询 ----------------
@app.get("/api/tasks")
def list_tasks():
    return [task_view(t) for t in db.list_tasks()]


@app.get("/api/tasks/{task_id}")
def get_task(task_id: str):
    task = db.get_task(task_id)
    if not task:
        raise HTTPException(404, "任务不存在")
    running = worker.is_running(task_id) or stream_api.is_running(task_id)
    return {"task": task_view(task), "events": db.list_events(task_id), "vlm_log": executor.get_vlm_log(task_id),
            "running": running}


@app.post("/api/tasks/{task_id}/cancel")
def cancel_task(task_id: str, request: Request):
    if not db.cancel_task(task_id):
        raise HTTPException(409, "任务不存在或已结束，无法取消")
    worker.cancel(task_id)
    if stream_api.is_running(task_id):
        stream_api.stop_stream(task_id)
    audit.log_action(request.state.actor, "task.cancel", "task", task_id, None, auth.client_ip(request))
    return {"task_id": task_id, "status": "cancelled"}


@app.delete("/api/tasks/{task_id}")
def delete_task(task_id: str, request: Request):
    task = db.get_task(task_id)
    if not task:
        raise HTTPException(404, "任务不存在")
    if worker.is_running(task_id) or stream_api.is_running(task_id) or task["status"] in (config.STATUS_PENDING, config.STATUS_PROCESSING):
        raise HTTPException(409, "请先取消任务并等待处理停止后再删除")
    if db.list_events(task_id):
        with db._write_lock, db._connect() as conn:
            conn.execute("UPDATE analysis_tasks SET archived=1 WHERE id=?", (task_id,))
        audit.log_action(request.state.actor, "task.archive", "task", task_id, {"evidence_retained": True}, auth.client_ip(request))
        return {"task_id": task_id, "archived": True, "evidence_retained": True}
    storage.delete_task_assets(task)
    executor.drop_vlm_log(task_id)
    audit.log_action(request.state.actor, "task.delete", "task", task_id, None, auth.client_ip(request))
    return {"task_id": task_id, "deleted": True}


# ---------------- 复核 ----------------
@app.get("/api/system/time-status")
def system_time_status():
    import json,time
    from pathlib import Path
    path=config.DATA_DIR/'time-sync-status.json'
    try:
        data=json.loads(path.read_text())
        if data.get('boot_id')!=Path('/proc/sys/kernel/random/boot_id').read_text().strip() or time.time()<float(data.get('last_verified_epoch') or 0)-2:
            data['quality']='unsynchronized'
        elif data.get('quality') in ('verified_mac','verified_ntp') and time.time()-float(data.get('last_verified_epoch') or 0)>180:
            data['quality']='holdover'
        return {key:data.get(key) for key in ('quality','source','last_verified_epoch','offset_before_sec')}
    except (OSError,ValueError):
        return {'quality':'not_configured','source':'','last_verified_epoch':None}


@app.post("/api/alerts/batch")
def batch_alerts(payload: dict, request: Request):
    action=payload.get('action')
    try:
        selected,events=report_fixes.validate_alert_batch(payload.get('ids'),payload.get('window_seconds'),action)
    except (ValueError,TypeError) as error:
        raise HTTPException(409,str(error))
    actor=request.state.actor;ip=auth.client_ip(request);comment=str(payload.get('comment') or '人工批量处理')
    completed=[];conflicts=[]
    if action in ('ack','resolve'):
        handler=alerts.ack if action=='ack' else alerts.resolve
        for alert in selected:
            (completed if handler(alert['id'],actor,comment,ip) else conflicts).append(alert['id'])
    else:
        for event in events:
            ids=[a['id'] for a in selected if a['event_id']==event['id']]
            try:
                result=review_mod.review_event(event['id'],action,actor,comment,ip)
                (completed if result is not None else conflicts).extend(ids)
            except review_mod.ReviewConflict:
                conflicts.extend(ids)
    return {'completed':completed,'conflicts':conflicts}


@app.post("/api/review/batch")
def batch_review(payload: dict, request: Request):
    if payload.get("action") not in ("confirmed", "rejected"):
        raise HTTPException(422, "批量复核只支持确认或驳回")
    try:
        events = report_fixes.validate_batch(payload.get("ids"), payload.get("window_seconds"))
    except (ValueError, TypeError) as e:
        raise HTTPException(409, str(e))
    completed, conflicts = [], []
    for event in events:
        try:
            review_mod.review_event(event['id'], payload['action'], request.state.actor,
                                    str(payload.get('comment','批量人工复核')), auth.client_ip(request))
            completed.append(event['id'])
        except review_mod.ReviewConflict:
            conflicts.append(event['id'])
    return {'completed':completed, 'conflicts':conflicts}


@app.get("/api/review/queue")
def review_queue(status: str = None, type: str = None, level: str = None,
                 limit: int = Query(100, ge=1, le=500), offset: int = Query(0, ge=0)):
    rows = db.list_review_queue(status=status, event_type=type, level=level, limit=limit, offset=offset)
    return {"items": rows, "total": db.review_queue_count(status)}


@app.patch("/api/events/{event_id}/review")
async def review_event(event_id: int, payload: dict, request: Request):
    action = payload.get("action"); comment = str(payload.get("comment", ""))
    actor = request.state.actor; ip = auth.client_ip(request)
    try:
        ev = review_mod.review_event(event_id, action, actor, comment, ip)
    except review_mod.ReviewConflict as e:
        raise HTTPException(409, str(e))
    except ValueError as e:
        raise HTTPException(400, str(e))
    if not ev:
        raise HTTPException(404, "事件不存在")
    return {"event": ev}


# ---------------- 通知 ----------------
@app.get("/api/notifications")
def notifications(unread: bool = False, limit: int = 100):
    return db.list_notifications(unread_only=unread, limit=limit)


@app.get("/api/notifications/unread-count")
def unread_count():
    return {"count": db.unread_notification_count()}


@app.post("/api/notifications/{notif_id}/read")
def read_notification(notif_id: int):
    db.mark_notification_read(notif_id)
    return {"ok": True}


@app.post("/api/notifications/read-all")
def read_all_notifications():
    n = db.mark_all_notifications_read()
    return {"read": n}


# ---------------- 底库 ----------------
@app.get("/api/galleries")
def list_galleries(include_items: bool = False):
    items = db.list_galleries()
    if include_items:
        for g in items:
            g["items"] = db.list_gallery_items(g["id"])
    return {"items": items}


@app.post("/api/galleries")
async def create_gallery(payload: dict, request: Request):
    gid = db.create_gallery(payload.get("name", "未命名"), payload.get("description", ""), payload.get("mode", "watch"))
    audit.log_action(request.state.actor, "gallery.create", "gallery", gid, None, auth.client_ip(request))
    return {"id": gid}


@app.delete("/api/galleries/{gid}")
def delete_gallery(gid: int, request: Request):
    db.delete_gallery(gid)
    audit.log_action(request.state.actor, "gallery.delete", "gallery", gid, None, auth.client_ip(request))
    return {"ok": True}


@app.get("/api/galleries/{gid}/items")
def list_gallery_items(gid: int):
    return {"items": db.list_gallery_items(gid)}


@app.post("/api/galleries/{gid}/items")
async def add_gallery_item(gid: int, payload: dict, request: Request):
    iid = db.add_gallery_item(gid, payload.get("kind", "text"), payload.get("content", ""),
                              payload.get("image_path"), payload.get("metadata"))
    audit.log_action(request.state.actor, "gallery.item_add", "gallery_item", iid, {"gallery": gid}, auth.client_ip(request))
    return {"id": iid}


@app.delete("/api/gallery-items/{iid}")
def delete_gallery_item(iid: int, request: Request):
    db.delete_gallery_item(iid)
    audit.log_action(request.state.actor, "gallery.item_delete", "gallery_item", iid, None, auth.client_ip(request))
    return {"ok": True}


# ---------------- 告警 ----------------
@app.get("/api/alerts")
def list_alerts(status: str = None, severity: str = None, source_id: str = None,
                limit: int = 200, offset: int = 0):
    return {"items": db.list_alerts(status, severity, source_id, limit, offset), "stats": db.alert_counts()}


@app.post("/api/alerts/{aid}/ack")
async def ack_alert(aid: int, payload: dict, request: Request):
    if not alerts.ack(aid, request.state.actor, payload.get("comment", ""), auth.client_ip(request)):
        if not db.get_alert(aid):
            raise HTTPException(404, "告警不存在")
        raise HTTPException(409, "告警已确认或已处置")
    return {"ok": True}


@app.post("/api/alerts/{aid}/resolve")
async def resolve_alert(aid: int, payload: dict, request: Request):
    if not alerts.resolve(aid, request.state.actor, payload.get("comment", ""), auth.client_ip(request)):
        if not db.get_alert(aid):
            raise HTTPException(404, "告警不存在")
        raise HTTPException(409, "告警已处置")
    return {"ok": True}


# ---------------- 样本 ----------------
@app.get("/api/samples")
def list_samples(label: str = None, type: str = None, exported: bool = None,
                 limit: int = 200, offset: int = 0):
    return {"items": db.list_samples(label=label, event_type=type, exported=exported, limit=limit, offset=offset)}


@app.get("/api/samples/stats")
def sample_stats():
    return db.sample_stats()


@app.post("/api/samples/export")
def export_samples(request: Request):
    name = samples.export_dataset(request.state.actor, auth.client_ip(request))
    if not name:
        raise HTTPException(409, "没有可导出的新样本")
    return {"file": name}


@app.get("/api/samples/exports")
def list_sample_exports():
    return {"items": samples.list_exports()}


@app.get("/api/samples/exports/{filename}/download")
def download_sample_export(filename: str):
    p = samples.export_path(filename)
    if not p:
        raise HTTPException(404, "文件不存在")
    rendered = display_archive(p)
    return FileResponse(str(rendered), filename=filename, media_type="application/gzip",
                        background=BackgroundTask(rendered.unlink, missing_ok=True))


# ---------------- 审计 / 存储 / 大屏 ----------------
@app.get("/api/audit")
def list_audit_logs(action: str = None, actor: str = None, limit: int = 200, offset: int = 0):
    return {"items": db.list_audit(action=action, actor=actor, limit=limit, offset=offset)}


@app.get("/api/storage")
def storage_info():
    return storage.disk_stats()


@app.get("/api/dashboard")
def dashboard():
    return db.dashboard_stats()


@app.get("/api/gpu")
def gpu_metrics():
    return gpu_stats.read()


# ---------------- 交通机器人问答 ----------------
@app.post("/api/ask")
def ask_agent(payload: dict, request: Request):
    q = str(payload.get("question", "")).strip()
    if not q:
        raise HTTPException(400, "问题不能为空")
    stats = db.dashboard_stats()
    parts = [f"{s.get('name','')}({'在线' if s.get('online') else '离线'},事件{s.get('events',0)},告警{s.get('active_alerts',0)})"
             for s in (stats.get("source_cards") or [])[:8]]
    srcs = "; ".join(parts)
    recent = "; ".join(f"{a.get('title','')}({a.get('severity','')})" for a in (stats.get("recent_alerts") or [])[:5])
    context = (f"实时检测状态：数据源 {stats.get('sources',0)} 个（在线 {stats.get('online_sources',0)}），"
               f"今日事件 {stats.get('events_today',0)}，待复核 {stats.get('pending_review',0)}，"
               f"活跃告警 {stats.get('alerts_active',0)}。\n数据源明细：{srcs or '暂无'}\n最近告警：{recent or '暂无'}")
    if not config.VLM_ENABLED:
        ans = (
            f"当前为本地态势模式：在线数据源 {stats.get('online_sources',0)}/{stats.get('sources',0)}，"
            f"今日事件 {stats.get('events_today',0)}，活跃告警 {stats.get('alerts_active',0)}，"
            f"待复核 {stats.get('pending_review',0)}。启用 VLM_ENABLED=1 后可使用大模型问答。"
        )
        audit.log_action(request.state.actor, "bot.ask", None, None, {"q": q[:60], "fallback": True}, auth.client_ip(request))
        return {"answer": ans, "question": q}
    try:
        ans = vlm.get_engine().generate(
            messages=[
                {"role": "system", "content": "你是「城市交通多模态智能体指挥中枢」的 AI 助手「交通机器人」。根据提供的实时检测数据，简洁专业地回答用户关于交通事件、告警、数据源的问题。用中文，150 字内；数据里没有的不要编造。"},
                {"role": "user", "content": context + "\n\n用户问题：" + q},
            ],
            max_tokens=400, temperature=0,
        ).strip()
    except Exception as e:
        ans = f"机器人暂时无法响应：{e}"
    audit.log_action(request.state.actor, "bot.ask", None, None, {"q": q[:60]}, auth.client_ip(request))
    return {"answer": ans, "question": q}


# ---------------- 误报优化 / 预置算法 ----------------
@app.get("/api/filter-rules")
def list_filter_rules():
    return {"items": db.list_filter_rules(), "stats": db.filter_rule_stats()}


@app.post("/api/filter-rules")
async def create_filter_rule(payload: dict, request: Request):
    rid = db.create_filter_rule(
        payload.get("name", "未命名规则"),
        payload.get("rule_type", "confidence"),
        json.dumps(payload.get("params", {}), ensure_ascii=False),
        payload.get("scope", "global"),
        payload.get("det_task_id"),
        payload.get("source_id"),
        1 if payload.get("enabled", True) else 0,
    )
    audit.log_action(request.state.actor, "filter_rule.create", "filter_rule", rid, payload, auth.client_ip(request))
    return {"id": rid}


@app.patch("/api/filter-rules/{rid}")
async def update_filter_rule(rid: int, payload: dict, request: Request):
    fields = {}
    for k in ("name", "rule_type", "scope", "det_task_id", "source_id", "enabled"):
        if k in payload:
            fields[k] = 1 if k == "enabled" and payload[k] else (0 if k == "enabled" else payload[k])
    if "params" in payload:
        fields["params_json"] = json.dumps(payload["params"], ensure_ascii=False)
    if not db.update_filter_rule(rid, **fields):
        raise HTTPException(404, "规则不存在或无更新")
    audit.log_action(request.state.actor, "filter_rule.update", "filter_rule", rid, list(fields.keys()), auth.client_ip(request))
    return {"ok": True}


@app.delete("/api/filter-rules/{rid}")
def delete_filter_rule(rid: int, request: Request):
    if not db.delete_filter_rule(rid):
        raise HTTPException(404, "规则不存在")
    audit.log_action(request.state.actor, "filter_rule.delete", "filter_rule", rid, None, auth.client_ip(request))
    return {"ok": True}


@app.get("/api/filter-rules/stats")
def filter_rule_stats():
    return db.filter_rule_stats()


@app.get("/api/algorithm-presets")
def algorithm_presets():
    return {"items": presets.list_presets()}


# ---------------- 报表 / 评测 / 压测 / 应急 / YOLO ----------------
@app.get("/api/reports/summary")
def report_summary(days: int = Query(7, ge=1, le=90)):
    return reports.summary(days)


@app.get("/api/reports/generate")
def report_generate(period: str = "weekly"):
    return reports.generate(period)


@app.get("/api/reports/export")
def report_export(kind: str = "events", days: int = Query(7, ge=1, le=90)):
    data = reports.export_csv(kind, days)
    return Response(
        content=data.encode("utf-8"),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{kind}_{days}d.csv"'},
    )


@app.get("/api/benchmark/info")
def benchmark_info():
    return benchmark.info()


@app.post("/api/benchmark/run")
def benchmark_run(payload: dict = None):
    payload = payload or {}
    return benchmark.run(int(payload.get("limit", 200)))


@app.post("/api/stress-test")
def run_stress_test(payload: dict):
    task_id = payload.get("task_id")
    video_path = payload.get("video_path")
    if task_id:
        t = db.get_task(task_id)
        if not t:
            raise HTTPException(404, "任务不存在")
        video_path = t.get("file_path")
    if not video_path or not os.path.exists(video_path):
        raise HTTPException(400, "请提供有效 video_path 或 task_id")
    return stress_test.run(video_path, int(payload.get("concurrency", 2)), payload.get("frames_per_stream"))


@app.get("/api/emergency/status")
def emergency_status():
    return {
        "configured": bool(config.EMERGENCY_API_URL),
        "api_url": config.EMERGENCY_API_URL,
        "ui_url": config.EMERGENCY_UI_URL,
        "local_plan_enabled": True,
        "model": config.VLM_MODEL,
        "vlm_enabled": config.VLM_ENABLED,
    }


@app.post("/api/emergency/push")
def emergency_push(payload: dict, request: Request):
    aid = payload.get("alert_id")
    if not aid:
        raise HTTPException(400, "alert_id 必填")
    try:
        report_fixes.require_approval(emergency_plan.build_context(alert_id=int(aid)))
    except ValueError as e:
        raise HTTPException(409, str(e))
    r = alerts.push_emergency(int(aid))
    audit.log_action(request.state.actor, "emergency.push", "alert", aid, r, auth.client_ip(request))
    return r


@app.post("/api/emergency/plan")
def emergency_generate_plan(request: Request, payload: dict = None):
    payload = payload or {}
    try:
        r = emergency_plan.generate(
            alert_id=payload.get("alert_id") or None,
            event_id=payload.get("event_id") or None,
            extra=str(payload.get("extra") or ""),
        )
    except ValueError as e:
        raise HTTPException(409, str(e))
    target_id = r.get("incident", {}).get("alert_id") or r.get("incident", {}).get("event_id")
    audit.log_action(
        request.state.actor,
        "emergency.plan_generate",
        "alert" if r.get("incident", {}).get("alert_id") else "event",
        target_id,
        {"fallback_used": r.get("fallback_used"), "model": r.get("model")},
        auth.client_ip(request),
    )
    return r


@app.post("/api/emergency/plan/stream")
async def emergency_plan_stream(request: Request, payload: dict = None):
    """NDJSON 流：context → delta… → done；客户端断开即取消模型请求。"""
    import asyncio
    payload = payload or {}
    try:
        ctx, started = emergency_plan.prepare(
            alert_id=payload.get("alert_id") or None,
            event_id=payload.get("event_id") or None,
            extra=str(payload.get("extra") or ""),
        )
    except ValueError as e:
        raise HTTPException(409, str(e))
    owner = "plan:" + uuid.uuid4().hex
    loop = asyncio.get_running_loop()
    queue: asyncio.Queue = asyncio.Queue()
    actor, ip = request.state.actor, auth.client_ip(request)

    def work():
        try:
            text = emergency_plan._call_model(ctx, owner=owner,
                                              on_delta=lambda d: loop.call_soon_threadsafe(queue.put_nowait, ("delta", d)))
            if not text:
                raise RuntimeError("模型返回为空")
            result = emergency_plan.finish(ctx, text, started)
        except Exception as exc:
            log.warning("应急方案流式生成失败，使用兜底模板: %s", exc)
            result = emergency_plan.finish(ctx, "", started, fallback_reason=str(exc))
        loop.call_soon_threadsafe(queue.put_nowait, ("done", result))

    async def body():
        future = loop.run_in_executor(None, work)
        try:
            yield json.dumps({"type": "context", "incident": ctx["incident"], "reference": ctx["reference"],
                              "model": config.VLM_MODEL}, ensure_ascii=False) + "\n"
            while True:
                kind, data = await queue.get()
                if kind == "delta":
                    yield json.dumps({"type": "delta", "text": data}, ensure_ascii=False) + "\n"
                else:
                    target = data["incident"].get("alert_id") or data["incident"].get("event_id")
                    audit.log_action(actor, "emergency.plan_generate",
                                     "alert" if data["incident"].get("alert_id") else "event", target,
                                     {"fallback_used": data.get("fallback_used"), "model": data.get("model"), "stream": True}, ip)
                    yield json.dumps({"type": "done", **data}, ensure_ascii=False) + "\n"
                    break
        finally:
            if not future.done():
                vlm.cancel(owner)

    return StreamingResponse(body(), media_type="application/x-ndjson", headers={"X-Accel-Buffering": "no"})


@app.get("/api/emergency/situation")
def emergency_situation():
    groups = {}
    for alert in db.list_alerts(status="active", limit=500):
        key = (alert.get("source_id"), alert.get("event_type") or alert.get("title"))
        group = groups.get(key)
        if group is None:
            groups[key] = {**alert, "count": 1, "first_at": alert.get("created_at")}
        else:
            group["count"] += 1
            group["first_at"] = alert.get("created_at")
            if alert.get("severity", "") > group.get("severity", ""):
                group["severity"] = alert["severity"]
    items = list(groups.values())[:12]
    with db._connect() as conn:
        levels = {row[0]: row[1] for row in conn.execute(
            "SELECT severity, COUNT(*) FROM alerts WHERE status='active' GROUP BY severity")}
        events_today = conn.execute(
            "SELECT COUNT(*) FROM traffic_events WHERE date(created_at) = date('now','localtime') AND event_type<>'Normal'"
        ).fetchone()[0]
        events_hour = conn.execute(
            "SELECT COUNT(*) FROM traffic_events WHERE datetime(created_at) BETWEEN datetime('now','localtime','-1 hour') AND datetime('now','localtime') AND event_type<>'Normal'"
        ).fetchone()[0]
        running = [dict(r) for r in conn.execute(
            "SELECT id, filename, progress, det_task_id, updated_at FROM analysis_tasks "
            "WHERE status IN ('pending','processing') ORDER BY created_at DESC LIMIT 10")]
    return {
        "now": db._now(),
        "alerts": items,
        "levels": {"L3": levels.get("L3", 0), "L2": levels.get("L2", 0), "L1": levels.get("L1", 0)},
        "active_alerts": sum(levels.values()),
        "events_today": events_today,
        "events_last_hour": events_hour,
        "running_runs": [r for r in running if not stream_api.is_running(r["id"])],
        "running_streams": [r for r in running if stream_api.is_running(r["id"])],
        "vlm": {"enabled": config.VLM_ENABLED, "model": config.VLM_MODEL},
    }


@app.post("/api/emergency/execute")
def emergency_execute(payload: dict, request: Request):
    sid = payload.get("source_id")
    tid = payload.get("det_task_id") or db.BUILTIN_TASK_ID
    src = db.get_source(sid) if sid else None
    uri = normalize_stream_url(payload.get("uri") or payload.get("camera_url") or "")
    if not src and uri:
        sid = uuid.uuid4().hex[:12]
        db.create_source(
            sid,
            payload.get("name") or f"应急视频源-{sid[:4]}",
            payload.get("kind") or _infer_source_kind(uri),
            uri,
            payload.get("lat"),
            payload.get("lng"),
            payload.get("address"),
        )
        src = db.get_source(sid)
    if not src:
        raise HTTPException(404, "数据源不存在")
    if not db.get_task_det(tid):
        raise HTTPException(404, "检测任务不存在")
    if not storage.has_free_space():
        raise HTTPException(507, f"磁盘剩余不足 {config.MIN_FREE_GB}GB")

    run_id = uuid.uuid4().hex[:12]
    db.create_task(run_id, src.get("name"), src.get("uri"), 0.0, det_task_id=tid, source_id=sid)
    try:
        worker.submit_analysis(run_id, stop_on_event=True)
    except worker.QueueFull as exc:
        db.update_status(run_id, config.STATUS_FAILED, str(exc))
        raise HTTPException(429, str(exc)) from exc
    audit.log_action(
        request.state.actor,
        "emergency.execute",
        "task",
        run_id,
        {"source_id": sid, "det_task_id": tid, "extra": payload.get("extra", "")},
        auth.client_ip(request),
    )
    return {
        "ok": True,
        "run_id": run_id,
        "source_id": sid,
        "det_task_id": tid,
        "message": "已启动检测，前端将等待风险事件并自动生成应急方案",
    }


@app.get("/api/vlm/status")
def vlm_status():
    return vlm.health_check()


@app.get("/api/detector/status")
@app.get("/api/yolo/status", include_in_schema=False)
def yolo_status():
    return yolo_detector.status()


# ---------------- 用户管理 ----------------
@app.get("/api/users")
def list_users():
    return {"items": db.list_users()}


@app.post("/api/users")
async def create_user(payload: dict, request: Request):
    username = str(payload.get("username", "")).strip()
    plain = str(payload.get("password", ""))
    role = payload.get("role", "viewer")
    if not username or not plain:
        raise HTTPException(400, "用户名和密码必填")
    if role not in auth.ROLES:
        raise HTTPException(400, "非法角色")
    h, salt = auth.hash_password(plain)
    try:
        uid = db.insert_user(username, h, salt, role, 1 if payload.get("enabled", True) else 0)
    except Exception as e:
        raise HTTPException(409, f"创建失败: {e}")
    audit.log_action(request.state.actor, "user.create", "user", uid, {"username": username, "role": role}, auth.client_ip(request))
    return {"id": uid}


@app.patch("/api/users/{uid}")
async def update_user(uid: int, payload: dict, request: Request):
    u = db.get_user(uid)
    if not u:
        raise HTTPException(404, "用户不存在")
    fields = {}
    if "username" in payload:
        fields["username"] = str(payload["username"]).strip()
    if "role" in payload:
        if payload["role"] not in auth.ROLES:
            raise HTTPException(400, "非法角色")
        if u["role"] == "admin" and payload["role"] != "admin" and db.admin_count(exclude_user_id=uid) <= 0:
            raise HTTPException(400, "不能降级最后一个管理员")
        fields["role"] = payload["role"]
    if "enabled" in payload:
        if u["role"] == "admin" and not payload["enabled"] and db.admin_count(exclude_user_id=uid) <= 0:
            raise HTTPException(400, "不能禁用最后一个管理员")
        fields["enabled"] = 1 if payload["enabled"] else 0
    if payload.get("password"):
        h, salt = auth.hash_password(str(payload["password"]))
        fields["pass_hash"] = h
        fields["salt"] = salt
    if not db.update_user(uid, **fields):
        raise HTTPException(400, "没有可更新字段")
    auth.drop_user_sessions(u["username"])
    audit.log_action(request.state.actor, "user.update", "user", uid, list(fields.keys()), auth.client_ip(request))
    return {"ok": True}


@app.delete("/api/users/{uid}")
def delete_user(uid: int, request: Request):
    u = db.get_user(uid)
    if not u:
        raise HTTPException(404, "用户不存在")
    if u["role"] == "admin" and db.admin_count(exclude_user_id=uid) <= 0:
        raise HTTPException(400, "不能删除最后一个管理员")
    db.delete_user(uid)
    auth.drop_user_sessions(u["username"])
    audit.log_action(request.state.actor, "user.delete", "user", uid, {"username": u["username"]}, auth.client_ip(request))
    return {"ok": True}


# ---------------- 前端配置 ----------------
@app.get("/api/config")
def get_config():
    return {
        "traffic_reasoning_enabled": True,
        "traffic_detection_profile": "标准画质 · 精简输出",
        "poll_interval_sec": config.POLL_INTERVAL_SEC,
        "sample_interval_sec": config.SAMPLE_INTERVAL_SEC,
        "event_types": EVENT_TYPES,
        "event_color": EVENT_COLOR,
        "level_color": LEVEL_COLOR,
        "level_label": LEVEL_LABEL,
        "max_upload_mb": config.MAX_UPLOAD_SIZE // 1024 // 1024,
        "max_concurrent_analysis": config.MAX_CONCURRENT_ANALYSIS,
        "max_streams": config.MAX_STREAMS,
        "vlm_max_inflight": config.VLM_MAX_INFLIGHT,
        "map_provider": config.MAP_PROVIDER,
        "amap_js_key": config.AMAP_JS_KEY,
        "amap_security_code": config.AMAP_SECURITY_CODE,
        "voting_mode": config.VOTING_MODE,
        "vlm_enabled": config.VLM_ENABLED,
        "analysis_max_edge": config.ANALYSIS_MAX_EDGE,
        "stream_analysis_max_edge": config.STREAM_ANALYSIS_MAX_EDGE,
        "stream_preview_max_edge": config.STREAM_PREVIEW_MAX_EDGE,
        "stream_reader_fps": config.STREAM_READER_FPS,
        "stream_adaptive_interval_enabled": config.STREAM_ADAPTIVE_INTERVAL_ENABLED,
    }


# ---------------- 静态 ----------------
app.mount("/static", StaticFiles(directory=str(config.STATIC_DIR)), name="static")
app.mount("/snapshots", StaticFiles(directory=str(config.SNAPSHOT_DIR)), name="snapshots")
app.mount("/uploads", StaticFiles(directory=str(config.UPLOAD_DIR)), name="uploads")
app.mount("/samples-img", StaticFiles(directory=str(config.SAMPLES_IMG_DIR)), name="samples-img")
app.mount("/gallery", StaticFiles(directory=str(config.GALLERY_DIR)), name="gallery")


@app.get("/")
def index():
    resp = FileResponse(str(config.STATIC_DIR / "index.html"))
    resp.headers["Cache-Control"] = "no-store"
    return resp
