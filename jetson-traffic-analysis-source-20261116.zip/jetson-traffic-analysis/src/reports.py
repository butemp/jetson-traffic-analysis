"""报表聚合与 CSV 导出。"""
import csv
import io
from datetime import datetime, timedelta

import db


def _date_range(days: int):
    end = datetime.now().date()
    start = end - timedelta(days=max(1, days) - 1)
    return start.isoformat(), end.isoformat()


def summary(days: int = 7) -> dict:
    start, end = _date_range(days)
    with db._connect() as conn:
        events_total = conn.execute(
            "SELECT COUNT(*) FROM traffic_events WHERE date(created_at) BETWEEN ? AND ? AND event_type<>'Normal'",
            (start, end),
        ).fetchone()[0]
        alerts_total = conn.execute(
            "SELECT COUNT(*) FROM alerts WHERE date(created_at) BETWEEN ? AND ?", (start, end)
        ).fetchone()[0]
        total_src = conn.execute("SELECT COUNT(*) FROM data_sources WHERE COALESCE(archived,0)=0 AND kind<>'file'").fetchone()[0]
        online_src = conn.execute("SELECT COUNT(*) FROM data_sources WHERE COALESCE(archived,0)=0 AND online=1 AND kind<>'file'").fetchone()[0]
        pos = conn.execute("SELECT COUNT(*) FROM traffic_events WHERE review_status IN ('confirmed','escalated') AND date(created_at) BETWEEN ? AND ?", (start,end)).fetchone()[0]
        neg = conn.execute("SELECT COUNT(*) FROM traffic_events WHERE review_status='rejected' AND date(created_at) BETWEEN ? AND ?", (start,end)).fetchone()[0]
        filter_hits = conn.execute("SELECT COALESCE(SUM(hit_count),0) FROM filter_rules").fetchone()[0]
        trend = []
        for i in range(days - 1, -1, -1):
            day = (datetime.now().date() - timedelta(days=i)).isoformat()
            ev = conn.execute(
                "SELECT COUNT(*) FROM traffic_events WHERE date(created_at)=? AND event_type<>'Normal'", (day,)
            ).fetchone()[0]
            al = conn.execute("SELECT COUNT(*) FROM alerts WHERE date(created_at)=?", (day,)).fetchone()[0]
            trend.append({"day": day, "events": ev, "alerts": al})
        by_type = conn.execute(
            "SELECT event_type, COUNT(*) AS count FROM traffic_events "
            "WHERE date(created_at) BETWEEN ? AND ? AND event_type<>'Normal' "
            "GROUP BY event_type ORDER BY count DESC",
            (start, end),
        ).fetchall()
        by_source = conn.execute(
            "SELECT COALESCE(s.name,e.source_id,'未知') AS source, COUNT(*) AS events, "
            "SUM(CASE WHEN e.review_status='rejected' THEN 1 ELSE 0 END) AS rejected "
            "FROM traffic_events e LEFT JOIN data_sources s ON s.id=e.source_id "
            "WHERE date(e.created_at) BETWEEN ? AND ? AND e.event_type<>'Normal' "
            "GROUP BY source ORDER BY events DESC LIMIT 10",
            (start, end),
        ).fetchall()
    reviewed = pos + neg
    return {
        "range": {"start": start, "end": end, "days": days},
        "kpi": {
            "events": events_total,
            "alerts": alerts_total,
            "online_rate": round(online_src / total_src * 100, 1) if total_src else None,
            "false_alarm_rate": round(neg / reviewed * 100, 1) if reviewed else None,
            "filter_hits": filter_hits,
        },
        "trend": trend,
        "by_type": [dict(r) for r in by_type],
        "by_source": [dict(r) for r in by_source],
    }


def generate(period: str = "daily") -> dict:
    days = {"daily": 1, "weekly": 7, "monthly": 30}.get(period, 7)
    s = summary(days)
    k = s["kpi"]
    advice = []
    if k["false_alarm_rate"] is None:
        advice.append("本期没有已复核事件，无法判断误报水平。")
    if k["false_alarm_rate"] is not None and k["false_alarm_rate"] > 30:
        advice.append("人工误报率偏高，建议提高置信度门槛或新增关键词过滤规则。")
    if k["online_rate"] is not None and k["online_rate"] < 80:
        advice.append("设备在线率不足 80%，建议优先排查离线数据源。")
    if k["alerts"] > 0 and not advice:
        advice.append("当前存在告警，请结合复核台及时闭环处置。")
    if not advice:
        advice.append("本周期运行平稳，继续保持现有策略。")
    return {"period": period, "summary": s, "conclusions": advice}


def export_csv(kind: str = "events", days: int = 7) -> str:
    start, end = _date_range(days)
    out = io.StringIO()
    out.write("\ufeff")
    with db._connect() as conn:
        if kind == "alerts":
            rows = conn.execute(
                "SELECT id,severity,status,title,message,created_at FROM alerts WHERE date(created_at) BETWEEN ? AND ? ORDER BY created_at DESC",
                (start, end),
            ).fetchall()
        elif kind == "daily":
            rows = summary(days)["trend"]
        else:
            rows = conn.execute(
                "SELECT id,event_type,severity,confidence,description,created_at FROM traffic_events "
                "WHERE date(created_at) BETWEEN ? AND ? AND event_type<>'Normal' ORDER BY created_at DESC",
                (start, end),
            ).fetchall()
    rows = [dict(r) for r in rows]
    if rows:
        writer = csv.DictWriter(out, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    return out.getvalue()
