"""严重度分级 + 上报路由（预置规则，类型集合见 config.SEVERITY_HIGH/MED）。"""
import config

LEVEL_LABEL = {"L1": "提示", "L2": "警告", "L3": "紧急"}
LEVEL_COLOR = {"L1": "info", "L2": "warning", "L3": "danger"}
_ORDER = {"L1": 1, "L2": 2, "L3": 3}


def compute_severity(event_type, confidence, has_event):
    """返回 'L1'/'L2'/'L3' 或 None（无事件）。"""
    if not has_event or not event_type or event_type == "Normal":
        return None
    hi = (confidence == "高")
    if event_type in config.SEVERITY_HIGH:
        return "L3" if hi else "L2"
    if event_type in config.SEVERITY_MED:
        return "L2" if hi else "L1"
    # 其余（行人/非机动车/牛羊闯入等）
    return "L2" if hi else "L1"


def escalate_up(level):
    """升一级：L1->L2->L3（L3 封顶）。"""
    n = _ORDER.get(level, 1)
    return "L3" if n >= 3 else ("L2" if n == 1 else "L3")


def channels_for(level):
    """该级别应走的渠道；webhook 是否外发由 NOTIFY_OUTBOUND_LEVELS 控制。"""
    if level in ("L2", "L3"):
        channels = ["in_app"]
        if config.NOTIFY_WEBHOOK_URL and level in config.NOTIFY_OUTBOUND_LEVELS:
            channels.append("webhook")
        return channels
    return []
