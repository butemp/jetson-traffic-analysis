"""人工复核：confirmed/rejected/escalated 三态，联动审计/样本/通知。"""
import logging
from typing import Optional

import audit
import db
import notifier
import samples
from escalation import LEVEL_LABEL, escalate_up

log = logging.getLogger("traffic.review")

ACTIONS = {"confirmed": "confirmed", "rejected": "rejected", "escalated": "escalated"}


class ReviewConflict(RuntimeError):
    pass


def review_event(event_id: int, action: str, reviewer: str, comment: str = "", ip: str = None) -> Optional[dict]:
    if action not in ACTIONS:
        raise ValueError(f"非法 action: {action}")
    ev = db.get_event(event_id)
    if not ev:
        return None
    new_status = ACTIONS[action]
    if not db.set_event_review(event_id, new_status, reviewer, comment):
        raise ReviewConflict("事件已复核，请勿重复提交")
    audit.log_action(reviewer, "review." + action, "event", event_id,
                     {"type": ev["event_type"], "comment": comment}, ip)
    log.info("事件 %s -> %s by %s", event_id, new_status, reviewer)

    if action == "escalated":
        new_level = escalate_up(ev.get("severity") or "L1")
        with db._write_lock, db._connect() as conn:
            conn.execute("UPDATE traffic_events SET severity=? WHERE id=?", (new_level, event_id))
        ev["severity"] = new_level
        title = f"【{LEVEL_LABEL[new_level]}】人工升级上报"
        msg = f"{ev.get('filename','')} @ {ev.get('timestamp_sec',0):.1f}s {ev['event_type']}：{ev['description']}"
        try:
            notifier.notify_event(ev, new_level, title, msg)
        except Exception as e:
            log.warning("升级通知失败: %s", e)
    else:
        try:
            samples.create_sample_from_event(ev, action, reviewer)
        except Exception as e:
            log.warning("样本入库失败: %s", e)

    return db.get_event(event_id)
