import asyncio
from collections import OrderedDict, deque
import io
import json
import math
import struct
import threading
import time
import uuid
from typing import Literal
from urllib.parse import urlsplit

from fastapi import APIRouter, HTTPException, Request, WebSocket, WebSocketDisconnect
from pydantic import BaseModel, Field
from starlette.concurrency import run_in_threadpool

import auth
import config
import db
import video

router = APIRouter()
_sessions = {}
_sessions_lock = threading.Lock()
UNCONNECTED_TTL = 15.


class StreamStart(BaseModel):
    persistent: bool = False
    name: str = Field(default='逐帧安全巡检', min_length=1, max_length=120)
    source_id: str | None = Field(default=None, max_length=120)
    scenarios: list[Literal['knife','fight']] = Field(default=['knife','fight'], min_length=1, max_length=2)
    knife_model: Literal['yolo','rtdetr','trained','trained-u8'] = 'trained-u8'
    knife_confidence: float = Field(default=.4, ge=.05, le=.99, allow_inf_nan=False)
    fight_threshold: float = Field(default=.65, ge=.05, le=.99, allow_inf_nan=False)
    tiled: bool = True
    describe: bool = False


def is_running(task_id=None):
    with _sessions_lock:
        return bool(_sessions) if task_id is None else task_id in _sessions


def _expire_locked(now):
    for key, old in list(_sessions.items()):
        if not old['connected'] and now-old['created'] > UNCONNECTED_TTL:
            _sessions.pop(key)
            old['stop'].set()
            old['closed'].set()
            db.update_status(key, config.STATUS_FAILED, '等待流连接超时')


def _get_models(options):
    from streaming import StreamModels
    models = StreamModels(tuple(sorted(options.scenarios)), options.knife_confidence, options.tiled, options.knife_model)
    models.warmup()
    return models


@router.get('/api/streams')
def list_streams():
    now = time.monotonic()
    with _sessions_lock:
        _expire_locked(now)
        items = [{'id': key, 'name': item['options'].name, 'status': item['status'], 'connected': item['connected'],
                  'source_id': item['options'].source_id, 'scenarios': item['options'].scenarios,
                  'persistent': item['options'].persistent, 'describe': item['options'].describe,
                  'age_sec': round(now-item['created'], 1), 'processed': item.get('processed', 0)}
                 for key, item in _sessions.items()]
    scheduler = None
    try:
        import gpu_scheduler
        if gpu_scheduler._hub is not None:
            scheduler = gpu_scheduler._hub.stats()
    except Exception:
        pass
    return {'items': items, 'max_streams': config.MAX_STREAMS, 'scheduler': scheduler}


@router.post('/api/streams')
async def start_stream(options: StreamStart, request: Request):
    source = db.get_source(options.source_id) if options.source_id else None
    if options.source_id and source is None:
        raise HTTPException(404, '数据源不存在')
    if options.persistent and source is None:
        raise HTTPException(422, '后台持续检测需要已登记的网络摄像头')
    if source is not None and not video.is_stream_path(source['uri']):
        raise HTTPException(422, '本地视频请从浏览器逐帧送入；摄像头请选择网络流源')
    with _sessions_lock:
        _expire_locked(time.monotonic())
        if len(_sessions) >= config.MAX_STREAMS:
            raise HTTPException(429, f'最多同时运行 {config.MAX_STREAMS} 路安全巡检，请先停止其他巡检')
        if options.persistent and any(s['options'].persistent and s['options'].source_id == options.source_id for s in _sessions.values()):
            raise HTTPException(409, '该摄像头已有后台巡检，请恢复查看或先停止已有任务')
        key = uuid.uuid4().hex[:12]
        db.create_task(key, options.name, '', det_task_id=db.STREAM_TASK_ID, source_id=options.source_id)
        _sessions[key] = {'id':key, 'options':options, 'source':source, 'created':time.monotonic(),
                          'connected':False, 'stop':threading.Event(), 'closed':threading.Event(),
                          'status':'starting', 'processed':0}
    if options.persistent:
        session = _sessions[key]
        session['connected'] = True
        session['relay'] = _Relay()
        session['runner'] = asyncio.create_task(_background_session(key, session))
    return {'id':key,'status':'starting','ws_path':f'/api/streams/{key}/ws', 'persistent': options.persistent}


class _Relay:
    """Keep acquisition independent of viewers; never acknowledge unseen frames."""
    def __init__(self):
        self.commands = asyncio.Queue(maxsize=64)
        self.viewers = set()
        self.ready = None
        self.latest = None

    async def receive(self):
        return await self.commands.get()

    async def send_json(self, payload):
        if payload.get('type') == 'ready':
            self.ready = payload
        self._fanout(('json', payload))

    async def send_bytes(self, packet):
        self.latest = packet
        self._fanout(('bytes', packet))

    def _fanout(self, item):
        for queue in tuple(self.viewers):
            if queue.full():
                queue.get_nowait()
            queue.put_nowait(item)


async def _background_session(key, session):
    try:
        await _run_session(session['relay'], key, session)
    finally:
        session['stop'].set()
        with _sessions_lock:
            _sessions.pop(key, None)
        session['closed'].set()


async def _watch_background(socket, session):
    relay = session['relay']
    queue = asyncio.Queue(maxsize=4)
    relay.viewers.add(queue)
    await socket.accept()
    async def commands():
        while not session['stop'].is_set():
            message = await socket.receive()
            if message['type'] == 'websocket.disconnect':
                return
            if not auth.get_session(socket):
                return
            text = message.get('text', '')
            if len(text) > 4096:
                return
            command = json.loads(text)
            if command.get('type') == 'painted':
                if not relay.commands.full():
                    relay.commands.put_nowait(message)
            elif command.get('type') == 'stop':
                session['stop'].set()
                return
    async def frames():
        if relay.ready:
            await socket.send_json(relay.ready)
        if relay.latest:
            await socket.send_bytes(relay.latest)
        while not session['stop'].is_set():
            try:
                kind, payload = await asyncio.wait_for(queue.get(), .5)
            except asyncio.TimeoutError:
                continue
            if kind == 'bytes':
                await socket.send_bytes(payload)
            else:
                await socket.send_json(payload)
    tasks = [asyncio.create_task(commands()), asyncio.create_task(frames())]
    try:
        await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
    finally:
        relay.viewers.discard(queue)
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        await socket.close()


@router.get('/api/streams/{key}')
def stream_status(key: str):
    task = db.get_task(key)
    if not task or task.get('det_task_id') != db.STREAM_TASK_ID:
        raise HTTPException(404, '流任务不存在')
    return {'id':key,'status':task['status'],'running':is_running(key),'events':db.list_stream_events(key)}


@router.delete('/api/streams/{key}')
def stop_stream(key: str):
    with _sessions_lock:
        session = _sessions.get(key)
        if session is None:
            return {'id':key,'status':'stopped'}
        session['stop'].set()
        if not session['connected']:
            _sessions.pop(key)
            session['closed'].set()
    db.cancel_task(key)
    stopped = session['closed'].wait(3.)
    return {'id':key,'status':'stopped' if stopped else 'stopping'}


def shutdown():
    with _sessions_lock:
        for session in _sessions.values():
            session['stop'].set()


def _decode_packet(data):
    import cv2
    import numpy as np
    from PIL import Image
    if len(data) > 6*1024*1024 or len(data) < 5:
        raise ValueError('帧消息大小无效')
    size = struct.unpack('!I',data[:4])[0]
    if not 0 < size <= 1024 or size+4 >= len(data):
        raise ValueError('帧消息头无效')
    header = json.loads(data[4:4+size])
    if not isinstance(header,dict) or set(header) != {'seq','pts'}:
        raise ValueError('帧头必须只包含seq和pts')
    seq, pts = header['seq'], header['pts']
    if type(seq) is not int or seq < 0 or type(pts) not in (int,float) or not math.isfinite(pts) or pts < 0:
        raise ValueError('帧序号或时间戳无效')
    jpeg = data[4+size:]
    with Image.open(io.BytesIO(jpeg)) as image:
        if image.format != 'JPEG' or image.width*image.height > 4096*2160 or max(image.size)>4096:
            raise ValueError('只支持不超过4K的JPEG帧')
    frame = cv2.imdecode(np.frombuffer(jpeg,np.uint8),cv2.IMREAD_COLOR)
    if frame is None:
        raise ValueError('无法解码JPEG帧')
    return seq, float(pts), frame


def _encode_packet(result, annotated, received_at):
    import cv2
    from streaming import _small
    preview = _small(annotated,1280)
    ok,jpeg = cv2.imencode('.jpg',preview,[cv2.IMWRITE_JPEG_QUALITY,85])
    if not ok:
        raise RuntimeError('实时图像编码失败')
    result['metrics']['frame_age_ms'] = (time.monotonic()-received_at)*1000
    header = json.dumps({'type':'frame',**result},ensure_ascii=False,allow_nan=False).encode()
    return struct.pack('!I',len(header))+header+jpeg.tobytes()


def _infer(detector, frame, seq, pts, received, history):
    from streaming import description_frames
    result = detector.step(frame, seq, pts, received, history)
    evidence = result.pop('_event_evidence', {})
    context = {}
    for event in result['new_events']:
        source = evidence.get(event['id'])
        event_frame = source['frame'] if source else frame
        event_pts = source['pts'] if source else pts
        context[event['id']] = description_frames(detector.history, event_pts, event_frame, event['boxes'])
    return result, context, evidence


def _publish_prepare(key, frame, result, received, evidence):
    import cv2
    from streaming import render_frame
    annotated = render_frame(frame, result)
    for event in result['new_events']:
        source = evidence.get(event['id'])
        event_frame = source['frame'] if source else frame
        event_annotated = render_frame(event_frame, {'boxes': event['boxes']}) if source else annotated
        filename = f'{key}_{event["id"]}.jpg'
        if not cv2.imwrite(str(config.SNAPSHOT_DIR/filename), event_annotated):
            raise RuntimeError('事件证据保存失败')
        db.save_stream_event(key, event, filename)
    return _encode_packet(result, annotated, received)


def _write_trace(trace, lines):
    trace.write(''.join(lines))
    trace.flush()


@router.websocket('/api/streams/{key}/ws')
async def stream_socket(socket: WebSocket, key: str):
    session_auth = auth.get_session(socket)
    origin = socket.headers.get('origin')
    if not session_auth or not auth.can_write(session_auth.get('role')):
        await socket.close(code=4401)
        return
    if origin and (urlsplit(origin).netloc != socket.headers.get('host') or urlsplit(origin).scheme not in ('http','https')):
        await socket.close(code=4403)
        return
    with _sessions_lock:
        background = _sessions.get(key)
    if background and background['options'].persistent:
        await _watch_background(socket, background)
        return
    with _sessions_lock:
        session = _sessions.get(key)
        if session is None or session['connected'] or session['stop'].is_set():
            session = None
        else:
            session['connected'] = True
    if session is None:
        await socket.close(code=4409)
        return
    try:
        await socket.accept()
        await _run_session(socket, key, session)
    except Exception as error:
        db.update_status(key, config.STATUS_FAILED, str(error))
    finally:
        session['stop'].set()
        db.update_status(key, config.STATUS_CANCELLED)
        with _sessions_lock:
            if _sessions.get(key) is session:
                _sessions.pop(key)
        session['closed'].set()
        try:
            await socket.close()
        except RuntimeError:
            pass


async def _run_session(socket, key, session):
    stop = session['stop']
    options = session['options']
    loop = asyncio.get_running_loop()
    incoming = asyncio.Queue(maxsize=1)
    results = asyncio.Queue(maxsize=2)
    updates = asyncio.Queue(maxsize=32)
    input_done = asyncio.Event()
    pending_red = OrderedDict()
    captured_history = deque(maxlen=30)
    state = {'last_seq': -1, 'last_pts': -1., 'dropped': 0, 'received': 0, 'processed': 0, 'inflight': 0}
    transport = 'registered_stream' if session['source'] is not None else 'browser_frame_packets'
    tasks = []
    describer = None
    trace = None
    trace_lines = []
    outcome = config.STATUS_CANCELLED

    def fail(error):
        session.setdefault('error', str(error))
        stop.set()

    def description_update(event):
        if stop.is_set():
            return
        stored = db.save_stream_event(key, event)
        if stored is None:
            return
        def put():
            if updates.full():
                updates.get_nowait()
            updates.put_nowait({'type':'description','event':stored})
        loop.call_soon_threadsafe(put)

    def acknowledge(seq, epoch):
        entry = pending_red.get((epoch,seq))
        if entry is None:
            return
        if entry['published_at'] is None:
            entry['acknowledged'] = True
            return
        pending_red.pop((epoch,seq),None)
        for event in entry['events']:
            describer.submit(event,entry['frames'][event['id']],entry['published_at'])

    def put_frame(item):
        from streaming import _small
        seq,pts,frame,received = item
        state['received'] += 1
        if not captured_history or frame.shape[:2] != session.get('input_shape') or pts-captured_history[-1][0]>.75:
            captured_history.clear()
        session['input_shape'] = frame.shape[:2]
        if not captured_history or pts-captured_history[-1][0] >= .1:
            captured_history.append((pts,_small(frame)))
        while captured_history and pts-captured_history[0][0]>2.25:
            captured_history.popleft()
        if incoming.full():
            incoming.get_nowait()
            state['dropped'] += 1
        incoming.put_nowait((*item,list(captured_history)))

    async def receive():
        try:
            while not stop.is_set():
                message = await socket.receive()
                if message['type'] == 'websocket.disconnect':
                    break
                if not options.persistent and not auth.get_session(socket):
                    raise ValueError('登录会话已经失效')
                if message.get('bytes') is not None:
                    if session['source'] is not None or input_done.is_set():
                        raise ValueError('当前流不接受浏览器图像')
                    received=time.monotonic()
                    seq,pts,frame=await run_in_threadpool(_decode_packet,message['bytes'])
                    if seq<=state['last_seq'] or pts<=state['last_pts']:
                        raise ValueError('拒绝重复或乱序帧')
                    state['last_seq'],state['last_pts']=seq,pts
                    put_frame((seq,pts,frame,received))
                elif message.get('text') is not None:
                    if len(message['text'])>4096:
                        raise ValueError('控制消息过大')
                    command=json.loads(message['text'])
                    kind=command.get('type')
                    if kind=='painted':
                        acknowledge(command.get('seq'),command.get('epoch'))
                    elif kind=='end' and session['source'] is None:
                        input_done.set()
                    elif kind=='stop':
                        stop.set()
                    else:
                        raise ValueError('未知流控制消息')
        except (WebSocketDisconnect,RuntimeError):
            pass
        except Exception as error:
            session['error']=str(error)
        finally:
            stop.set()

    async def source_frames():
        reader=video.acquire_stream_reader(session['source']['uri'],full_rate=True)
        last_id=None
        beginning=None
        last_received=time.monotonic()
        last_health=0.
        try:
            while not stop.is_set():
                frame_id,captured,frame=await run_in_threadpool(reader.read_packet,last_id,.5,stop.is_set)
                if frame is None:
                    if time.monotonic()-last_received > 5 and session['status'] != 'buffering':
                        session['status']='buffering'
                        await run_in_threadpool(db.update_source_status, options.source_id, False)
                        await socket.send_json({'type':'status','status':'buffering'})
                    continue
                last_received=time.monotonic()
                if last_received-last_health > 5:
                    await run_in_threadpool(db.update_source_status, options.source_id, True, db._now())
                    last_health=last_received
                if session['status'] == 'buffering':
                    session['status']='running'
                    await socket.send_json({'type':'status','status':'running'})
                if beginning is None:
                    beginning=captured
                last_id=frame_id
                put_frame((frame_id,captured-beginning,frame,captured))
        except Exception as error:
            fail(error)
        finally:
            reader.release(full_rate=True)

    async def infer_loop():
        try:
            while not stop.is_set():
                try:
                    seq,pts,frame,received,history = await asyncio.wait_for(incoming.get(), timeout=.15)
                except asyncio.TimeoutError:
                    continue
                state['inflight'] += 1
                try:
                    result, context, evidence = await run_in_threadpool(_infer, detector, frame, seq, pts, received, history)
                except BaseException:
                    state['inflight'] -= 1
                    raise
                await results.put((seq, frame, received, result, context, evidence))
        except asyncio.CancelledError:
            raise
        except Exception as error:
            fail(error)

    async def publish_loop():
        last_flush = time.monotonic()
        try:
            while not stop.is_set():
                while not updates.empty():
                    await socket.send_json(updates.get_nowait())
                if trace_lines and time.monotonic()-last_flush >= 1.:
                    lines = trace_lines[:]
                    trace_lines.clear()
                    await run_in_threadpool(_write_trace, trace, lines)
                    last_flush = time.monotonic()
                try:
                    seq, frame, received, result, context, evidence = await asyncio.wait_for(results.get(), timeout=.15)
                except asyncio.TimeoutError:
                    continue
                try:
                    result['metrics']['server_dropped'] = state['dropped']
                    result['metrics']['received_frames'] = state['received']
                    result['metrics']['input_transport'] = transport
                    packet = await run_in_threadpool(_publish_prepare, key, frame, result, received, evidence)
                    if stop.is_set():
                        break
                    record_key = result['epoch'], seq
                    if result['new_events']:
                        pending_red[record_key] = {'events': result['new_events'], 'frames': context,
                                                   'published_at': None, 'acknowledged': False, 'created': time.monotonic()}
                        while len(pending_red) > 8:
                            _, old = pending_red.popitem(last=False)
                            for event in old['events']:
                                description_update({**event, 'description_status': 'not_displayed'})
                    await socket.send_bytes(packet)
                    published = time.monotonic()
                    result['published_at'] = published
                    trace_lines.append(json.dumps(result, ensure_ascii=False)+'\n')
                    if record_key in pending_red:
                        pending_red[record_key]['published_at'] = published
                        if pending_red[record_key]['acknowledged']:
                            acknowledge(seq, result['epoch'])
                    state['processed'] += 1
                    session['processed'] = state['processed']
                    if state['processed'] % 30 == 0:
                        await run_in_threadpool(db.update_task_metrics, key, sampled_frames=state['processed'],
                                                yolo_checked_frames=state['processed'])
                finally:
                    state['inflight'] -= 1
        except asyncio.CancelledError:
            raise
        except (WebSocketDisconnect, RuntimeError):
            stop.set()
        except Exception as error:
            fail(error)

    try:
        from streaming import StreamDetector, EventDescriber
        await socket.send_json({'type':'status','status':'loading_detection_models'})
        models = await run_in_threadpool(_get_models, options)
        detector = StreamDetector(models, fight_threshold=options.fight_threshold, async_action=config.STREAM_ASYNC_ACTION)
        detector.session_id = key
        describer = EventDescriber(description_update, enabled=options.describe and config.VLM_ENABLED)
        if stop.is_set() or not db.update_status(key, config.STATUS_PROCESSING):
            return
        session['status'] = 'running'
        trace_path = config.DATA_DIR/'streams'/key
        trace_path.mkdir(parents=True, exist_ok=False)
        trace = (trace_path/'frames.jsonl').open('w')
        await socket.send_json({'type':'ready','models':models.info,'session_id':key})
        tasks.append(asyncio.create_task(receive()))
        tasks.append(asyncio.create_task(infer_loop()))
        publisher = asyncio.create_task(publish_loop())
        if session['source'] is not None:
            tasks.append(asyncio.create_task(source_frames()))
        ended_at = None
        while not stop.is_set() and not publisher.done():
            await asyncio.sleep(.1)
            now = time.monotonic()
            for record_key, entry in list(pending_red.items()):
                if now-entry['created'] > 15:
                    pending_red.pop(record_key)
                    for event in entry['events']:
                        description_update({**event,'description_status':'not_displayed','description':'未收到红框呈现确认，不调用模型。'})
            if input_done.is_set() and incoming.empty() and state['inflight'] == 0:
                ended_at = ended_at or now
                if (not pending_red and not describer.pending.unfinished_tasks) or now-ended_at > config.VLM_TIMEOUT+5:
                    outcome = config.STATUS_COMPLETED
                    break
        stop.set()
        await asyncio.wait({publisher}, timeout=1.)
        tasks.append(publisher)
        while not updates.empty():
            await socket.send_json(updates.get_nowait())
        if session.get('error'):
            outcome = config.STATUS_FAILED
            db.update_status(key, outcome, session['error'])
            await socket.send_json({'type':'error','error':session['error']})
        await socket.send_json({'type':'end','status':outcome})
    except WebSocketDisconnect:
        pass
    except Exception as error:
        outcome = config.STATUS_FAILED
        db.update_status(key, outcome, str(error))
        try:
            await socket.send_json({'type':'error','error':str(error)})
        except (RuntimeError, WebSocketDisconnect):
            pass
    finally:
        stop.set()
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        if describer is not None:
            await run_in_threadpool(describer.close)
        if 'detector' in locals():
            await run_in_threadpool(detector.close)
        if trace is not None:
            await run_in_threadpool(_write_trace, trace, trace_lines)
            trace.close()
        await run_in_threadpool(db.update_task_metrics, key, sampled_frames=state['processed'],
                                yolo_checked_frames=state['processed'])
        db.update_status(key, outcome)
