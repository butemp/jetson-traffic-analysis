(() => {
  'use strict';
  const { defineComponent, ref, reactive, computed, onMounted, onBeforeUnmount } = window.Vue;
  const LIMIT = 2 * 1024 * 1024;
  window.SafetyStream = defineComponent({
    name: 'SafetyStream',
    props: { initialSourceId: { type: String, default: '' } },
    setup(props) {
      const displayText = window.Presentation.text;
      const mediaHost = ref(null), result = ref(null), file = ref(null), sources = ref([]);
      const monitors = ref([]), streamLimit = ref(null);
      const form = reactive({ persistent: true, mode: props.initialSourceId ? 'source' : 'file', sourceId: props.initialSourceId, scenarios: ['knife', 'fight'], knife_model: 'trained-u8', knife_confidence: .4, fight_threshold: .65, tiled: true, describe: false, edge: 'original', quality: .85 });
      const ui = reactive({ active: false, phase: 'idle', input: '尚未输入', source: '—', resolution: '—', models: null, serverStatus: '', hasFrame: false, seq: null, pts: null, received: 0, sent: 0, rxFps: null, silence: 0, metrics: {}, fightReady: null, browser: 0, encoding: 0, network: 0, events: [], faults: [], sourceLoading: false, sourceError: '' });
      const phases = { idle: '准备就绪', starting: '准备输入 / 创建会话', connecting: '连接服务端', warming: '模型预热 / 等待首帧', running: '结果更新中', draining: '输入结束 · 等待结果与解释', ended: '处理结束 · 保留解释连接', stopped: '已停止', error: '巡检异常', disconnected: '连接已断开', buffering: '输入缓冲中', updating: '结果更新中' };
      const phaseText = computed(() => phases[ui.phase] || ui.phase);
      const modelsText = computed(() => ui.models == null ? '等待检测服务就绪' : typeof ui.models === 'string' ? displayText(ui.models) : Object.values(ui.models).map(item => item.name || '').filter(Boolean).join(' · ') || '检测服务已就绪');
      const canStart = computed(() => !ui.active && form.scenarios.length && (form.mode === 'camera' || (form.mode === 'file' ? !!file.value : sources.value.some(s => s.id === form.sourceId))));
      let live = null, generation = 0, alive = true, sourceAbort = null, encodeOwner = null, deletion = Promise.resolve();
      const valid = s => alive && live === s && s.generation === generation;
      const number = (v, digits = 0) => typeof v === 'number' && Number.isFinite(v) ? v.toFixed(digits) : '—';
      function fault(error) { if (alive) { ui.faults.unshift({ text: displayText(error?.message || error), time: new Date().toLocaleTimeString('zh-CN') }); ui.faults.splice(5); } }
      function removeSession(id) {
        if (id == null) return deletion;
        deletion = deletion.then(async () => {
          const response = await fetch(`/api/streams/${encodeURIComponent(id)}`, { method: 'DELETE', credentials: 'same-origin', keepalive: true });
          if (!response.ok && response.status !== 404) throw new Error(`会话 ${id} 释放失败（HTTP ${response.status}），请确认 计算会话已释放。`);
        }).catch(error => fault(error));
        return deletion;
      }
      function releaseMedia(s) {
        if (s.vfc != null) s.video?.cancelVideoFrameCallback(s.vfc);
        s.vfc = null;
        s.stream?.getTracks().forEach(track => track.stop()); s.stream = null;
        if (s.video) { s.video.pause(); s.video.srcObject = null; s.video.removeAttribute('src'); s.video.load(); s.video.remove(); s.video = null; }
        if (s.url) URL.revokeObjectURL(s.url); s.url = null;
      }
      function stop(phase = 'stopped', terminate = true) {
        const s = live; live = null; generation++; ui.active = false; ui.phase = phase;
        if (!s) return;
        s.abort.abort(); clearInterval(s.timer); cancelAnimationFrame(s.raf);
        s.paintResolve?.(); s.queue.length = 0; releaseMedia(s);
        if (s.ws) {
          s.ws.onopen = s.ws.onmessage = s.ws.onerror = s.ws.onclose = null;
          try { if (terminate && s.ws.readyState === WebSocket.OPEN) s.ws.send(JSON.stringify({ type: 'stop' })); s.ws.close(); } catch (error) { fault(error); }
        }
        if (terminate) removeSession(s.id).then(loadMonitors);
      }
      function fail(s, error, phase = 'error') { if (valid(s)) { fault(error); stop(phase, !s.persistent); loadMonitors(); } }
      async function loadSources() {
        sourceAbort?.abort(); const controller = new AbortController(); sourceAbort = controller;
        ui.sourceLoading = true; ui.sourceError = '';
        try {
          const response = await fetch('/api/sources', { credentials: 'same-origin', signal: controller.signal });
          if (!response.ok) throw new Error(`数据源加载失败（HTTP ${response.status}）`);
          const data = await response.json();
          if (alive && sourceAbort === controller) sources.value = (Array.isArray(data.items) ? data.items : []).filter(s => s.id != null && s.id !== '' && /^(https?|rtsp|rtmp|tcp|udp):/i.test(s.uri || ''));
        } catch (error) { if (alive && !controller.signal.aborted) ui.sourceError = error.message; }
        finally { if (alive && sourceAbort === controller) ui.sourceLoading = false; }
      }
      function dimensions(s) {
        const w = s.video.videoWidth, h = s.video.videoHeight;
        if (!w || !h) throw new Error('输入尚无可解码画面。');
        if (s.edge === 'original' && Math.max(w, h) > 4096) throw new Error('原尺寸模式仅支持长边 ≤4096px；请选择长边 1920px 或更换视频，不会自动缩小原尺寸输入。');
        const scale = s.edge === 'original' ? 1 : Math.min(1, 1920 / Math.max(w, h));
        const width = Math.round(w * scale), height = Math.round(h * scale);
        if (s.canvas.width !== width || s.canvas.height !== height) { s.canvas.width = width; s.canvas.height = height; }
        ui.resolution = `${w}×${h} → ${width}×${height}`;
      }
      function finishInput(s) {
        if (!valid(s) || !s.inputEnded || s.encoding || s.endSent || s.backendEnded) return;
        try {
          s.ws.send(JSON.stringify({ type: 'end' })); s.endSent = true;
          ui.phase = 'draining'; ui.input = '播放结束，已发送输入结束标记'; releaseMedia(s);
        } catch (error) { fail(s, error); }
      }
      function capture(s, metadata) {
        if (!valid(s) || s.inputEnded || s.backendEnded) return;
        // Re-arm before encoding: seq follows presentedFrames, never inference completions.
        s.vfc = s.video.requestVideoFrameCallback((_, next) => capture(s, next));
        const presented = metadata.presentedFrames, pts = metadata.mediaTime;
        if (!Number.isSafeInteger(presented) || presented < 1 || !Number.isFinite(pts) || pts < 0) { fail(s, '浏览器未提供有效的逐帧序号与时间戳。'); return; }
        if (presented <= s.presented) return;
        ui.browser += Math.max(0, presented - s.presented - 1); s.presented = presented;
        if (encodeOwner) { ui.encoding++; return; }
        if (s.ws.bufferedAmount > LIMIT) { ui.network++; ui.input = '网络背压：跳过发送，播放继续'; return; }
        try {
          dimensions(s); s.canvas.getContext('2d').drawImage(s.video, 0, 0, s.canvas.width, s.canvas.height);
          s.encoding = true; encodeOwner = s;
          s.canvas.toBlob(blob => {
            encodeOwner = null; // An old, uncancellable encoder also blocks rapid-restart encodes.
            if (!valid(s)) return;
            try {
              if (!blob) throw new Error('JPEG 编码失败，未将失败帧当作正常结果。');
              if (!s.backendEnded) {
                if (s.ws.readyState !== WebSocket.OPEN) throw new Error('发送帧时连接已断开。');
                if (s.ws.bufferedAmount > LIMIT) ui.network++;
                else {
                  const header = new TextEncoder().encode(JSON.stringify({ seq: presented - 1, pts }));
                  const prefix = new ArrayBuffer(4); new DataView(prefix).setUint32(0, header.byteLength, false);
                  s.ws.send(new Blob([prefix, header, blob])); ui.sent++; ui.input = '顺序播放 / 逐帧发送中';
                }
              }
            } catch (error) { fail(s, error); }
            finally { s.encoding = false; finishInput(s); }
          }, 'image/jpeg', s.quality);
        } catch (error) { encodeOwner = null; s.encoding = false; fail(s, error); }
      }
      async function play(s) {
        if (!valid(s) || !s.video || s.playing) return;
        s.playing = true;
        try { s.vfc = s.video.requestVideoFrameCallback((_, metadata) => capture(s, metadata)); await s.video.play(); }
        catch (error) { fail(s, new Error(`无法播放输入：${error.message}。请检查格式、摄像头权限后重新开始。`)); }
      }
      function mergeEvent(event, painted = false) {
        if (!event || event.id == null) return;
        const index = ui.events.findIndex(e => String(e.id) === String(event.id));
        const previous = index < 0 ? {} : ui.events.splice(index, 1)[0];
        ui.events.unshift(painted ? { ...event, ...previous } : { ...previous, ...event }); ui.events.splice(30);
      }
      async function paint(s) {
        if (s.painting) return; s.painting = true;
        try {
          while (valid(s) && s.queue.length) {
            const { header, jpeg } = s.queue.shift();
            const image = await createImageBitmap(jpeg);
            if (!valid(s)) { image.close(); return; }
            const canvas = result.value;
            try { canvas.width = image.width; canvas.height = image.height; canvas.getContext('2d').drawImage(image, 0, 0); }
            finally { image.close(); }
            ui.hasFrame = true; ui.seq = header.seq; ui.pts = header.pts;
            // Two animation frames leave a paint opportunity between drawing and ACK.
            await new Promise(resolve => { s.paintResolve = resolve; s.raf = requestAnimationFrame(() => { s.raf = requestAnimationFrame(() => { s.paintResolve = null; resolve(); }); }); });
            if (!valid(s)) return;
            if (terminate && s.ws.readyState === WebSocket.OPEN) s.ws.send(JSON.stringify({ type: 'painted', seq: header.seq, epoch: header.epoch }));
            for (const event of header.new_events || []) mergeEvent({ ...event, description_status: s.describe ? 'pending' : 'disabled', trigger_seq: header.seq }, true);
          }
        } catch (error) { fail(s, new Error(`结果呈现失败：${error.message}`)); }
        finally { s.painting = false; if (valid(s) && s.backendEnded && s.socketClosed && !s.queue.length) stop('ended'); }
      }
      function receive(s, data) {
        if (!valid(s)) return;
        try {
          if (typeof data === 'string') {
            const message = JSON.parse(data);
            if (message.type === 'ready') { ui.models = message.models ?? null; ui.serverStatus = '检测模型已就绪'; if (!s.playing) ui.phase = 'warming'; if (s.mode !== 'source') play(s); }
            else if (message.type === 'description') mergeEvent(message.event);
            else if (message.type === 'error') fail(s, typeof message.error === 'string' ? message.error : JSON.stringify(message.error || '服务端处理失败'));
            else if (message.type === 'status') {
              ui.serverStatus = phases[message.status] || message.status;
              if (['error', 'failed', 'disconnected'].includes(message.status)) fail(s, `服务端状态异常：${ui.serverStatus}`);
              else if (phases[message.status] && !s.endSent && !s.backendEnded) ui.phase = message.status;
            } else if (message.type === 'end') {
              if (['error', 'failed'].includes(message.status)) { fail(s, `巡检异常结束：${message.status}`); return; }
              s.backendEnded = true; ui.phase = 'ended'; ui.serverStatus = message.status || 'end'; ui.input = '输入已结束'; releaseMedia(s);
            }
            return;
          }
          if (!(data instanceof ArrayBuffer) || data.byteLength < 5) throw new Error('结果二进制包不完整。');
          const size = new DataView(data).getUint32(0, false);
          if (!size || size > 1024 * 1024 || size + 4 >= data.byteLength) throw new Error('结果头长度无效。');
          const header = JSON.parse(new TextDecoder().decode(new Uint8Array(data, 4, size)));
          if (header.type !== 'frame' || String(header.session_id) !== String(s.id) || !Number.isSafeInteger(header.seq) || header.seq < 0 || header.epoch == null) throw new Error('结果会话或帧标识不匹配。');
          if (s.persistent && s.queue.length >= 8) s.queue.shift();
          if (s.queue.length >= 8) throw new Error('结果显示积压，已停止；不会静默丢弃红框或确认未显示的帧。请保持页面在前台。');
          s.lastFrame = performance.now(); if (s.rxAt == null) s.rxAt = s.lastFrame;
          s.rxCount++; ui.received++; ui.silence = 0; ui.metrics = header.metrics || {}; ui.fightReady = header.diagnostics?.fight_ready ?? null;
          if (s.mode === 'source') { ui.resolution = `${header.width}×${header.height}（服务端输入）`; ui.input = '服务端采集 · 浏览器不上传帧'; }
          if (!s.endSent && !s.backendEnded) { ui.phase = 'running'; ui.serverStatus = '逐帧处理中'; }
          s.queue.push({ header, jpeg: new Blob([new Uint8Array(data, size + 4)], { type: 'image/jpeg' }) }); paint(s);
        } catch (error) { fail(s, error); }
      }
      async function start() {
        if (!canStart.value) return;
        if (![form.knife_confidence, form.fight_threshold, form.quality].every(v => typeof v === 'number' && Number.isFinite(v) && v >= 0 && v <= 1)) { fault('阈值与 JPEG 质量必须是 0–1 之间的有效数值。'); return; }
        stop();
        const s = { generation: ++generation, abort: new AbortController(), mode: form.mode, edge: form.edge, quality: form.quality, describe: form.describe, canvas: document.createElement('canvas'), queue: [], presented: 0, rxCount: 0, rxAt: null, lastFrame: performance.now(), raf: 0 };
        live = s;
        Object.assign(ui, { active: true, phase: 'starting', input: '正在准备输入', source: '', resolution: '—', models: null, serverStatus: '', hasFrame: false, seq: null, pts: null, received: 0, sent: 0, rxFps: null, silence: 0, metrics: {}, fightReady: null, browser: 0, encoding: 0, network: 0, events: [], faults: [] });
        const source = sources.value.find(item => item.id === form.sourceId);
        const payload = { persistent: s.mode === 'source' && form.persistent, name: s.mode === 'file' ? file.value.name : s.mode === 'camera' ? '浏览器摄像头' : source.name, source_id: s.mode === 'source' ? source.id : null, scenarios: [...form.scenarios], knife_model: form.knife_model, knife_confidence: form.knife_confidence, fight_threshold: form.fight_threshold, tiled: form.tiled, describe: s.describe };
        ui.source = payload.name;
        s.timer = setInterval(() => {
          if (!valid(s)) return;
          const now = performance.now(); ui.silence = Math.floor((now - s.lastFrame) / 1000);
          if (s.rxAt != null && now - s.rxAt >= 1000) { ui.rxFps = s.rxCount * 1000 / (now - s.rxAt); s.rxAt = now; s.rxCount = 0; }
        }, 1000);
        try {
          if (s.mode !== 'source') {
            const video = document.createElement('video'); s.video = video;
            if (!video.requestVideoFrameCallback || !window.createImageBitmap) throw new Error('此浏览器缺少逐帧回调或图像解码能力，请使用支持逐帧处理的新版浏览器；不会退回定时采样。');
            video.muted = true; video.playsInline = true; video.preload = 'auto'; mediaHost.value.appendChild(video);
            video.addEventListener('error', () => fail(s, `输入解码失败（${video.error?.code || '未知错误'}），请检查视频格式。`), { signal: s.abort.signal });
            for (const type of ['waiting', 'stalled']) video.addEventListener(type, () => { if (valid(s)) ui.input = '输入缓冲中，等待视频帧'; }, { signal: s.abort.signal });
            video.addEventListener('ended', () => { s.inputEnded = true; if (valid(s)) { ui.input = '播放结束，等待最后一帧编码'; finishInput(s); } }, { signal: s.abort.signal });
            if (s.mode === 'camera') {
              if (!navigator.mediaDevices?.getUserMedia) throw new Error('摄像头需要 HTTPS 或 localhost，以及浏览器授权。');
              ui.input = '等待摄像头授权（仅本次点击触发）';
              const stream = await navigator.mediaDevices.getUserMedia({ video: { width: { ideal: s.edge === 'original' ? 3840 : 1920 }, height: { ideal: s.edge === 'original' ? 2160 : 1080 } }, audio: false });
              if (!valid(s)) { stream.getTracks().forEach(track => track.stop()); return; }
              s.stream = stream; video.srcObject = stream;
              stream.getVideoTracks().forEach(track => track.addEventListener('ended', () => fail(s, '摄像头已断开或授权已撤销。'), { signal: s.abort.signal }));
            } else { s.url = URL.createObjectURL(file.value); video.src = s.url; }
            if (video.readyState < 1) await new Promise((resolve, reject) => {
              video.addEventListener('loadedmetadata', resolve, { once: true, signal: s.abort.signal });
              s.abort.signal.addEventListener('abort', () => reject(new DOMException('已取消', 'AbortError')), { once: true });
            });
            if (!valid(s)) return; dimensions(s);
          }
          ui.input = '等待上一会话释放 / 创建 计算会话'; await deletion;
          if (!valid(s)) return;
          const response = await fetch('/api/streams', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload), signal: s.abort.signal });
          if ([409, 429].includes(response.status)) { const detail = await response.json(); throw new Error(detail.detail || '巡检资源已占用，请恢复已有任务或停止后重试。'); }
          if (!response.ok) throw new Error(`创建巡检失败（HTTP ${response.status}）：${(await response.text()).slice(0, 240)}`);
          const created = await response.json();
          if (!valid(s)) { removeSession(created.id); return; }
          s.id = created.id; s.persistent = !!created.persistent; if (s.id == null || !created.ws_path) throw new Error('创建接口未返回会话 id 或 ws_path。');
          connect(s, created.ws_path);
          await loadMonitors();
        } catch (error) {
          const mediaErrors = { NotAllowedError: '未获摄像头或播放权限，请在浏览器中授权后重新开始。', NotFoundError: '未发现可用摄像头，请连接设备或选择本地视频。', NotReadableError: '无法读取摄像头，可能被其他程序占用。' };
          if (valid(s)) fail(s, mediaErrors[error.name] || error);
        }
      }
      function connect(s, path) {
          const url = new URL(path, location.href);
          if (url.origin !== location.origin || url.username || url.password) throw new Error('拒绝连接非同源巡检 WebSocket。');
          url.protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
          const ws = new WebSocket(url); s.ws = ws; ws.binaryType = 'arraybuffer'; ui.phase = 'connecting'; ui.input = s.mode === 'source' ? '等待服务端采集（不上传帧）' : '输入已准备，等待模型就绪';
          ws.onopen = () => { if (valid(s)) ui.phase = 'warming'; };
          ws.onmessage = event => receive(s, event.data);
          ws.onerror = () => fail(s, 'WebSocket 连接异常，请检查登录状态与服务端。', 'disconnected');
          ws.onclose = event => { if (valid(s)) { if (s.backendEnded) { s.socketClosed = true; if (!s.painting && !s.queue.length) stop('ended'); } else fail(s, `连接意外断开（${event.code}）；未完成解释不代表正常。`, 'disconnected'); } };
      }
      async function loadMonitors() {
        try {
          const response = await fetch('/api/streams');
          if (!response.ok) throw new Error('无法加载后台巡检状态');
          const data = await response.json();
          if (!alive) return;
          monitors.value = (data.items || []).filter(item => item.persistent);
          streamLimit.value = data.max_streams;
        } catch (error) { fault(error); }
      }
      async function resumeMonitor(item) {
        if (live) stop('disconnected', !live.persistent);
        form.mode = 'source'; form.sourceId = item.source_id;
        const s = { generation: ++generation, abort: new AbortController(), mode: 'source', persistent: true,
          describe: item.describe, id: item.id, queue: [], rxCount: 0, rxAt: null, lastFrame: performance.now(), raf: 0 };
        live = s;
        Object.assign(ui, { active: true, phase: 'connecting', source: item.name, events: [], faults: [], hasFrame: false, received: 0 });
        try {
          const response = await fetch('/api/streams/' + encodeURIComponent(item.id));
          if (!response.ok) throw new Error('后台任务已结束，请刷新列表');
          const data = await response.json();
          if (!valid(s)) return;
          ui.events = (data.events || []).slice(-30).reverse();
          connect(s, '/api/streams/' + encodeURIComponent(item.id) + '/ws');
          s.timer = setInterval(() => {
            if (!valid(s)) return;
            const now = performance.now(); ui.silence = Math.floor((now - s.lastFrame) / 1000);
            if (s.rxAt != null && now - s.rxAt >= 1000) { ui.rxFps = s.rxCount * 1000 / (now - s.rxAt); s.rxAt = now; s.rxCount = 0; }
          }, 1000);
        } catch (error) { fail(s, error); }
      }
      async function stopMonitor(item) {
        if (live?.id === item.id) stop();
        else await removeSession(item.id);
        await loadMonitors();
      }
      function descriptionLabel(event) {
        const status = event.description_status;
        if (!ui.active && ['pending', 'running'].includes(status)) return '解释已中断 · 需人工复核';
        return ({ pending: '红框已呈现 · 等待解释', running: '正在生成解释', ready: '解释已返回 · 待复核', failed: '解释失败 · 不是正常结论', disabled: '未启用解释 · 待复核', skipped_busy: '解释服务忙，已跳过 · 待复核' })[status] || '解释状态待确认';
      }
      onMounted(() => { loadSources(); loadMonitors(); });
      onBeforeUnmount(() => { alive = false; sourceAbort?.abort(); stop('disconnected', !live?.persistent); file.value = null; });
      return { displayText, monitors, streamLimit, loadMonitors, resumeMonitor, stopMonitor, mediaHost, result, file, sources, form, ui, canStart, phaseText, modelsText, number, start, stop, loadSources, descriptionLabel, selectFile: event => { file.value = event.target.files?.[0] || null; } };
    },
    template: `
      <section class="safety-view" aria-label="逐帧安全巡检">
        <header class="safety-header"><div><div class="safety-eyebrow">连续视频输入 / 候选事件复核</div><h1 class="safety-title">逐帧安全巡检</h1><p class="safety-subtitle">按实际播放顺序检测，只呈现服务端返回的同帧结果。</p></div><span class="safety-state" :data-state="ui.phase" role="status">{{ displayText(phaseText) }}</span></header>
        <div class="safety-notice"><strong>任何可见刀具都纳入候选，包括做饭备菜。</strong> 同时关注疑似打斗；红框仅表示候选，无候选时不绘框。结果需人工复核，不作违法性判断。</div>
        <div class="safety-panel"><b>后台巡检</b> <button class="safety-button" @click="loadMonitors">刷新状态</button>
          <p v-if="!monitors.length">暂无后台巡检任务。</p>
          <div v-for="item in monitors" :key="item.id">{{ displayText(item.name) }} · {{ displayText(item.status) }} · 已处理 {{ displayText(item.processed) }} 帧
            <button class="safety-button" @click="resumeMonitor(item)">恢复查看</button>
            <button class="safety-button" @click="stopMonitor(item)">停止任务</button>
          </div>
        </div>
        <section class="safety-panel safety-controls" aria-label="输入与检测设置">
          <fieldset class="safety-fieldset" :disabled="ui.active">
            <legend class="safety-section-title">01 / 选择输入</legend>
            <div class="safety-source-tabs"><label><input type="radio" v-model="form.mode" value="file"> 本地视频</label><label><input type="radio" v-model="form.mode" value="camera"> 浏览器摄像头</label><label><input type="radio" v-model="form.mode" value="source"> 已登记数据源</label></div>
            <label v-if="form.mode === 'file'" class="safety-file">选择视频文件<input type="file" accept="video/*" @change="selectFile"><span class="safety-hint">{{ displayText(file ? file.name : '文件只在浏览器顺序播放，不上传整段文件、不提前跳转抽帧。') }}</span></label>
            <p v-else-if="form.mode === 'camera'" class="safety-hint">点击「开始巡检」时才请求摄像头权限；不采集音频。原始预览隐藏，不影响逐帧播放。</p>
            <div v-else class="safety-source-select"><label class="safety-field">已登记数据源<select v-model="form.sourceId"><option value="" disabled>请选择数据源</option><option v-for="source in sources" :key="source.id" :value="source.id">{{ displayText(source.name) }} · {{ displayText(source.kind) }}</option></select></label><button class="safety-button" type="button" @click="loadSources" :disabled="ui.sourceLoading">{{ displayText(ui.sourceLoading ? '加载中…' : '刷新列表') }}</button><p class="safety-hint">由服务端采集；浏览器不发送 JPEG。不支持手填任意地址。</p><p v-if="ui.sourceError" class="safety-error-text" role="alert">{{ displayText(ui.sourceError) }}</p><p v-else-if="!ui.sourceLoading && !sources.length" class="safety-hint">暂无已登记数据源，可使用本地视频或浏览器摄像头。</p></div>
            <p v-if="form.mode === 'source'" class="safety-hint"><label><input type="checkbox" v-model="form.persistent">后台持续检测（关闭网页后继续；设备或服务重启后需重新启动）</label></p>
            <div class="safety-options"><span class="safety-label">检测内容</span><label><input type="checkbox" v-model="form.scenarios" value="knife"> 可见刀具</label><label><input type="checkbox" v-model="form.scenarios" value="fight"> 疑似打斗</label><label class="safety-description-option"><input type="checkbox" v-model="form.describe"> 生成事件解释</label></div>
            <details class="safety-advanced"><summary>高级设置 <span>输入清晰度、阈值与检测方案</span></summary><div class="safety-settings-grid">
              <label class="safety-field">刀具检测方案<select v-model="form.knife_model"><option value="rtdetr">候选方案 · 验证中</option><option value="yolo">基础方案 · 对照</option><option value="trained">轻量方案 · 对照</option><option value="trained-u8">加速方案 · 推荐</option></select></label>
              <label class="safety-field">分析帧尺寸<select v-model="form.edge" :disabled="form.mode === 'source'"><option value="1920">长边最多 1920px（不放大）</option><option value="original">原尺寸 · 长边 ≤4096px</option></select></label>
              <label class="safety-field">JPEG 质量 {{ displayText(number(form.quality, 2)) }}<input type="range" min="0.5" max="1" step="0.01" v-model.number="form.quality" :disabled="form.mode === 'source'"></label>
              <label class="safety-field">刀具置信度<input type="number" min="0" max="1" step="0.05" v-model.number="form.knife_confidence"></label>
              <label class="safety-field">打斗阈值<input type="number" min="0" max="1" step="0.05" v-model.number="form.fight_threshold"></label>
              <label class="safety-check"><input type="checkbox" v-model="form.tiled"> 启用切片检测</label>
            </div><p class="safety-hint">细小刀具建议保留原尺寸。高置信度即时标记，低置信度需短时跨帧支持；极短或模糊目标仍可能遗漏。超过 4K 明确拒绝，不静默缩小。</p></details>
          </fieldset>
          <div class="safety-actions"><button class="safety-button safety-primary" type="button" :disabled="!canStart" @click="start">开始巡检</button><button class="safety-button safety-stop" type="button" :disabled="!ui.active" @click="stop()">停止并释放</button><span class="safety-hint">最多 {{ displayText(streamLimit == null ? "—" : streamLimit) }} 路巡检 · 网络源可后台运行；本地视频随页面结束</span></div>
          <p class="safety-input-policy">{{ displayText(form.mode === 'source' ? '服务端采集模式：无客户端帧上传。' : (form.edge === 'original' ? '当前分析输入：原尺寸（≤4096px）' : '当前分析输入：长边上限 1920px（超过将等比缩小）') + ' · JPEG ' + number(form.quality, 2) + ' · 原始视频预览隐藏，播放持续进行。') }}</p>
        </section>
        <div v-if="ui.faults.length" class="safety-faults" role="alert"><div v-for="(item, index) in ui.faults" :key="index"><time>{{ displayText(item.time) }}</time><span>{{ displayText(item.text) }}</span></div></div>
        <div class="safety-metrics">
          <div class="safety-metric safety-input-metric"><span>输入 / 分析分辨率</span><strong>{{ displayText(ui.resolution) }}</strong><small :title="displayText(ui.source)">{{ displayText(ui.source) }}</small></div>
          <div class="safety-metric"><span>处理速率</span><strong>{{ displayText(number(ui.metrics.processing_fps, 1)) }} <small>FPS</small></strong><small>实际收到 {{ displayText(number(ui.rxFps, 1)) }} FPS · {{ displayText(ui.received) }} 帧</small></div>
          <div class="safety-metric"><span>单帧处理</span><strong>{{ displayText(number(ui.metrics.processing_ms)) }} <small>ms</small></strong><small>服务端已处理 {{ displayText(number(ui.metrics.processed)) }} 帧</small></div>
          <div class="safety-metric"><span>帧龄</span><strong>{{ displayText(number(ui.metrics.frame_age_ms)) }} <small>ms</small></strong><small>服务端返回的帧龄</small></div>
          <div class="safety-metric"><span>跳过 / 丢弃</span><strong>{{ displayText(form.mode === 'source' ? number(ui.metrics.source_skipped) : ui.browser + ui.encoding + ui.network) }} <small>帧</small></strong><small>{{ displayText(form.mode === 'source' ? '服务端源跳过' : '客户端跳过（分项见下方）') }}</small></div>
        </div>
        <div class="safety-workspace">
          <section class="safety-panel safety-result-panel"><div class="safety-panel-head"><h2>02 / 同帧检测结果</h2><span class="safety-live-label">{{ displayText(ui.hasFrame ? '服务端标注画面' : '等待有效结果') }}</span></div>
            <div class="safety-screen"><canvas ref="result" v-show="ui.hasFrame" class="safety-canvas" width="1280" height="720" aria-label="服务端返回的同帧红框候选画面"></canvas><div v-if="!ui.hasFrame" class="safety-empty"><span class="safety-empty-mark" aria-hidden="true">[ · ]</span><strong>{{ displayText(ui.active ? phaseText : '尚无检测画面') }}</strong><p>{{ displayText(ui.active ? '等待服务端处理后返回图像；空白不代表检测正常。' : '选择输入并开始巡检。这里不显示未检测的原始视频。') }}</p></div></div>
            <div class="safety-frame-meta"><span>帧序号 <b>{{ displayText(ui.seq ?? '—') }}</b></span><span>媒体时间 <b>{{ displayText(number(ui.pts, 3)) }} s</b></span><span class="safety-red-key">红框 = 候选，非定论</span></div>
            <div class="safety-runtime" role="status"><strong>{{ displayText(phaseText) }}</strong><span>{{ displayText(ui.input) }}</span><span v-if="ui.serverStatus">服务端：{{ displayText(ui.serverStatus) }}</span><span v-if="ui.active && ui.silence >= 5" class="safety-warn-text">已 {{ displayText(ui.silence) }} 秒未收到新结果。可能仍在预热、缓冲或处理中；请保持页面前台，这不是正常结论。</span><span v-if="form.scenarios.includes('fight')">打斗时序窗口：{{ displayText(ui.fightReady === true ? '已就绪' : ui.fightReady === false ? '积累帧 / 预热中' : '等待诊断') }}</span></div>
            <div class="safety-models"><span>检测能力</span><code>{{ displayText(modelsText) }}</code></div>
            <p class="safety-counters">浏览器漏回调 {{ displayText(ui.browser) }} · 编码忙跳过 {{ displayText(ui.encoding) }} · 网络背压跳过 {{ displayText(ui.network) }} · 已发送 {{ displayText(ui.sent) }}<br>服务端源跳过 {{ displayText(number(ui.metrics.source_skipped)) }} · 服务端丢弃 {{ displayText(number(ui.metrics.server_dropped)) }}（不同层级不累加）</p>
          </section>
          <aside class="safety-panel safety-events-panel"><div class="safety-panel-head"><h2>03 / 候选事件</h2><span>最近 {{ displayText(ui.events.length) }} / 30</span></div><p class="safety-events-note">红框实际呈现并确认后才触发解释。解释失败或忙碌跳过，均不能视为正常。</p>
            <div v-if="!ui.events.length" class="safety-events-empty"><strong>尚无候选事件记录</strong><p>{{ displayText(ui.hasFrame ? '仅表示目前尚未收到事件，不保证没有遗漏。' : '事件将在检测画面返回并呈现后出现。') }}</p></div>
            <ol v-else class="safety-event-list"><li v-for="event in ui.events" :key="event.id" class="safety-event"><div class="safety-event-head"><strong>{{ displayText(event.kind === 'knife' ? '可见刀具候选' : event.kind === 'fight' ? '疑似打斗候选' : event.kind || '待复核候选') }}</strong><span>#{{ displayText(event.trigger_seq ?? '—') }}</span></div><div class="safety-event-state" :data-state="event.description_status">{{ displayText(descriptionLabel(event)) }}</div><p v-if="event.description" class="safety-event-description">{{ displayText(event.description) }}</p><p v-if="event.uncertainty" class="safety-warn-text">不确定性：{{ displayText(event.uncertainty) }}</p><p v-if="event.error" class="safety-error-text">{{ displayText(event.error) }}</p><small class="safety-event-id">事件 {{ displayText(event.id) }}<br v-if="event.published_at"><span v-if="event.published_at">发布时间 {{ displayText(event.published_at) }}</span></small></li></ol>
          </aside>
        </div>
        <div ref="mediaHost" class="safety-source-host" aria-hidden="true"></div>
      </section>`
  });
})();
