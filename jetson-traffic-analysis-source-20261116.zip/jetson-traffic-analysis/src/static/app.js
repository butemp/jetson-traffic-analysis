const { createApp, ref, reactive, computed, watch, onMounted, onBeforeUnmount } = Vue;

createApp({
  components: { SafetyStream: window.SafetyStream, TrafficReasoning: window.TrafficReasoning },
  template: "#app-tpl",
  setup() {
    const displayText = window.Presentation.text, displayCell = window.Presentation.cell;
    const authed = ref(false);
    const authDisabled = ref(false);
    const user = ref("");
    const loginForm = reactive({ user: "admin", pass: "", loading: false, err: "" });
    const cfg = ref({ poll_interval_sec: 1.5, event_color: {}, level_color: {}, level_label: {}, max_upload_mb: 500, max_concurrent_analysis: 1, map_provider: "", amap_js_key: "", amap_security_code: "", vlm_enabled: false });
    const currentClock = ref("");
    const serverClockWarning = ref("");
    const dashboardError = ref("");
    const sourcesError = ref("");
    const clockStatus=ref({quality:'not_configured'});
    let clockStatusTimer=null;
    const clockStatusText=computed(()=>({verified_mac:'已与本机时间源同步',verified_ntp:'已与网络时间源同步',holdover:'时间源暂不可达，沿用本次开机已校准时间',saved_time_only:'仅恢复最近可信时间，等待校准',unsynchronized:'设备时间尚未校准',not_configured:'自动校时服务尚未配置'}[clockStatus.value.quality] || '校时状态待确认'));
    async function loadClockStatus() {
      try { clockStatus.value=await (await api('/api/system/time-status')).json(); }
      catch { clockStatus.value={quality:'unavailable'}; }
    }
    let clockTimer = null;

    const view = ref("dashboard");
    const rvStats = reactive({ pending: 0 });
    const alertStats = reactive({ active: 0, today: 0 });
    const unread = ref(0);

    const sidebarCollapsed = ref(window.innerWidth <= 820);
    const mobileNavigation = window.matchMedia('(max-width: 820px)');
    const closeMobileNavigation = () => { if (mobileNavigation.matches) sidebarCollapsed.value = true; };
    const openTabs = ref([{ k: "dashboard", t: "首页大屏" }]);
    const menuTree = [
      { k: "dashboard", t: "首页大屏", icon: "📊" },
      { k: "sources", t: "数据源管理", icon: "🎥" },
      { k: "safety", t: "逐帧安全巡检", icon: "▣" },
      { title: "算法管理", icon: "🧠", children: [
        { k: "presets", t: "智能体库" },
        { k: "det-tasks", t: "零样本任务" },
        { k: "filters", t: "误报优化" },
        { k: "runs", t: "运行记录" },
      ] },
      { title: "告警与复审", icon: "🚨", children: [
        { k: "alerts", t: "告警中心" },
        { k: "review", t: "复审任务" },
        { k: "samples", t: "误报优化" },
      ] },
      { k: "gallery", t: "底库管理", icon: "📦" },
      { title: "分析工具", icon: "📈", children: [
        { k: "reports", t: "报表中心" },
        { k: "benchmark", t: "准确率评测" },
        { k: "stress", t: "压力测试" },
        { k: "emergency", t: "应急指挥" },
      ] },
      { title: "系统管理", icon: "⚙️", children: [
        { k: "appearance", t: "外观与时间" },
        { k: "users", t: "用户管理" },
        { k: "audit", t: "审计日志" },
        { k: "storage", t: "存储管理" },
      ] },
    ];
    const _tabTitle = { dashboard: "首页大屏", sources: "数据源管理", safety: "逐帧安全巡检", presets: "智能体库", "det-tasks": "零样本任务", filters: "误报优化", runs: "运行记录", alerts: "告警中心", review: "复审任务", gallery: "底库管理", samples: "样本回流", reports: "报表中心", benchmark: "准确率评测", stress: "压力测试", emergency: "应急指挥", users: "用户管理", audit: "审计日志", storage: "存储管理" };
    _tabTitle.appearance='外观与时间';
    const TAB_KEY='traffic.ui.tabs.v1', APPEARANCE_KEY='traffic.ui.appearance.v1';
    const draggedTab=ref('');
    function saveTabOrder() { try {localStorage.setItem(TAB_KEY,JSON.stringify(openTabs.value.map(t=>t.k)));} catch {} }
    try {
      const stored=JSON.parse(localStorage.getItem(TAB_KEY)||'null');
      if (Array.isArray(stored)) {
        const keys=[...new Set(stored.filter(k=>Object.hasOwn(_tabTitle,k)))];
        if (!keys.includes('dashboard')) keys.unshift('dashboard');
        openTabs.value=keys.map(k=>({k,t:_tabTitle[k]}));
      }
    } catch {}
    watch(openTabs,saveTabOrder,{deep:true});
    function moveTab(key,target) {
      const from=openTabs.value.findIndex(t=>t.k===key),to=openTabs.value.findIndex(t=>t.k===target);
      if (from<0||to<0||from===to) return;
      const next=[...openTabs.value];const [tab]=next.splice(from,1);next.splice(to,0,tab);
      openTabs.value=next;saveTabOrder();
    }
    function shiftTab(key,delta) {
      const index=openTabs.value.findIndex(t=>t.k===key),target=openTabs.value[index+delta];
      if (target) moveTab(key,target.k);
    }
    function startTabDrag(event,key) {draggedTab.value=key;event.dataTransfer?.setData('text/plain',key);}
    function dropTab(target) {if(draggedTab.value)moveTab(draggedTab.value,target);draggedTab.value='';}
    const appearanceDefaults={theme:'navy',accent:'#22d3ee',background:''};
    const themeOptions=[{value:'navy',label:'深蓝',bg:'#03101f',panel:'rgba(4,20,38,.92)'},{value:'slate',label:'石墨',bg:'#171b24',panel:'rgba(31,36,46,.94)'},{value:'forest',label:'墨绿',bg:'#071c18',panel:'rgba(10,35,29,.94)'}];
    const accentOptions=[{value:'#22d3ee',label:'青蓝'},{value:'#a78bfa',label:'浅紫'},{value:'#fbbf24',label:'金黄'},{value:'#6ee7b7',label:'薄荷绿'}];
    function cleanAppearance(value) {
      const v=value&&typeof value==='object'?value:{};
      return {theme:themeOptions.some(t=>t.value===v.theme)?v.theme:'navy',accent:accentOptions.some(a=>a.value===v.accent)?v.accent:'#22d3ee',
        background:typeof v.background==='string'&&v.background.length<=3000000&&/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(v.background)?v.background:''};
    }
    let savedAppearance={};try{savedAppearance=JSON.parse(localStorage.getItem(APPEARANCE_KEY)||'{}')}catch{}
    const appearance=reactive(cleanAppearance(savedAppearance));
    function applyAppearance() {
      if (typeof document==='undefined') return;
      const clean=cleanAppearance(appearance),theme=themeOptions.find(t=>t.value===clean.theme),style=document.documentElement.style;
      document.documentElement.setAttribute('data-traffic-theme',clean.theme);
      for(const [key,value] of Object.entries({'--workspace-bg':theme.bg,'--workspace-panel':theme.panel,'--cyan':clean.accent,'--el-color-primary':clean.accent,'--user-background':clean.background?'url("'+clean.background+'")':'none'}))style.setProperty(key,value);
    }
    watch(appearance,applyAppearance,{deep:true});applyAppearance();
    function saveAppearance() {
      try{localStorage.setItem(APPEARANCE_KEY,JSON.stringify(cleanAppearance(appearance)));ElementPlus.ElMessage.success('已保存到此浏览器');}
      catch{ElementPlus.ElMessage.error('浏览器存储空间不足，当前预览尚未保存');}
    }
    function resetAppearance() {Object.assign(appearance,appearanceDefaults);applyAppearance();saveAppearance();}
    function pickBackground(event) {
      const file=event.target.files?.[0];event.target.value='';if(!file)return;
      if(!['image/png','image/jpeg','image/webp'].includes(file.type)||file.size>2*1024*1024){ElementPlus.ElMessage.error('请选择不超过2MB的PNG、JPEG或WebP图片');return;}
      const reader=new FileReader();reader.onerror=()=>ElementPlus.ElMessage.error('图片读取失败');
      reader.onload=()=>{const picture=new Image();picture.onerror=()=>ElementPlus.ElMessage.error('无法解码图片');picture.onload=()=>{
        if(Math.max(picture.width,picture.height)>4096){ElementPlus.ElMessage.error('图片长边不能超过4096像素');return;}
        appearance.background=String(reader.result);
      };picture.src=String(reader.result);};reader.readAsDataURL(file);
    }
    function badgeFor(k) {
      if (k === "alerts") return alertStats.active || 0;
      if (k === "review") return rvStats.pending || 0;
      return 0;
    }
    function closeTab(k) {
      const i = openTabs.value.findIndex(t => t.k === k);
      if (i < 0) return;
      openTabs.value.splice(i, 1);
      if (view.value === k) {
        const next = openTabs.value[i] || openTabs.value[i - 1] || { k: "dashboard" };
        switchView(next.k);
      }
    }
    function onMenuSelect(k) { switchView(k); if (window.innerWidth <= 820) sidebarCollapsed.value = true; }

    // 大屏
    const dash = ref({ sources: 0, online_sources: 0, tasks: 0, events_today: 0, pending_review: 0, alerts_active: 0, alerts_today: 0, source_cards: [], recent_alerts: [] });
    const gpu = ref({ util_pct: null, mem_used_mb: null, mem_total_mb: null });
    const gpuUtilPct = computed(() => Math.max(0, Math.min(100, Number(gpu.value.util_pct) || 0)));
    const gpuMemPct = computed(() => {
      const total = Number(gpu.value.mem_total_mb) || 0;
      const used = Number(gpu.value.mem_used_mb) || 0;
      return total ? Math.max(0, Math.min(100, Math.round(used / total * 100))) : 0;
    });
    let gpuTimer = null;
    async function loadGpu() { try { gpu.value = await (await api("/api/gpu")).json(); } catch (e) {} }
    function startGpuPoll() { loadGpu(); if (gpuTimer === null) gpuTimer = setInterval(loadGpu, 3000); }
    function stopGpuPoll() { if (gpuTimer !== null) { clearInterval(gpuTimer); gpuTimer = null; } }
    const dashboardMapMode = ref("risk");
    const aiQuestion = ref("今日风险最高的数据源是哪里？");
    const aiAnswer = ref("系统将根据活跃告警、待复核数量与事件密度综合排序，优先推送异常源。");
    const amapEl = ref(null);
    const amapReady = ref(false);
    const amapLoading = ref(false);
    const amapError = ref("");
    const tileFallbackReady = ref(false);
    const tileFallbackProvider = ref("amap");
    const tileFallbackNonce = ref(0);
    let tileFallbackErrors = 0;
    let amapMap = null;
    let amapContainer = null;
    let amapTrafficLayer = null;
    let amapMarkers = [];
    let amapSdkPromise = null;
    // 数据源
    const sourcesItems = ref([]);
    const srcDlg = ref(false);
    const safetySourceId = ref("");
    const sourceKindOptions = [
      { label: "RTSP 摄像头", value: "rtsp" },
      { label: "RTMP 直播", value: "rtmp" },
      { label: "HTTP/MP4 流", value: "http" },
      { label: "本地文件", value: "file" },
    ];
    const cameraSampleUrl = "http://43.143.164.58:8080/rtp/41010500002000000001_41010500002000000001.live.mp4?originTypeStr=rtp_push&videoCodec=H265";
    const srcForm = reactive({ name: "", kind: "rtsp", uri: "", lat: null, lng: null, address: "" });
    const srcEditing = ref(null);
    // 检测任务
    const detTasks = ref([]);
    const taskDlg = ref(false);
    const taskForm = reactive({ name: "", status: "enabled", target_objects: [], prompt: "", require_review: true, interval_sec: null, gallery_ids: [] });
    const objectPresets = ["车辆", "非机动车", "障碍物", "烟火", "明火", "交通事故", "逆行", "拥堵"];
    const runDlg = ref(false);
    const runForm = reactive({ source_id: "", det_task_id: "", uri: "", name: "", kind: "rtsp", lat: null, lng: null, address: "" });
    const UPLOAD_TASK_KEY = "qjw.uploadTask";
    const uploadTask = ref("");
    watch(uploadTask, v => { try { localStorage.setItem(UPLOAD_TASK_KEY, v); } catch (e) {} });
    // 逐帧刀具与斗殴巡检模式下，首页大屏切换为公安版文案
    const safetyMode = computed(() => uploadTask.value === "safety-stream");
    const brandTitle = computed(() => safetyMode.value ? "公安逐帧刀具与斗殴智能巡检系统" : "城市交通智能体指挥中枢");
    const brandBadge = computed(() => safetyMode.value ? "公安视觉智能体" : "交通视觉智能体");
    const dashTitle = computed(() => safetyMode.value ? "城市公安全域智能体指挥中枢" : "城市交通全域智能体指挥中枢");
    const presetsItems = ref([]);
    const PRESET_SKILLS = {
      preset01: ["区域感知", "行为分析", "滞留判定"],
      preset02: ["区域警戒", "入侵检测", "轨迹分析"],
      preset03: ["人群计数", "密度分析", "聚集识别"],
      preset04: ["岗位监测", "在岗识别", "异常告警"],
      preset05: ["视觉识别", "多模态融合", "L3应急联动"],
      preset06: ["物体识别", "异常检测", "占道分析"],
      preset07: ["行为识别", "区域警戒", "翻越判定"],
      preset08: ["目标识别", "区域管制", "实时告警"],
      preset09: ["装备识别", "合规检测", "工地管控"],
      preset10: ["行为识别", "禁区管控", "吸烟判定"],
      preset11: ["行为识别", "分心检测", "作业违规"],
      preset12: ["异物识别", "占道分析", "消防管控"],
      preset13: ["目标识别", "风险预警", "楼宇管控"],
      preset14: ["状态识别", "环境监测", "满溢判定"],
    };
    const skillsFor = (id) => PRESET_SKILLS[id] || ["视觉识别", "实时告警"];
    const filterRules = ref([]), filterStats = reactive({ total: 0, enabled: 0, hits: 0, by_type: [] });
    const filterDlg = ref(false);
    const filterForm = reactive({ name: "", rule_type: "confidence", scope: "global", enabled: true, det_task_id: "", source_id: "", params_text: "{\"min\":\"中\"}" });
    // 告警
    const alertItems = ref([]);
    const alertFilter = reactive({ status: "active" });
    // 运行
    const tasks = ref([]), curTask = ref(null), curEvents = ref([]), uploading = ref(false);
    const vlmLog = ref([]);
    const vlmRawOpen = ref(false);
    const vlmLogOpen = reactive({});
    function vlmSummary(text) {
      if (!text) return "";
      const body = String(text).trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
      try {
        const o = JSON.parse(body);
        if (o && typeof o.description === "string") return o.description + (o.uncertainty ? "；疑点：" + o.uncertainty : "");
      } catch (e) {}
      return String(text).replace(/^<模型输出解析失败>:\s*/, "");
    }
    function vlmTag(l) {
      const status = (l && l.status) || "";
      if (status === "error") return { label: "解析异常", type: "danger", effect: "plain" };
      if (status === "skipped" || status === "disabled") return { label: "未调用", type: "info", effect: "plain" };
      const t = (l && l.event_type) || "Normal";
      if (t === "Normal") return { label: "正常", type: "success", effect: "plain" };
      if (t === "UNKNOWN") return { label: "待复核", type: "warning", effect: "plain" };
      const c = evtColor(t);
      return { label: t, type: (c === "info" || c === "success") ? "danger" : c, effect: "dark" };
    }
    const vlmLogGroups = computed(() => {
      const groups = [];
      const described = new Set(vlmLog.value.filter(l => l.status === "called" || l.status === "error").map(l => l.ts + "|" + l.event_type));
      for (const raw of vlmLog.value) {
        if (raw.status === "detected" && described.has(raw.ts + "|" + raw.event_type)) continue;
        const l = { ...raw, summary: raw.summary || vlmSummary(raw.output) };
        const key = (l.status || "") + "|" + (l.event_type || "");
        const g = groups[groups.length - 1];
        if (g && g.key === key) { g.items.push(l); g.from = l.ts; g.id = l.t + "@" + l.ts; }
        else groups.push({ key, id: l.t + "@" + l.ts, latest: l, items: [l], from: l.ts, to: l.ts, tag: vlmTag(l) });
      }
      return groups;
    });
    const vlmLogStats = computed(() => {
      const called = vlmLog.value.filter(l => l.status === "called");
      const detected = vlmLog.value.filter(l => l.status === "detected").length;
      const events = detected || called.filter(l => l.has_event || (l.event_type && !["Normal", "UNKNOWN"].includes(l.event_type))).length;
      const lat = called.map(l => l.latency_ms).filter(v => typeof v === "number");
      return { total: vlmLog.value.length, called: called.length, events, detected,
               avg: lat.length ? (lat.reduce((a, b) => a + b, 0) / lat.length / 1000).toFixed(1) : null };
    });
    function toggleVlmGroup(g) { if (g.items.length > 1) vlmLogOpen[g.id] = !vlmLogOpen[g.id]; }
    const taskMedia = reactive({ localUrl: "", nativeUrl: "", proxyUrl: "" });
    let taskTimer = null;
    let taskPollSeq = 0;
    let taskGeneration = 0;
    let taskSessionGeneration = 0;
    let taskRequest = null;
    let taskController = null;
    let taskListGeneration = 0;
    let taskListController = null;
    let taskUnmounted = false;
    // 复核
    const rvFilter = reactive({ status: "pending", level: "" });
    const reviewItems = ref([]), reviewDlg = ref(false), reviewEv = ref(null), reviewComment = ref("");
    // 底库
    const galleries = ref([]), galleryDlg = ref(false), galleryForm = reactive({ name: "", mode: "watch" });
    // 通知
    const notifDrawer = ref(false), notifications = ref([]);
    let notifTimer = null;
    // 样本/审计/存储
    const sampleItems = ref([]), sampleStats = reactive({ pos: 0, neg: 0, unexported: 0, exported: 0, total: 0 });
    const exporting = ref(false), exports = ref([]);
    const auditItems = ref([]), storage = ref(null);
    const report = ref(null), reportDoc = ref(null);
    const benchmarkInfo = ref(null), benchmarkResult = ref(null), benchmarkRunning = ref(false);
    const stressForm = reactive({ task_id: "", concurrency: 2, frames_per_stream: 10 });
    const stressResult = ref(null), stressRunning = ref(false);
    const emergency = ref({ configured: false, api_url: "", ui_url: "", local_plan_enabled: false, model: "", vlm_enabled: false });
    const emergencyForm = reactive({ alert_id: "", event_id: "", extra: "" });
    const emergencyExecute = reactive({ source_id: "", det_task_id: "builtin9", uri: "", name: "", kind: "http", lat: null, lng: null, address: "", extra: "" });
    const emergencyPlan = ref(null);
    const emergencyPlanLoading = ref(false);
    const emergencyRun = ref(null);
    let emergencyPollTimer = null;
    const emSituation = ref(null);
    const emNow = ref(Date.now());
    const emStream = reactive({ startedAt: 0, firstTokenAt: 0, chars: 0, controller: null, error: "" });
    let emSituationTimer = null;
    const EM_SECTIONS = ["事件概述", "响应定级", "指挥架构", "预警发布", "处置行动方案", "资源调度方案", "信息报送与新闻发布", "风险提示与注意事项", "依据引用"];
    const botOpen = ref(false);
    const botMessages = ref([]);
    const botInput = ref("");
    const botLoading = ref(false);
    const usersItems = ref([]), userDlg = ref(false), userForm = reactive({ username: "", password: "", role: "viewer", enabled: true });

    // helpers
    const isActive = (s) => s === "pending" || s === "processing";
    const isStreamTask = computed(() => {
      const fp = (curTask.value && curTask.value.file_path) || "";
      return /^(https?|rtsp|rtmp|tcp|udp):\/\//i.test(fp);
    });
    function localVideoUrl(row) {
      const fp = row && row.file_path;
      if (!fp || /^(https?|rtsp|rtmp|tcp|udp):\/\//i.test(fp)) return "";
      return "/uploads/" + fp.split("/").pop();
    }
    function nativeVideoUrl(row) {
      if (row && row.has_credentials) return "";
      const url = String((row && (row.uri || row.file_path)) || "").trim();
      return /^https?:\/\//i.test(url) ? url : "";
    }
    function setTaskMedia(row) {
      taskMedia.localUrl = localVideoUrl(row);
      taskMedia.nativeUrl = nativeVideoUrl(row);
      taskMedia.proxyUrl = (!taskMedia.localUrl && !taskMedia.nativeUrl && row && row.source_id) ? "/api/sources/" + row.source_id + "/stream" : "";
    }
    const previewNonce = ref(Date.now());
    const previewDlg = ref(false);
    const previewSrc = ref(null);
    function refreshPreview() { previewNonce.value = Date.now(); }
    function openPreview(row) { previewSrc.value = row; previewDlg.value = true; }
    const geoSources = computed(() => (dash.value.source_cards || []).filter(hasSourceLngLat));
    const hasGeoSources = computed(() => geoSources.value.length > 0);
    function hasSourceLngLat(s) {
      if (!s) return false;
      const valid = (v, limit) => (typeof v === "number" || typeof v === "string") &&
        String(v).trim() !== "" && Number.isFinite(Number(v)) && Math.abs(Number(v)) <= limit;
      return valid(s.lng, 180) && valid(s.lat, 90);
    }
    function redactSourceUri(uri) {
      return String(uri || "").replace(/(\b[a-z][a-z0-9+.-]*:\/\/)[^/\s]*@/gi, "$1***@")
        .replace(/([?&](?:password|passwd|token|access_token|secret|api_key)=)[^&#]*/gi, "$1***");
    }
    function sourceStateLabel(source) {
      if (source.kind === "file") return source.online ? "文件可用" : "文件不可用";
      return source.online ? "最近测试通过" : "待测试 / 不可达";
    }
    function inferSourceKindClient(uri) {
      const u = String(uri || "").toLowerCase();
      if (u.startsWith("rtsp://") || (u.startsWith("rtsp:") && !u.startsWith("rtsp://"))) return "rtsp";
      if (u.startsWith("rtmp://") || (u.startsWith("rtmp:") && !u.startsWith("rtmp://"))) return "rtmp";
      if (u.startsWith("http://") || u.startsWith("https://")) return "http";
      return "file";
    }
    function sourceKindForPayload(form) {
      const inferred = inferSourceKindClient(form && form.uri);
      return inferred !== "file" ? inferred : ((form && form.kind) || inferred);
    }
    function normalizeTaskRow(t) {
      if (!t) return t;
      const legacyKey = "yo" + "lo_checked_frames";
      return Object.assign({}, t, {
        edge_checked_frames: t.edge_checked_frames ?? t[legacyKey] ?? 0,
        last_vlm_output: t.last_vlm_output || "",
        last_vlm_status: t.last_vlm_status || "",
        last_vlm_event_type: t.last_vlm_event_type || "Normal",
        last_vlm_confidence: t.last_vlm_confidence || "",
        last_vlm_at: t.last_vlm_at || "",
      });
    }
    function vlmRunState(row) {
      const status = String((row && row.last_vlm_status) || "").toLowerCase();
      if (!row || !row.last_vlm_at) return { label: "等待首轮", type: "info", state: "idle" };
      if (status === "called") return { label: "已调用", type: "success", state: "called" };
      if (status === "error") return { label: "调用异常", type: "danger", state: "error" };
      if (status === "disabled") return { label: "未开启", type: "info", state: "disabled" };
      if (status === "skipped") return { label: "本轮未调用", type: "warning", state: "skipped" };
      return { label: "等待更新", type: "info", state: "idle" };
    }
    function mercatorPoint(lng, lat, zoom) {
      const n = Math.pow(2, zoom);
      const boundedLat = Math.max(-85.05112878, Math.min(85.05112878, Number(lat)));
      const rad = boundedLat * Math.PI / 180;
      return {
        x: (Number(lng) + 180) / 360 * n,
        y: (1 - Math.log(Math.tan(rad) + 1 / Math.cos(rad)) / Math.PI) / 2 * n,
      };
    }
    const mapFallbackCenter = computed(() => {
      const rows = geoSources.value;
      if (!rows.length) return [108.320004, 22.82402];
      let wsum = 0, lng = 0, lat = 0;
      rows.forEach(s => {
        const w = 1 + Number(s.events || 0) + Number(s.active_alerts || 0) * 4;
        wsum += w;
        lng += Number(s.lng) * w;
        lat += Number(s.lat) * w;
      });
      return [lng / wsum, lat / wsum];
    });
    const mapFallbackZoom = 7;
    const mapFallbackTiles = computed(() => {
      const center = mapFallbackCenter.value;
      const zoom = mapFallbackZoom;
      const lon2tile = (lon, z) => Math.floor((lon + 180) / 360 * Math.pow(2, z));
      const lat2tile = (lat, z) => {
        const rad = lat * Math.PI / 180;
        return Math.floor((1 - Math.log(Math.tan(rad) + 1 / Math.cos(rad)) / Math.PI) / 2 * Math.pow(2, z));
      };
      const cx = lon2tile(center[0], zoom);
      const cy = lat2tile(center[1], zoom);
      const tiles = [];
      for (let row = -2; row <= 2; row += 1) {
        for (let col = -3; col <= 3; col += 1) {
          const x = cx + col;
          const y = cy + row;
          const srv = Math.abs(x + y) % 4 + 1;
          const url = tileFallbackProvider.value === "osm"
            ? `https://tile.openstreetmap.org/${zoom}/${x}/${y}.png`
            : `https://webrd0${srv}.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=7&x=${x}&y=${y}&z=${zoom}`;
          tiles.push({ key: `${tileFallbackNonce.value}-${tileFallbackProvider.value}-${zoom}-${x}-${y}`, left: (col + 3) * 256, top: (row + 2) * 256, url });
        }
      }
      return tiles;
    });
    function tilePointStyle(s, i = 0) {
      const zoom = mapFallbackZoom;
      const center = mapFallbackCenter.value;
      const centerTile = mercatorPoint(center[0], center[1], zoom);
      const originX = Math.floor(centerTile.x) - 3;
      const originY = Math.floor(centerTile.y) - 2;
      const pos = sourceLngLat(s, i);
      if (!pos) return { display: "none" };
      const p = mercatorPoint(pos[0], pos[1], zoom);
      const px = (p.x - originX) * 256;
      const py = (p.y - originY) * 256;
      const left = Math.max(4, Math.min(96, px / 1792 * 100));
      const top = Math.max(4, Math.min(96, py / 1280 * 100));
      return { left: left + "%", top: top + "%" };
    }
    const mapHeatPoints = computed(() => (dash.value.source_cards || []).filter(hasSourceLngLat).map((s, i) => {
      const intensity = Math.min(1, (Number(s.events || 0) + Number(s.active_alerts || 0) * 6 + (s.online ? 1 : 0)) / 12);
      return { ...s, _idx: i, _intensity: Math.max(.18, intensity) };
    }));
    function heatPointStyle(s) {
      const base = tilePointStyle(s, s._idx || 0);
      const size = 46 + Math.round((s._intensity || .2) * 90);
      return {
        ...base,
        width: size + "px",
        height: size + "px",
        opacity: Math.min(.86, .32 + (s._intensity || .2) * .5),
      };
    }
    const statusText = (s) => ({ pending: "排队", processing: "分析中", completed: "已完成", failed: "失败", cancelled: "已取消" }[s] || s);
    const statusType = (s) => ({ pending: "info", processing: "warning", completed: "success", failed: "danger", cancelled: "info" }[s] || "info");
    const evtColor = (t) => (cfg.value.event_color || {})[t] || "info";
    const lvlColor = (l) => (cfg.value.level_color || {})[l] || "info";
    const lvlLabel = (l) => (cfg.value.level_label || {})[l] || l;
    const revColor = (s) => ({ pending: "warning", confirmed: "success", rejected: "info", escalated: "danger" }[s] || "info");
    const revLabel = (s) => ({ pending: "待复核", confirmed: "已确认", rejected: "已驳回", escalated: "已升级" }[s] || s);
    const fmtTs = (sec) => { const s = Math.floor(sec || 0); return String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0"); };
    function snapshotUrl(path) {
      const p = String(path || "").trim();
      if (!p) return "";
      if (/^(https?:)?\/\//i.test(p) || p.startsWith("data:")) return p;
      if (p.startsWith("/")) return p;
      return "/snapshots/" + p.split("/").pop();
    }
    const alertStatusLabel = (s) => ({ active: "活跃", acked: "已认领", resolved: "已解决" }[s] || s || "未知");
    const alertStatusType = (s) => ({ active: "danger", acked: "warning", resolved: "success" }[s] || "info");
    const fmtDur = (sec) => { if (!sec) return "时长未知"; const s = Math.round(sec); return Math.floor(s / 60) + "分" + (s % 60) + "秒"; };
    const fmtArr = (v) => { try { const a = typeof v === "string" ? JSON.parse(v) : v; return Array.isArray(a) ? a.join("、") : ""; } catch (e) { return ""; } };
    function cleanPlanText(s) {
      return String(s || "").replace(/\*\*/g, "").replace(/^[-*]\s*/, "").trim();
    }
    const emergencySections = computed(() => {
      const md = (emergencyPlan.value && emergencyPlan.value.plan_markdown) || "";
      if (!md.trim()) return [];
      const sections = [];
      let current = { title: "指挥摘要", lines: [] };
      md.split(/\r?\n/).forEach((line) => {
        const m = line.match(/^#{1,3}\s+(.+)$/);
        if (m) {
          if (current.lines.length || sections.length) sections.push(current);
          current = { title: cleanPlanText(m[1]), lines: [] };
        } else if (line.trim()) {
          current.lines.push(cleanPlanText(line));
        }
      });
      if (current.lines.length || !sections.length) sections.push(current);
      return sections.map(s => ({ title: s.title, body: s.lines.join("\n") }));
    });
    const emergencyPlanCards = computed(() => {
      const p = emergencyPlan.value || {};
      const inc = p.incident || {};
      const live = emergencyPlanLoading.value && emStream.startedAt;
      const seconds = live ? ((emNow.value - emStream.startedAt) / 1000).toFixed(0) : (p.elapsed_sec != null ? Math.round(p.elapsed_sec) : null);
      return [
        { label: "响应等级", value: inc.severity ? (inc.severity + " " + (lvlLabel(inc.severity) || "")) : "待定", cls: inc.severity === "L3" ? "danger" : "warn" },
        { label: "事发点位", value: inc.source_name || "未绑定数据源", cls: "blue" },
        { label: "事件类型", value: inc.event_type || "交通异常", cls: "danger" },
        { label: "识别置信度", value: inc.confidence || "—", cls: "green" },
        { label: live ? "已生成" : "生成耗时", value: seconds != null ? seconds + " 秒" : "—", cls: "blue" },
        { label: "方案字数", value: String((p.plan_markdown || "").replace(/\s|#/g, "").length), cls: "green" },
      ];
    });
    const emSectionProgress = computed(() => {
      const titles = emergencySections.value.map(sec => sec.title);
      const streaming = emergencyPlanLoading.value;
      let last = -1;
      EM_SECTIONS.forEach((name, i) => { if (titles.some(t => t.includes(name))) last = i; });
      return EM_SECTIONS.map((name, i) => ({ name, state: i < last || (!streaming && i <= last) ? "done" : (i === last && streaming ? "active" : "todo") }));
    });
    const emRunSteps = computed(() => {
      const run = emergencyRun.value;
      if (!run) return [];
      const st = (run.task && run.task.status) || "pending";
      const found = (run.events || []).length > 0;
      const planned = !!(emergencyPlan.value && !emergencyPlanLoading.value && emergencyPlan.value.plan_markdown);
      const failed = st === "failed" || st === "cancelled";
      const steps = [
        { name: "连接视频源", detail: run.task.filename || "", state: st === "pending" ? "active" : "done" },
        { name: "抽帧检测", detail: (run.task.sampled_frames || 0) + " 帧 · 复判 " + (run.task.vlm_checked_frames || 0) + " 次", state: found ? "done" : (st === "processing" ? "active" : (failed ? "error" : "todo")) },
        { name: "发现风险事件", detail: found ? (run.events[0].event_type + " @ " + fmtTs(run.events[0].timestamp_sec)) : "等待中", state: found ? "done" : (failed ? "error" : "todo") },
        { name: "生成指挥方案", detail: emergencyPlanLoading.value ? "模型生成中" : (planned ? "已完成" : ""), state: planned ? "done" : (emergencyPlanLoading.value ? "active" : "todo") },
      ];
      return steps;
    });
    function fmtAgo(ts) {
      if (!ts) return "";
      const t = new Date(ts).getTime();
      if (!isFinite(t)) return ts;
      const sec = Math.max(0, Math.round((emNow.value - t) / 1000));
      if (sec < 60) return sec + " 秒前";
      if (sec < 3600) return Math.floor(sec / 60) + " 分钟前";
      if (sec < 86400) return Math.floor(sec / 3600) + " 小时前";
      return String(ts).slice(5, 16).replace("T", " ");
    }

    async function api(url, opts = {}) {
      const session = taskSessionGeneration;
      const r = await fetch(url, opts);
      const serverTime = Date.parse(r.headers.get("date") || "");
      if (Number.isFinite(serverTime)) {
        serverClockWarning.value = Math.abs(Date.now() - serverTime) > 300000
          ? "设备时间与本机相差超过 5 分钟，请核对时间源；今日统计及事件排序可能不准确。" : "";
      }
      // An obsolete task response must not expire a newer login session.
      if (opts.signal && opts.signal.aborted) throw new DOMException("Request aborted", "AbortError");
      if (r.status === 401) {
        if (isTaskSessionCurrent(session)) { authed.value = false; stopAll(); }
        throw new Error("unauth");
      }
      if (!r.ok && (!opts.method || opts.method.toUpperCase() === "GET")) {
        throw new Error("读取失败（HTTP " + r.status + "），请检查设备连接后重试");
      }
      return r;
    }

    async function boot() {
      try { const d = await (await fetch("/api/auth/me")).json(); authDisabled.value = !!d.auth_disabled; if (d.authed) { authed.value = true; user.value = d.user; await afterLogin(); } } catch (e) {}
    }
    async function doLogin() {
      loginForm.loading = true; loginForm.err = "";
      try {
        const r = await fetch("/api/auth/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ user: loginForm.user, pass: loginForm.pass }) });
        if (!r.ok) { loginForm.err = r.status === 401 ? "用户名或密码错误" : "登录失败"; return; }
        const d = await r.json(); authed.value = true; user.value = d.user; loginForm.pass = "";
        await afterLogin();
      } catch (e) { loginForm.err = "网络错误"; } finally { loginForm.loading = false; }
    }
    async function doLogout() {
      stopAll();
      authed.value = false;
      try {
        const r = await fetch("/api/auth/logout", { method: "POST" });
        if (!r.ok) throw new Error("退出登录失败（HTTP " + r.status + "）");
      } catch (e) {
        ElementPlus.ElMessage.error(e.message || "退出登录失败");
      }
    }
    async function afterLogin() {
      const session = taskSessionGeneration;
      view.value = "dashboard";
      try {
        const data = await (await fetch("/api/config")).json();
        if (!isTaskSessionCurrent(session)) return;
        cfg.value = data;
      } catch (e) {}
      if (!isTaskSessionCurrent(session)) return;
      await Promise.all([loadDashboard(), refreshTasks(), loadDetTasks(), loadSources(), loadGalleries()]);
      loadClockStatus();if(clockStatusTimer===null)clockStatusTimer=setInterval(loadClockStatus,30000);
      if (!isTaskSessionCurrent(session)) return;
      await pollUnread();
      if (isTaskSessionCurrent(session)) { startNotifPoll(); loadReviewCounts(); loadAlertStats(); startGpuPoll(); }
    }

    function switchView(k) {
      view.value = k;
      if (k === "dashboard") startGpuPoll(); else stopGpuPoll();
      if (!openTabs.value.find(t => t.k === k)) openTabs.value.push({ k, t: _tabTitle[k] || k });
      if (k === "dashboard") loadDashboard();
      else if (k === "sources") loadSources();
      else if (k === "presets") loadPresets();
      else if (k === "det-tasks") loadDetTasks();
      else if (k === "filters") loadFilters();
      else if (k === "alerts") loadAlerts();
      else if (k === "review") loadReview();
      else if (k === "gallery") loadGalleries();
      else if (k === "samples") { loadSamples(); loadExports(); }
      else if (k === "reports") loadReports();
      else if (k === "benchmark") loadBenchmarkInfo();
      else if (k === "stress") refreshTasks();
      else if (k === "emergency") loadEmergency();
      else if (k === "users") loadUsers();
      else if (k === "audit") loadAudit();
      else if (k === "storage") loadStorage();
      else if (k === "appearance") loadClockStatus();
    }
    function setDashboardMapMode(mode) {
      dashboardMapMode.value = mode;
      if (mode === "alerts") loadAlertStats();
      if (mode === "sources") loadSources();
      setTimeout(updateAmapMode, 0);
    }
    function openSourceCreate() {
      srcEditing.value = null;
      Object.assign(srcForm, { name: "", kind: "rtsp", uri: "", lat: null, lng: null, address: "" });
      srcDlg.value = true;
    }
    function openDashboardTarget(target) {
      if (target === "sources") switchView("sources");
      else if (target === "presets") switchView("presets");
      else if (target === "det-tasks") switchView("det-tasks");
      else if (target === "runs") switchView("runs");
      else if (target === "alerts") { alertFilter.status = "active"; switchView("alerts"); }
      else if (target === "review") { rvFilter.status = "pending"; rvFilter.level = ""; switchView("review"); }
      else if (target === "reports") switchView("reports");
      else if (target === "samples") switchView("samples");
      else if (target === "emergency") switchView("emergency");
      else if (target === "storage") switchView("storage");
    }
    function openRiskLevel(level) {
      if (level === "L3") { alertFilter.status = "active"; switchView("alerts"); return; }
      rvFilter.status = "pending";
      rvFilter.level = level === "L2" ? "L2" : "";
      switchView("review");
    }
    function openMapSource(s) {
      if (s && s.active_alerts) {
        alertFilter.status = "active";
        switchView("alerts");
      } else {
        switchView("sources");
      }
    }
    function runBuiltinFromDashboard() {
      if (sourcesItems.value.length) {
        openRunDlg("builtin9");
      } else {
        switchView("runs");
      }
    }
    function askDashboard(q) {
      aiQuestion.value = q;
      if (q.includes("告警")) {
        aiAnswer.value = `当前活跃告警 ${dash.value.alerts_active || 0} 个，今日新增 ${dash.value.alerts_today || 0} 个；点击右侧预警卡可进入告警中心处置。`;
      } else if (q.includes("复核")) {
        aiAnswer.value = `当前待复核 ${dash.value.pending_review || 0} 条；建议优先处理 L3/L2 事件，并将误报回流为负样本。`;
      } else if (q.includes("数据源")) {
        aiAnswer.value = `当前在线 ${dash.value.online_sources || 0}/${dash.value.sources || 0} 路；离线源可进入数据源管理执行连通测试。`;
      } else {
        aiAnswer.value = "已刷新态势数据。可从数据源、告警、复核、报表入口继续下钻。";
        loadDashboard();
      }
    }

    // ---- 大屏 ----
    function loadAmapSdk() {
      if (!cfg.value.amap_js_key || cfg.value.map_provider !== "amap") {
        return Promise.reject(new Error("未配置高德地图 Key"));
      }
      if (window.AMap && window.AMap.Map) return Promise.resolve(window.AMap);
      if (amapSdkPromise) return amapSdkPromise;
      amapLoading.value = true;
      amapError.value = "";
      if (cfg.value.amap_security_code) {
        window._AMapSecurityConfig = { securityJsCode: cfg.value.amap_security_code };
      }
      amapSdkPromise = new Promise((resolve, reject) => {
        const script = document.createElement("script");
        script.src = "https://webapi.amap.com/maps?v=2.0&key=" + encodeURIComponent(cfg.value.amap_js_key) + "&plugin=AMap.Scale,AMap.ToolBar,AMap.TileLayer.Traffic";
        script.async = true;
        script.onload = () => window.AMap ? resolve(window.AMap) : reject(new Error("高德地图 SDK 未就绪"));
        script.onerror = () => reject(new Error("高德地图加载失败"));
        document.head.appendChild(script);
      }).catch((e) => {
        amapSdkPromise = null;
        throw e;
      }).finally(() => { amapLoading.value = false; });
      return amapSdkPromise;
    }
    function resetTileFallback() {
      tileFallbackReady.value = false;
      tileFallbackProvider.value = "amap";
      tileFallbackErrors = 0;
      tileFallbackNonce.value += 1;
    }
    function onTileFallbackLoad(e) {
      if (e && e.target && e.target.naturalWidth > 32) tileFallbackReady.value = true;
    }
    function onTileFallbackError() {
      tileFallbackErrors += 1;
      if (tileFallbackProvider.value === "amap" && tileFallbackErrors >= 6) {
        tileFallbackReady.value = false;
        tileFallbackProvider.value = "osm";
        tileFallbackErrors = 0;
      }
    }
    function fallbackLngLat(i) {
      const points = [
        [108.320004, 22.82402], [109.412, 24.326], [110.290, 25.273], [108.366, 21.686],
        [109.119, 21.473], [109.602, 23.093], [111.305, 23.486], [106.616, 23.905],
        [107.353, 22.404], [110.181, 22.643], [108.085, 24.692], [110.147, 23.321],
      ];
      return points[i % points.length];
    }
    function sourceLngLat(s, i = 0) {
      const lng = Number(s && s.lng);
      const lat = Number(s && s.lat);
      return hasSourceLngLat(s) ? [lng, lat] : null;
    }
    function markerHtml(s, unlocated) {
      const cls = s.active_alerts ? "hot" : (s.online ? "ok" : "off");
      const count = s.active_alerts || s.events || "";
      return `<div class="amap-marker ${cls}${unlocated ? " unlocated" : ""}"><span>${count}</span></div>`;
    }
    function updateAmapMode() {
      if (!amapMap || !window.AMap) return;
      if (!amapTrafficLayer) amapTrafficLayer = new window.AMap.TileLayer.Traffic({ zIndex: 12 });
      if (dashboardMapMode.value === "traffic") {
        amapTrafficLayer.setMap(amapMap);
      } else {
        amapTrafficLayer.setMap(null);
      }
      const zoom = dashboardMapMode.value === "sources" ? 10 : 8;
      if (amapMap.getZoom && Math.abs(amapMap.getZoom() - zoom) > 2) amapMap.setZoom(zoom);
    }
    function hasLoadedAmapTiles() {
      if (!amapEl.value) return false;
      const imgs = Array.from(amapEl.value.querySelectorAll("img"));
      return imgs.some(img => img.complete && img.naturalWidth > 32 && img.naturalHeight > 32);
    }
    function waitForAmapTiles(timeoutMs = 4500) {
      const started = Date.now();
      return new Promise((resolve, reject) => {
        const tick = () => {
          if (hasLoadedAmapTiles()) { resolve(true); return; }
          if (Date.now() - started > timeoutMs) { reject(new Error("高德地图瓦片未加载，已保留本地态势底图")); return; }
          setTimeout(tick, 220);
        };
        tick();
      });
    }
    function renderAmapMarkers() {
      if (!amapMap || !window.AMap) return;
      amapMap.remove(amapMarkers);
      amapMarkers = [];
      const rows = (dash.value.source_cards || []).filter(hasSourceLngLat);
      for (let i = 0; i < rows.length; i += 1) {
        const s = rows[i];
        const real = sourceLngLat(s, i);
        const raw = sourceLngLat(s, i);
        const hasReal = hasSourceLngLat(s);
        const pos = hasReal ? raw : real;
        const marker = new window.AMap.Marker({
          position: pos,
          title: (s.name || "数据源") + (hasReal ? "" : "（示意位置）"),
          content: markerHtml(s, !hasReal),
          offset: new window.AMap.Pixel(-12, -12),
        });
        marker.on("click", () => openMapSource(s));
        amapMarkers.push(marker);
      }
      if (amapMarkers.length) {
        amapMap.add(amapMarkers);
        amapMap.setFitView(amapMarkers, false, [60, 60, 60, 60], 13);
      } else {
        amapMap.setCenter([108.320004, 22.82402]);
        amapMap.setZoom(7);
      }
      updateAmapMode();
    }
    function renderAmapDashboard() {
      if (view.value !== "dashboard") return;
      setTimeout(() => {
        if (!amapEl.value || !cfg.value.amap_js_key) return;
        loadAmapSdk()
          .then((AMap) => {
            if (amapMap && amapContainer !== amapEl.value) {
              try { amapMap.destroy(); } catch (e) {}
              amapMap = null;
              amapContainer = null;
              amapTrafficLayer = null;
              amapMarkers = [];
              amapReady.value = false;
            }
            if (!amapMap) {
              amapMap = new AMap.Map(amapEl.value, {
                viewMode: "2D",
                zoom: 7,
                center: [108.320004, 22.82402],
                mapStyle: "amap://styles/normal",
                features: ["bg", "road", "building", "point"],
                pitch: 0,
                resizeEnable: true,
              });
              amapContainer = amapEl.value;
              amapMap.addControl(new AMap.Scale());
              amapMap.addControl(new AMap.ToolBar({ position: { right: "12px", top: "92px" } }));
            }
            waitForAmapTiles()
              .then(() => {
                amapReady.value = true;
                amapError.value = "";
                renderAmapMarkers();
              })
              .catch((e) => {
                amapReady.value = false;
                amapError.value = e.message || "地图瓦片加载失败";
                try { amapMap && amapMap.destroy(); } catch (err) {}
                amapMap = null;
                amapContainer = null;
                amapTrafficLayer = null;
                amapMarkers = [];
              });
          })
          .catch((e) => {
            amapReady.value = false;
            amapError.value = e.message || "地图加载失败，已使用本地态势底图";
          });
      }, 80);
    }
    async function loadDashboard() {
      try {
        dash.value = await (await api("/api/dashboard")).json();
        dashboardError.value = "";
        resetTileFallback();
        renderAmapDashboard();
      } catch (e) { dashboardError.value = "首页数据更新失败，当前可能是旧数据。" + (e.message || ""); }
    }

    // ---- 数据源 ----
    async function loadSources() {
      try {
        sourcesItems.value = (await (await api("/api/sources")).json()).items;
        sourcesError.value = "";
      } catch (e) { sourcesError.value = "数据源列表更新失败，当前可能是旧数据。" + (e.message || ""); }
    }
    function openSourceEdit(row) {
      srcEditing.value = row;
      Object.assign(srcForm, {
        name: row.name || "",
        kind: row.kind || "rtsp",
        uri: row.uri || "",
        lat: row.lat,
        lng: row.lng,
        address: row.address || "",
      });
      srcDlg.value = true;
    }
    async function createSource(opts = {}) {
      if (!srcForm.uri) { ElementPlus.ElMessage.warning("请填写摄像头或视频流地址"); return null; }
      const isEdit = !!srcEditing.value;
      const payload = { ...srcForm, kind: sourceKindForPayload(srcForm) };
      const url = srcEditing.value ? "/api/sources/" + srcEditing.value.id : "/api/sources";
      const method = srcEditing.value ? "PATCH" : "POST";
      const r = await api(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      if (!r.ok) { ElementPlus.ElMessage.error(srcEditing.value ? "更新失败" : "创建失败"); return; }
      const sid = srcEditing.value ? srcEditing.value.id : (await r.json()).id;
      srcDlg.value = false;
      let testedOnline = true;
      if (srcEditing.value) {
        ElementPlus.ElMessage.success("已更新定位");
      } else {
        ElementPlus.ElMessage.success("已创建，正在测试连通…");
        const t = await (await api("/api/sources/" + sid + "/test", { method: "POST" })).json();
        testedOnline = !!t.online;
        t.online ? ElementPlus.ElMessage.success("连通成功，已在线") : ElementPlus.ElMessage.warning("连通失败：" + (t.error || ""));
      }
      srcEditing.value = null;
      Object.assign(srcForm, { name: "", kind: "rtsp", uri: "", lat: null, lng: null, address: "" });
      await loadSources();
      await loadDashboard();
      if (!isEdit && opts.runAfter) {
        if (testedOnline) await startSourceRun(sid);
        else ElementPlus.ElMessage.warning("数据源未连通，已保存但未启动理解");
      }
      return sid;
    }
    async function createSourceAndRun() {
      await createSource({ runAfter: true });
    }
    async function testSource(id) { const t = await (await api("/api/sources/" + id + "/test", { method: "POST" })).json(); t.online ? ElementPlus.ElMessage.success("在线") : ElementPlus.ElMessage.warning("离线：" + (t.error || "")); await loadSources(); }
    async function delSource(id) { try { await ElementPlus.ElMessageBox.confirm("将该数据源移出列表？历史告警、录像和截图将保留供追溯。", "确认", { type: "warning" }); } catch (e) { return; } await api("/api/sources/" + id, { method: "DELETE" }); await loadSources(); ElementPlus.ElMessage.success("已删除"); }
    async function startSourceRun(sourceId) {
      await loadDetTasks();
      openRunDlg();
      runForm.source_id = sourceId;
    }


    // ---- 检测任务 ----
    async function loadDetTasks() {
      try {
        detTasks.value = (await (await api("/api/det-tasks")).json()).items;
        if (detTasks.value.length && !detTasks.value.some(t => t.id === uploadTask.value)) {
          uploadTask.value = "";
        }
      } catch (e) {}
    }
    function openTaskDlg(p) { Object.assign(taskForm, { name: p?.name || "", status: "enabled", target_objects: p?.target_objects || [], prompt: p?.prompt || "", require_review: true, interval_sec: null, gallery_ids: [] }); taskDlg.value = true; }
    async function createDetTask() {
      if (!taskForm.name) { ElementPlus.ElMessage.warning("请填任务名称"); return; }
      const r = await api("/api/det-tasks", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...taskForm }) });
      if (!r.ok) { ElementPlus.ElMessage.error("创建失败"); return; }
      taskDlg.value = false; ElementPlus.ElMessage.success("已创建"); await loadDetTasks();
    }
    async function delDetTask(id) { try { await ElementPlus.ElMessageBox.confirm("删除该任务？", "确认", { type: "warning" }); } catch (e) { return; } await api("/api/det-tasks/" + id, { method: "DELETE" }); await loadDetTasks(); ElementPlus.ElMessage.success("已删除"); }
    function openRunDlg(tid) { if (tid === 'safety-stream') { switchView('safety'); return; } Object.assign(runForm, { det_task_id: tid || "builtin9", source_id: "", uri: "", name: "", kind: "rtsp", lat: null, lng: null, address: "" }); runDlg.value = true; }
    async function createRun() {
      if (runForm.det_task_id === "safety-stream") {
        if (!runForm.source_id) { ElementPlus.ElMessage.warning("请先登记并选择摄像头数据源"); return; }
        const source = sourcesItems.value.find(s => s.id === runForm.source_id);
        if (!source || source.kind === "file") { ElementPlus.ElMessage.warning("实时巡检请选择网络源；本地录像请在巡检页选择视频文件"); return; }
        safetySourceId.value = runForm.source_id;
        runDlg.value = false;
        switchView("safety");
        return;
      }
      if (!runForm.source_id && !runForm.uri) { ElementPlus.ElMessage.warning("请选择数据源或填写在线视频 URL"); return; }
      const session = taskSessionGeneration, generation = taskGeneration;
      const body = { source_id: runForm.source_id, det_task_id: runForm.det_task_id || "builtin9" };
      if (!runForm.source_id && runForm.uri) {
        Object.assign(body, { uri: runForm.uri, name: runForm.name, kind: sourceKindForPayload(runForm), lat: runForm.lat, lng: runForm.lng, address: runForm.address });
      }
      const r = await api("/api/runs", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      if (!isTaskSessionCurrent(session)) return;
      if (!r.ok) { ElementPlus.ElMessage.error("运行失败"); return; }
      const rid = (await r.json()).run_id;
      if (!isTaskSessionCurrent(session)) return;
      runDlg.value = false; ElementPlus.ElMessage.success("已开始运行"); await refreshTasks();
      if (!isTaskSessionCurrent(session) || generation !== taskGeneration) return;
      view.value = "runs";
      if (rid) selectTask(rid);
    }

    // ---- 预置算法 / 误报规则 ----
    async function loadPresets() { try { presetsItems.value = (await (await api("/api/algorithm-presets")).json()).items; } catch (e) {} }
    async function loadFilters() { try { const d = await (await api("/api/filter-rules")).json(); filterRules.value = d.items || []; Object.assign(filterStats, d.stats || {}); } catch (e) {} }
    function openFilterDlg() { Object.assign(filterForm, { name: "", rule_type: "confidence", scope: "global", enabled: true, det_task_id: "", source_id: "", params_text: "{\"min\":\"中\"}" }); filterDlg.value = true; }
    async function createFilterRule() {
      let params = {};
      try { params = JSON.parse(filterForm.params_text || "{}"); } catch (e) { ElementPlus.ElMessage.error("params 不是合法 JSON"); return; }
      const body = { name: filterForm.name, rule_type: filterForm.rule_type, scope: filterForm.scope, enabled: filterForm.enabled, params };
      if (filterForm.scope === "task") body.det_task_id = filterForm.det_task_id;
      if (filterForm.scope === "source") body.source_id = filterForm.source_id;
      const r = await api("/api/filter-rules", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      if (!r.ok) { ElementPlus.ElMessage.error("创建失败"); return; }
      filterDlg.value = false; ElementPlus.ElMessage.success("已创建"); await loadFilters();
    }
    async function delFilterRule(id) { await api("/api/filter-rules/" + id, { method: "DELETE" }); await loadFilters(); ElementPlus.ElMessage.success("已删除"); }

    // ---- 运行（上传/历史/详情）----
    function isTaskSessionCurrent(session) {
      return authed.value && !taskUnmounted && session === taskSessionGeneration;
    }
    function isCurrentTaskRequest(request) {
      return !!request && !!taskRequest && isTaskSessionCurrent(request.session) &&
        request.id === taskRequest.id && request.generation === taskGeneration && !request.signal.aborted;
    }
    function clearTaskSelection() {
      curTask.value = null;
      curEvents.value = [];
      vlmLog.value = [];
      setTaskMedia(null);
    }
    function stopTaskPoll() {
      taskGeneration += 1;
      taskRequest = null;
      if (taskTimer !== null) { clearTimeout(taskTimer); taskTimer = null; }
      if (taskController) { taskController.abort(); taskController = null; }
      taskPollSeq = 0;
    }
    function beginTaskRequest(id) {
      stopTaskPoll();
      taskController = new AbortController();
      taskRequest = { id, generation: taskGeneration, session: taskSessionGeneration, signal: taskController.signal };
      return taskRequest;
    }
    async function taskApi(url, signal, opts = {}) {
      const r = await api(url, { ...opts, signal });
      if (!r.ok) throw new Error("任务请求失败（HTTP " + r.status + "）");
      return r;
    }
    async function fetchTaskDetails(request) {
      const d = await (await taskApi("/api/tasks/" + request.id, request.signal)).json();
      if (!d.task || d.task.id !== request.id) throw new Error("任务详情响应不匹配");
      if (!Array.isArray(d.events) || (d.vlm_log != null && !Array.isArray(d.vlm_log))) throw new Error("任务详情响应格式错误");
      return d;
    }
    async function refreshTasks(request = null) {
      const session = taskSessionGeneration;
      if (!isTaskSessionCurrent(session) || (request && !isCurrentTaskRequest(request))) return;
      if (taskListController) taskListController.abort();
      const generation = ++taskListGeneration;
      const controller = request ? null : new AbortController();
      taskListController = controller;
      const signal = request ? request.signal : controller.signal;
      const isCurrent = () => isTaskSessionCurrent(session) && generation === taskListGeneration &&
        !signal.aborted && (!request || isCurrentTaskRequest(request));
      try {
        const rows = await (await taskApi("/api/tasks", signal)).json();
        if (!isCurrent()) return;
        tasks.value = rows.map(normalizeTaskRow);
      } catch (e) {
        if (isCurrent() && e.name !== "AbortError") ElementPlus.ElMessage.error(e.message || "任务列表加载失败");
      } finally {
        if (generation === taskListGeneration) taskListController = null;
      }
    }
    async function selectTask(id) {
      if (!isTaskSessionCurrent(taskSessionGeneration) || id == null) return;
      const preserveMedia = curTask.value && curTask.value.id === id;
      const request = beginTaskRequest(id);
      // Hide the previous task's controls and media while a different task loads.
      if (!preserveMedia) clearTaskSelection();
      try {
        const d = await fetchTaskDetails(request);
        if (!isCurrentTaskRequest(request)) return;
        curTask.value = normalizeTaskRow(d.task);
        curEvents.value = d.events;
        vlmLog.value = (d.vlm_log || []).slice().reverse();
        if (!preserveMedia) setTaskMedia(curTask.value);
        if (isActive(curTask.value.status)) startTaskPoll(request);
      } catch (e) {
        if (!isCurrentTaskRequest(request) || e.name === "AbortError") return;
        stopTaskPoll();
        clearTaskSelection();
        ElementPlus.ElMessage.error(e.message || "任务详情加载失败");
      }
    }
    function startTaskPoll(request) {
      const canPoll = () => isCurrentTaskRequest(request) && curTask.value &&
        curTask.value.id === request.id && isActive(curTask.value.status);
      if (!canPoll()) return;
      if (taskTimer !== null) clearTimeout(taskTimer);
      const ms = Math.max(2500, (cfg.value.poll_interval_sec || 2.5) * 1000);
      const tick = async () => {
        if (!canPoll()) return;
        taskTimer = null;
        try {
          const d = await fetchTaskDetails(request);
          if (!isCurrentTaskRequest(request)) return;
          const oldCount = Number(curTask.value.event_count || curEvents.value.length || 0);
          const nextTask = normalizeTaskRow(d.task);
          const nextCount = Number(nextTask.event_count || d.events.length || 0);
          curTask.value = nextTask;
          vlmLog.value = (d.vlm_log || []).slice().reverse();
          if (nextCount !== oldCount || !isActive(nextTask.status)) curEvents.value = d.events;
          taskPollSeq += 1;
          if (taskPollSeq % 4 === 0 || !isActive(nextTask.status)) {
            await refreshTasks(request);
            if (!isCurrentTaskRequest(request)) return;
            const r = await api("/api/alerts?limit=1", { signal: request.signal });
            if (!r.ok) throw new Error("告警统计加载失败（HTTP " + r.status + "）");
            const d = await r.json();
            if (!isCurrentTaskRequest(request)) return;
            Object.assign(alertStats, d.stats);
          }
        } catch (e) {
          if (!isCurrentTaskRequest(request) || e.name === "AbortError") return;
          ElementPlus.ElMessage.error(e.message || "任务状态更新失败");
        }
        if (canPoll()) taskTimer = setTimeout(tick, ms);
      };
      taskTimer = setTimeout(tick, ms);
    }
    function beforeUpload(f) {
      if (!uploadTask.value) { ElementPlus.ElMessage.warning("请先选择交通检测或刀具与斗殴检测"); return false; }
      if (!/\.(mp4|mov|avi|mkv|webm|wmv|flv|m4v|ts)$/i.test(f.name)) { ElementPlus.ElMessage.error("仅支持视频文件"); return false; }
      if (f.size > cfg.value.max_upload_mb * 1024 * 1024) { ElementPlus.ElMessage.error("文件超过 " + cfg.value.max_upload_mb + "MB"); return false; }
      return true;
    }
    const uploadQueueCount = ref(0);
    const uploadProgress = reactive({name:'',size:0,sent:0,percent:0,rate:0,remaining:null,stage:'idle',reused:false,error:''});
    const uploadStageText = computed(()=>({checking:'检查文件',choice:'选择上传方式',uploading:'正在传输',saving:'传输完成，正在保存并建立任务',reusing:'使用已存录像，正在建立任务',done:uploadProgress.reused?'已复用录像并提交检测':'已上传并提交检测',cancelled:'当前文件已跳过或取消',error:'上传未完成'}[uploadProgress.stage]||''));
    const uploadMB = n => (Math.max(0,Number(n)||0)/1048576).toFixed(1);
    const uploadEta = computed(()=>uploadProgress.remaining==null?'估算中':uploadProgress.remaining<60?Math.ceil(uploadProgress.remaining)+'秒':Math.ceil(uploadProgress.remaining/60)+'分钟');
    let uploadQueue = Promise.resolve(), activeUploadXHR = null;
    function cancelCurrentUpload() { if (activeUploadXHR && uploadProgress.stage==='uploading') activeUploadXHR.abort(); }
    async function uploadError(response) {
      const value=await response.json().catch(()=>({}));
      return new Error(typeof value.detail==='string'?value.detail:'请求失败（HTTP '+response.status+'）');
    }
    function sendUpload(req,tid,session) {
      return new Promise((resolve,reject)=>{
        const xhr=new XMLHttpRequest(); activeUploadXHR=xhr;
        const started=performance.now();let lastAt=started,lastSent=0;
        const current=()=>activeUploadXHR===xhr&&isTaskSessionCurrent(session);
        const finish=()=>{if(activeUploadXHR===xhr)activeUploadXHR=null;};
        xhr.open('POST','/api/upload?allow_duplicate=true&det_task_id='+encodeURIComponent(tid));
        xhr.withCredentials=true;
        xhr.upload.onprogress=e=>{
          if(!current()||!e.lengthComputable)return;
          const now=performance.now(),sent=Math.min(req.file.size,Math.round(req.file.size*e.loaded/e.total));
          uploadProgress.sent=sent;uploadProgress.percent=Math.min(100,Math.floor(e.loaded/e.total*100));
          if(now-lastAt>=300){
            const rate=(sent-lastSent)/((now-lastAt)/1000);
            uploadProgress.rate=uploadProgress.rate?uploadProgress.rate*.65+rate*.35:rate;
            lastAt=now;lastSent=sent;
          }
          uploadProgress.remaining=uploadProgress.rate>0?(req.file.size-sent)/uploadProgress.rate:null;
          req.onProgress?.({percent:uploadProgress.percent});
          if(e.loaded>=e.total)uploadProgress.stage='saving';
        };
        xhr.upload.onload=()=>{if(current()){uploadProgress.sent=req.file.size;uploadProgress.percent=100;uploadProgress.remaining=0;uploadProgress.stage='saving';}};
        xhr.onload=()=>{finish();if(!xhr.status){reject(new Error('网络连接中断，请重试'));return;}resolve(new Response(xhr.responseText,{status:xhr.status,headers:{'Content-Type':xhr.getResponseHeader('Content-Type')||'application/json'}}));};
        xhr.onerror=()=>{finish();reject(new Error('网络连接中断，请检查以太网连接后重试'));};
        xhr.onabort=()=>{finish();reject(new DOMException('当前上传已取消','AbortError'));};
        uploadProgress.stage='uploading';
        const form=new FormData();form.append('file',req.file);xhr.send(form);
      });
    }
    function customUpload(req) {
      const tid=uploadTask.value,session=taskSessionGeneration;
      uploadQueueCount.value++;
      const operation=uploadQueue.then(()=>isTaskSessionCurrent(session)?uploadOne(req,tid,session):{skipped:true});
      uploadQueue=operation.catch(()=>{}).finally(()=>{uploadQueueCount.value=Math.max(0,uploadQueueCount.value-1);});
      return operation;
    }
    async function uploadOne(req,tid,session) {
      const generation=taskGeneration;
      if(!isTaskSessionCurrent(session))return;
      uploading.value=true;
      Object.assign(uploadProgress,{name:req.file.name,size:req.file.size,sent:0,percent:0,rate:0,remaining:null,stage:'checking',reused:false,error:''});
      try {
        const check=await api('/api/upload/preflight',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({filename:req.file.name,size:req.file.size,det_task_id:tid})});
        if(!isTaskSessionCurrent(session))return;
        if(!check.ok)throw await uploadError(check);
        const info=await check.json();let reuse=null;
        if(info.duplicate){
          uploadProgress.stage='choice';
          try{
            await ElementPlus.ElMessageBox.confirm('服务器已有同名录像“'+req.file.name+'”（'+uploadMB(info.duplicate.size)+' MB）。使用已存录像可以省去传输；本地内容如有更新，请选择重新上传。','已有同名录像',{confirmButtonText:'使用已存录像',cancelButtonText:'重新上传',distinguishCancelAndClose:true,closeOnClickModal:false});
            reuse=info.duplicate;
          }catch(action){
            if(!isTaskSessionCurrent(session))return;
            if(action!=='cancel'){uploadProgress.stage='cancelled';return {skipped:true};}
          }
        }
        if(!isTaskSessionCurrent(session))return;
        let r;
        if(reuse){
          uploadProgress.stage='reusing';uploadProgress.reused=true;
          r=await api('/api/runs',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({source_id:reuse.source_id,det_task_id:tid})});
        }else r=await sendUpload(req,tid,session);
        if(!isTaskSessionCurrent(session))return;
        if(r.status===401){authed.value=false;stopAll();throw new Error('登录状态已失效，请刷新后重试');}
        if(!r.ok)throw await uploadError(r);
        const data=await r.json(),taskId=data.task_id||data.run_id;
        uploadProgress.stage='done';uploadProgress.percent=100;
        ElementPlus.ElMessage.success(reuse?'已复用录像，提交检测':'上传成功，已提交检测');
        try{
          await refreshTasks();
          if(isTaskSessionCurrent(session)&&generation===taskGeneration)await selectTask(taskId);
        }catch(e){if(isTaskSessionCurrent(session))ElementPlus.ElMessage.warning('已提交检测，列表刷新失败，请点击运行记录重试');}
        return data;
      }catch(e){
        if(isTaskSessionCurrent(session)){
          uploadProgress.stage=e.name==='AbortError'?'cancelled':'error';uploadProgress.error=e.name==='AbortError'?'':displayText(e.message||'上传异常');
          if(e.name!=='AbortError'&&e.message!=='unauth')ElementPlus.ElMessage.error(uploadProgress.error);
        }
        throw e;
      }finally{if(isTaskSessionCurrent(session))uploading.value=false;}
    }
    async function cancelTask() {
      const request = taskRequest;
      if (!isCurrentTaskRequest(request) || !curTask.value || curTask.value.id !== request.id) return;
      try {
        await taskApi("/api/tasks/" + request.id + "/cancel", request.signal, { method: "POST" });
        if (!isCurrentTaskRequest(request)) return;
        ElementPlus.ElMessage.success("已请求取消");
        await selectTask(request.id);
      } catch (e) {
        if (isCurrentTaskRequest(request) && e.name !== "AbortError") ElementPlus.ElMessage.error(e.message || "取消任务失败");
      }
    }
    async function delTask() {
      let request = taskRequest;
      if (!isCurrentTaskRequest(request) || !curTask.value || curTask.value.id !== request.id) return;
      try {
        await ElementPlus.ElMessageBox.confirm("将该运行移出列表？有关联事件时保留录像、截图与告警；无事件时才释放文件。", "确认", { type: "warning" });
      } catch (e) {
        if (e !== "cancel" && e !== "close" && isCurrentTaskRequest(request)) ElementPlus.ElMessage.error("无法确认删除");
        return;
      }
      if (!isCurrentTaskRequest(request)) return;
      // Invalidate pending detail/poll responses before sending the deletion.
      request = beginTaskRequest(request.id);
      clearTaskSelection();
      try {
        await taskApi("/api/tasks/" + request.id, request.signal, { method: "DELETE" });
        if (!isCurrentTaskRequest(request)) return;
        ElementPlus.ElMessage.success("已移出列表；有事件的任务保留证据");
        await refreshTasks(request);
      } catch (e) {
        if (isCurrentTaskRequest(request) && e.name !== "AbortError") ElementPlus.ElMessage.error(e.message || "删除任务失败");
      } finally {
        if (isCurrentTaskRequest(request)) stopTaskPoll();
      }
    }

    // ---- 告警 ----
    async function loadAlertStats() { try { const d = await (await api("/api/alerts?limit=1")).json(); Object.assign(alertStats, d.stats); } catch (e) {} }
    async function loadAlerts() {
      alertSelection.value=[];
      try {
        const p = new URLSearchParams({ status: alertFilter.status || "", limit: "200" });
        const r = await api("/api/alerts?" + p);
        if (!r.ok) throw new Error("告警列表加载失败");
        const d = await r.json();
        alertItems.value = d.items || [];
        Object.assign(alertStats, d.stats || {});
      } catch (e) {
        ElementPlus.ElMessage.error(e.message || "告警列表加载失败");
      }
    }
    const alertSelection=ref([]),alertBatchWindow=ref(300),alertBatchAction=ref('ack');
    const alertActionLabels={ack:'认领',resolve:'解决',confirmed:'确认异常',rejected:'驳回误报'};
    async function batchAlerts() {
      const ids=[...alertSelection.value];if(!ids.length)return;
      try{await ElementPlus.ElMessageBox.confirm('将对所选'+ids.length+'条告警执行“'+alertActionLabels[alertBatchAction.value]+'”，仅限同一任务'+alertBatchWindow.value/60+'分钟内。','批量处理确认');}catch{return;}
      try{
        const r=await api('/api/alerts/batch',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ids,action:alertBatchAction.value,window_seconds:alertBatchWindow.value})});
        const d=await r.json();if(!r.ok){ElementPlus.ElMessage.error(d.detail||'批量处理失败');return;}
        ElementPlus.ElMessage.success('已处理'+d.completed.length+'条，并发冲突'+d.conflicts.length+'条');
        await loadAlerts();await loadReviewCounts();await loadDashboard();
      }catch(e){ElementPlus.ElMessage.error(e.message||'批量处理失败');}
    }
    async function ackAlert(id) {
      const r = await api("/api/alerts/" + id + "/ack", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
      r.ok ? ElementPlus.ElMessage.success("已认领") : ElementPlus.ElMessage.error("认领失败");
      await loadAlerts(); await loadAlertStats(); await loadDashboard();
    }
    async function resolveAlert(id) {
      const r = await api("/api/alerts/" + id + "/resolve", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
      r.ok ? ElementPlus.ElMessage.success("已解决") : ElementPlus.ElMessage.error("解决失败");
      await loadAlerts(); await loadAlertStats(); await loadDashboard();
    }
    function openEmergencyFromAlert(a) {
      Object.assign(emergencyForm, { alert_id: String(a.id), event_id: "", extra: "" });
      switchView("emergency");
      generateEmergencyPlan({ alert_id: a.id });
    }

    // ---- 复核 ----
    async function loadReviewCounts() { try { rvStats.pending = (await (await api("/api/review/queue?status=pending&limit=1")).json()).total; } catch (e) {} }
    const batchSelection=ref([]), batchWindow=ref(300);
    async function batchReview(action) {
      const ids=[...batchSelection.value];
      if (!ids.length) return;
      try { await ElementPlus.ElMessageBox.confirm("将对所选 "+ids.length+" 条事件执行"+(action==='rejected'?'驳回':'确认异常')+"，仅限同一任务"+(batchWindow.value/60)+"分钟内。", "批量人工复核"); }
      catch { return; }
      const r=await api("/api/review/batch",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({ids,action,window_seconds:batchWindow.value})});
      const d=await r.json();
      if (!r.ok) { ElementPlus.ElMessage.error(d.detail || "批量操作失败"); return; }
      ElementPlus.ElMessage.success("已处理 "+d.completed.length+" 条；并发冲突 "+d.conflicts.length+" 条");
      await loadReview(); await loadAlertStats();
    }
    async function loadReview() {
      batchSelection.value=[];
      try {
        const p = new URLSearchParams({ status: rvFilter.status || "", level: rvFilter.level || "", limit: "200" });
        const d = await (await api("/api/review/queue?" + p)).json();
        reviewItems.value = d.items || [];
      } catch (e) {
        ElementPlus.ElMessage.error(e.message || "复核列表加载失败");
      }
      await loadReviewCounts();
    }
    const reviewVideoUrl = ref("");
    const reviewEvidenceMessage = ref("");
    let reviewGeneration = 0;
    async function openReview(ev) {
      if (!ev || !ev.id) {
        ElementPlus.ElMessage.warning("事件数据不完整，无法打开复核详情");
        return;
      }
      reviewEv.value = ev;
      reviewComment.value = "";
      reviewVideoUrl.value = "";
      reviewEvidenceMessage.value = "正在查找原始录像…";
      reviewDlg.value = true;
      const generation = ++reviewGeneration;
      try {
        const data = await (await api("/api/tasks/" + encodeURIComponent(ev.task_id))).json();
        if (generation !== reviewGeneration) return;
        const url = localVideoUrl(data.task);
        if (url) {
          const at = Math.max(0, Number(ev.timestamp_sec) || 0);
          reviewVideoUrl.value = url + "#t=" + Math.max(0, at - 10) + "," + (at + 10);
          reviewEvidenceMessage.value = "事件前后约 10 秒，可拖动时间轴查看完整原始录像。红框图与录像请结合复核。";
        } else reviewEvidenceMessage.value = "该实时任务未保存原始录像；目前仅有截图证据，不能仅凭截图确认动作过程。";
      } catch (error) {
        if (generation === reviewGeneration) reviewEvidenceMessage.value = "录像信息读取失败：" + (error.message || "请重试");
      }
    }
    async function doReview(action) {
      if (!reviewEv.value) return;
      const request = curTask.value ? taskRequest : null;
      try {
        const r = await api("/api/events/" + reviewEv.value.id + "/review", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action, comment: reviewComment.value }) });
        if (!r.ok) {
          const d = await r.json().catch(() => ({}));
          ElementPlus.ElMessage.error(d.detail || "复核操作失败");
          return;
        }
        ElementPlus.ElMessage.success({ confirmed: "已确认（正样本）", rejected: "已驳回（负样本）", escalated: "已升级上报" }[action]);
        reviewDlg.value = false;
        await loadReviewCounts();
        await loadAlertStats();
        if (view.value === "review") await loadReview();
        if (isCurrentTaskRequest(request)) await selectTask(request.id);
      } catch (e) {
        ElementPlus.ElMessage.error(e.message || "复核操作失败");
      }
    }

    // ---- 底库 ----
    async function loadGalleries() {
      try {
        const gs = (await (await api("/api/galleries?include_items=1")).json()).items;
        for (const g of gs) { g._items = g.items || []; g._newItem = ""; }
        galleries.value = gs;
      } catch (e) {}
    }
    function openGalleryDlg() { Object.assign(galleryForm, { name: "", mode: "watch" }); galleryDlg.value = true; }
    async function createGallery() {
      if (!galleryForm.name) return;
      await api("/api/galleries", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: galleryForm.name, mode: galleryForm.mode }) });
      galleryDlg.value = false; ElementPlus.ElMessage.success("已创建"); await loadGalleries();
    }
    async function delGallery(id) { try { await ElementPlus.ElMessageBox.confirm("删除该底库及其所有条目？", "确认", { type: "warning" }); } catch (e) { return; } await api("/api/galleries/" + id, { method: "DELETE" }); await loadGalleries(); ElementPlus.ElMessage.success("已删除"); }
    async function addGalleryItem(g) {
      if (!g._newItem) return;
      await api("/api/galleries/" + g.id + "/items", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ kind: "text", content: g._newItem }) });
      g._newItem = ""; g._items = (await (await api("/api/galleries/" + g.id + "/items")).json()).items;
    }
    async function delGalleryItem(iid, g) { await api("/api/gallery-items/" + iid, { method: "DELETE" }); g._items = (await (await api("/api/galleries/" + g.id + "/items")).json()).items; }

    // ---- 通知 ----
    async function pollUnread() { try { unread.value = (await (await api("/api/notifications/unread-count")).json()).count; } catch (e) {} }
    function startNotifPoll() { stopNotifPoll(); notifTimer = setInterval(pollUnread, 6000); }
    function stopNotifPoll() { if (notifTimer) { clearInterval(notifTimer); notifTimer = null; } }
    async function loadNotif() { try { notifications.value = await (await api("/api/notifications?limit=50")).json(); } catch (e) {} }
    async function readAllNotif() { await api("/api/notifications/read-all", { method: "POST" }); notifications.value.forEach(n => n.read_at = "1"); unread.value = 0; }

    // ---- 样本 ----
    const sampleLabel = ref("neg");
    async function loadSamples() { try { sampleItems.value = (await (await api("/api/samples?limit=200&label=" + sampleLabel.value)).json()).items; Object.assign(sampleStats, await (await api("/api/samples/stats")).json()); } catch (e) {} }
    async function loadExports() { try { exports.value = (await (await api("/api/samples/exports")).json()).items; } catch (e) {} }
    async function exportSamples() {
      exporting.value = true;
      try { const r = await api("/api/samples/export", { method: "POST" }); if (!r.ok) { ElementPlus.ElMessage.error("导出失败：" + (await r.text())); return; } ElementPlus.ElMessage.success("已导出：" + (await r.json()).file); await loadSamples(); await loadExports(); } catch (e) {} finally { exporting.value = false; }
    }

    // ---- 审计/存储 ----
    async function loadAudit() { try { auditItems.value = (await (await api("/api/audit?limit=300")).json()).items; } catch (e) {} }
    async function loadStorage() { try { storage.value = await (await api("/api/storage")).json(); } catch (e) {} }
    // ---- 报表/评测/压测/应急/用户 ----
    async function loadReports() { try { report.value = await (await api("/api/reports/summary?days=7")).json(); } catch (e) {} }
    async function generateReport(period) { try { reportDoc.value = await (await api("/api/reports/generate?period=" + period)).json(); } catch (e) {} }
    async function loadBenchmarkInfo() { try { benchmarkInfo.value = await (await api("/api/benchmark/info")).json(); } catch (e) {} }
    async function runBenchmark() {
      benchmarkRunning.value = true;
      try { benchmarkResult.value = await (await api("/api/benchmark/run", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ limit: 200 }) })).json(); }
      catch (e) {} finally { benchmarkRunning.value = false; }
    }
    async function runStress() {
      stressRunning.value = true; stressResult.value = null;
      try {
        const r = await api("/api/stress-test", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...stressForm }) });
        stressResult.value = await r.json();
        if (!r.ok) ElementPlus.ElMessage.error("压测失败");
      } catch (e) {} finally { stressRunning.value = false; }
    }
    async function loadEmergency() {
      try {
        emergency.value = await (await api("/api/emergency/status")).json();
        if (!emergencyExecute.det_task_id) emergencyExecute.det_task_id = "builtin9";
      } catch (e) {}
      pollEmergencySituation();
    }
    async function pollEmergencySituation() {
      if (emSituationTimer) { clearTimeout(emSituationTimer); emSituationTimer = null; }
      if (view.value !== "emergency" || !authed.value) return;
      if (!document.hidden) {
        try {
          const r = await api("/api/emergency/situation");
          if (r.ok) emSituation.value = await r.json();
        } catch (e) {}
      }
      emNow.value = Date.now();
      if (view.value === "emergency") emSituationTimer = setTimeout(pollEmergencySituation, 3000);
    }
    function selectEmergencyAlert(a) {
      if (emergencyPlanLoading.value) { ElementPlus.ElMessage.warning("方案生成中，请先停止当前生成"); return; }
      Object.assign(emergencyForm, { alert_id: String(a.id), event_id: "" });
      generateEmergencyPlan({ alert_id: a.id, event_id: null });
    }
    function cancelEmergencyPlan() {
      if (emStream.controller) emStream.controller.abort();
    }
    async function pushEmergency() {
      const r = await api("/api/emergency/push", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ alert_id: emergencyForm.alert_id }) });
      const d = await r.json(); d.ok ? ElementPlus.ElMessage.success("已推送") : ElementPlus.ElMessage.warning(d.message || "未推送");
    }
    async function askBot(q) {
      q = (q || "").trim(); if (!q || botLoading.value) return;
      botMessages.value.push({ role: "user", text: q }); botInput.value = ""; botLoading.value = true;
      try {
        const r = await api("/api/ask", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ question: q }) });
        const d = await r.json();
        botMessages.value.push({ role: "bot", text: d.answer || "（无回复）" });
      } catch (e) { botMessages.value.push({ role: "bot", text: "机器人暂时无法响应" }); }
      finally { botLoading.value = false; }
    }
    function sendBot() { askBot(botInput.value); }
    const approvalDlg = ref(false);
    const approval = reactive({ incident: {}, video_url: "", fingerprint: "", severity: "L2", evidence_reviewed: false, comment: "", payload: null });
    async function approveEmergency() {
      if (!approval.evidence_reviewed) return;
      const r = await api("/api/emergency/approve", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({event_id:approval.incident.event_id, severity:approval.severity, fingerprint:approval.fingerprint, comment:approval.comment, evidence_reviewed:true}) });
      if (!r.ok) { const d=await r.json(); ElementPlus.ElMessage.error(d.detail || "审核失败"); return; }
      approvalDlg.value=false;
      await generateEmergencyPlan(approval.payload);
    }
    async function generateEmergencyPlan(override) {
      if (emergencyPlanLoading.value) return null;
      const payload = Object.assign({
        alert_id: emergencyForm.alert_id || null,
        event_id: emergencyForm.event_id || null,
        extra: emergencyForm.extra || "",
      }, override || {});
      try {
        const params=new URLSearchParams();
        if (payload.alert_id) params.set("alert_id",payload.alert_id);
        else if (payload.event_id) params.set("event_id",payload.event_id);
        const info=await (await api("/api/emergency/assessment?"+params)).json();
        if (!info.approved) {
          Object.assign(approval, info, {severity:info.incident.severity || "L2", evidence_reviewed:false,comment:"",payload});
          approvalDlg.value=true;
          return null;
        }
      } catch (e) { ElementPlus.ElMessage.error(e.message || "无法读取事件证据"); return null; }
      const controller = new AbortController();
      Object.assign(emStream, { startedAt: Date.now(), firstTokenAt: 0, chars: 0, controller, error: "" });
      emergencyPlanLoading.value = true;
      emergencyPlan.value = null;
      const tick = setInterval(() => { emNow.value = Date.now(); }, 500);
      let result = null;
      try {
        const r = await api("/api/emergency/plan/stream", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload), signal: controller.signal });
        if (!r.ok) {
          const d = await r.json().catch(() => ({}));
          ElementPlus.ElMessage.error(d.detail || "方案生成失败");
          return null;
        }
        const reader = r.body.getReader();
        const decoder = new TextDecoder();
        let buf = "";
        const handle = (msg) => {
          if (msg.type === "context") {
            emergencyPlan.value = { incident: msg.incident, reference: msg.reference, model: msg.model, plan_markdown: "", generated_by: "streaming" };
            emergencyForm.alert_id = msg.incident.alert_id ? String(msg.incident.alert_id) : "";
            emergencyForm.event_id = msg.incident.event_id ? String(msg.incident.event_id) : "";
          } else if (msg.type === "delta" && emergencyPlan.value) {
            if (!emStream.firstTokenAt) emStream.firstTokenAt = Date.now();
            emergencyPlan.value.plan_markdown += msg.text;
            emStream.chars += msg.text.length;
          } else if (msg.type === "done") {
            result = msg;
            emergencyPlan.value = msg;
          }
        };
        for (;;) {
          const { value, done } = await reader.read();
          if (done) break;
          buf += decoder.decode(value, { stream: true });
          let i;
          while ((i = buf.indexOf("\n")) >= 0) {
            const line = buf.slice(0, i); buf = buf.slice(i + 1);
            if (line.trim()) handle(JSON.parse(line));
          }
        }
        if (result) result.fallback_used ? ElementPlus.ElMessage.warning("模型不可用，已生成兜底方案") : ElementPlus.ElMessage.success("应急方案已生成");
        else ElementPlus.ElMessage.warning("方案生成中断");
        return result;
      } catch (e) {
        if (e.name === "AbortError") ElementPlus.ElMessage.info("已停止生成");
        else if (e.message !== "unauth") ElementPlus.ElMessage.error("方案生成异常");
        return null;
      } finally {
        clearInterval(tick);
        emNow.value = Date.now();
        if (emStream.controller === controller) emStream.controller = null;
        emergencyPlanLoading.value = false;
        pollEmergencySituation();
      }
    }
    function stopEmergencyPoll() {
      if (emergencyPollTimer) {
        clearTimeout(emergencyPollTimer);
        emergencyPollTimer = null;
      }
    }
    async function pollEmergencyRun(runId) {
      try {
        const d = await (await api("/api/tasks/" + runId)).json();
        emergencyRun.value = { run_id: runId, task: d.task, events: d.events || [] };
        const event = (d.events || []).find(e => e.event_type !== "Normal") || null;
        if (event) {
          stopEmergencyPoll();
          emergencyForm.event_id = String(event.id);
          emergencyForm.alert_id = "";
          await generateEmergencyPlan({ alert_id: null, event_id: event.id, extra: emergencyExecute.extra || emergencyForm.extra || "" });
          try { const fin = await (await api("/api/tasks/" + runId)).json(); emergencyRun.value = { run_id: runId, task: fin.task, events: fin.events || [] }; } catch (e) {}
          return;
        }
        if (!isActive(d.task.status)) {
          stopEmergencyPoll();
          ElementPlus.ElMessage.warning("检测已结束，未产出风险事件");
          return;
        }
        emergencyPollTimer = setTimeout(() => pollEmergencyRun(runId), 1200);
      } catch (e) {
        if (e.message !== "unauth") emergencyPollTimer = setTimeout(() => pollEmergencyRun(runId), 2500);
      }
    }
    async function cancelEmergencyRun() {
      const run = emergencyRun.value;
      stopEmergencyPoll();
      cancelEmergencyPlan();
      if (run && run.task && isActive(run.task.status)) {
        try { await api("/api/tasks/" + run.run_id + "/cancel", { method: "POST" }); } catch (e) {}
        run.task = { ...run.task, status: "cancelled" };
      }
    }
    let emergencyExecuting = false;
    async function executeEmergencyFlow() {
      if (emergencyExecuting || (emergencyRun.value && emergencyRun.value.task && isActive(emergencyRun.value.task.status)) || emergencyPlanLoading.value) return;
      if (!emergencyExecute.source_id && !emergencyExecute.uri) { ElementPlus.ElMessage.warning("请选择数据源或填写在线视频 URL"); return; }
      emergencyExecuting = true;
      try { await executeEmergencyFlowInner(); } finally { emergencyExecuting = false; }
    }
    async function executeEmergencyFlowInner() {
      stopEmergencyPoll();
      emergencyPlan.value = null;
      emergencyRun.value = null;
      try {
        const payload = {
          source_id: emergencyExecute.source_id,
          det_task_id: emergencyExecute.det_task_id || "builtin9",
          uri: emergencyExecute.source_id ? "" : emergencyExecute.uri,
          name: emergencyExecute.name,
          kind: sourceKindForPayload(emergencyExecute),
          lat: emergencyExecute.lat,
          lng: emergencyExecute.lng,
          address: emergencyExecute.address,
          extra: emergencyExecute.extra || "",
        };
        const r = await api("/api/emergency/execute", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
        const d = await r.json();
        if (!r.ok) { ElementPlus.ElMessage.error(d.detail || "执行失败"); return; }
        emergencyRun.value = { run_id: d.run_id, task: { status: "pending", progress: 0 }, events: [] };
        ElementPlus.ElMessage.success("已启动检测，等待风险事件");
        await refreshTasks();
        pollEmergencyRun(d.run_id);
      } catch (e) {
        if (e.message !== "unauth") ElementPlus.ElMessage.error("一键执行异常");
      }
    }
    async function copyEmergencyPlan() {
      if (!emergencyPlan.value || !emergencyPlan.value.plan_markdown) return;
      try {
        await navigator.clipboard.writeText(emergencyPlan.value.plan_markdown);
        ElementPlus.ElMessage.success("方案已复制");
      } catch (e) {
        ElementPlus.ElMessage.warning("浏览器不允许自动复制");
      }
    }
    async function loadUsers() { try { usersItems.value = (await (await api("/api/users")).json()).items; } catch (e) {} }
    function openUserDlg() { Object.assign(userForm, { username: "", password: "", role: "viewer", enabled: true }); userDlg.value = true; }
    async function createUser() {
      const r = await api("/api/users", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...userForm }) });
      if (!r.ok) { ElementPlus.ElMessage.error("创建失败：" + await r.text()); return; }
      userDlg.value = false; ElementPlus.ElMessage.success("已创建"); await loadUsers();
    }
    async function delUser(id) { try { await ElementPlus.ElMessageBox.confirm("删除该用户？", "确认", { type: "warning" }); } catch (e) { return; } const r = await api("/api/users/" + id, { method: "DELETE" }); r.ok ? ElementPlus.ElMessage.success("已删除") : ElementPlus.ElMessage.error("删除失败"); await loadUsers(); }

    function tickClock() {
      const d = new Date();
      currentClock.value = d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0") + " " + String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0") + ":" + String(d.getSeconds()).padStart(2, "0");
    }
    function startClock() { tickClock(); clockTimer = setInterval(tickClock, 1000); }
    function stopClock() { if (clockTimer) { clearInterval(clockTimer); clockTimer = null; } }
    function destroyAmap() {
      if (amapMap) {
        try { amapMap.destroy(); } catch (e) {}
      }
      amapMap = null;
      amapContainer = null;
      amapTrafficLayer = null;
      amapMarkers = [];
      amapReady.value = false;
    }
    function stopAll() {
      if(clockStatusTimer!==null){clearInterval(clockStatusTimer);clockStatusTimer=null;}
      taskSessionGeneration += 1;
      if(activeUploadXHR){activeUploadXHR.abort();activeUploadXHR=null;}
      stopTaskPoll();
      taskListGeneration += 1;
      if (taskListController) { taskListController.abort(); taskListController = null; }
      clearTaskSelection();
      tasks.value = [];
      uploading.value = false;
      stopNotifPoll(); stopGpuPoll(); stopClock(); stopEmergencyPoll(); destroyAmap();
    }
    onMounted(() => { mobileNavigation.addEventListener('change', closeMobileNavigation); startClock(); boot(); });
    onBeforeUnmount(() => { mobileNavigation.removeEventListener('change', closeMobileNavigation); taskUnmounted = true; stopAll(); });

    return {
      displayText, displayCell,
      clockStatus,clockStatusText,loadClockStatus,draggedTab,moveTab,shiftTab,startTabDrag,dropTab,
      appearance,themeOptions,accentOptions,cleanAppearance,applyAppearance,saveAppearance,resetAppearance,pickBackground,
      alertSelection,alertBatchWindow,alertBatchAction,alertActionLabels,batchAlerts,
      batchSelection, batchWindow, batchReview, approvalDlg, approval, approveEmergency, sampleLabel, uploadQueueCount, safetySourceId, reviewVideoUrl, reviewEvidenceMessage, serverClockWarning, dashboardError, sourcesError, redactSourceUri, sourceStateLabel,
      rvStats, loadBenchmarkInfo, vlmRawOpen, vlmLogOpen, vlmSummary, vlmTag, vlmLogGroups, vlmLogStats, toggleVlmGroup,
      authed, authDisabled, user, loginForm, cfg, currentClock, view, menuTree, sidebarCollapsed, openTabs, dash,
      dashboardMapMode, aiQuestion, aiAnswer, amapEl, amapReady, amapLoading, amapError, hasGeoSources, hasSourceLngLat, mapFallbackTiles, mapHeatPoints, tileFallbackReady, onTileFallbackLoad, onTileFallbackError, tilePointStyle, heatPointStyle,
      sourcesItems, srcDlg, srcForm, srcEditing, previewNonce, previewDlg, previewSrc, refreshPreview, openPreview,
      detTasks, taskDlg, taskForm, objectPresets, runDlg, runForm, uploadTask, sourceKindOptions, cameraSampleUrl,
      brandTitle, brandBadge, dashTitle, gpu, gpuUtilPct, gpuMemPct,
      presetsItems, filterRules, filterStats, filterDlg, filterForm,
      alertItems, alertStats, alertFilter,
      tasks, curTask, curEvents, uploading, taskMedia, nativeVideoUrl, isStreamTask, isActive, vlmRunState, vlmLog,
      rvFilter, reviewItems, reviewDlg, reviewEv, reviewComment,
      galleries, galleryDlg, galleryForm,
      notifDrawer, notifications, unread,
      sampleItems, sampleStats, exporting, exports, auditItems, storage,
      report, reportDoc, benchmarkInfo, benchmarkResult, benchmarkRunning, stressForm, stressResult, stressRunning,
      emergency, emergencyForm, emergencyExecute, emergencyPlan, emergencyPlanLoading, emergencyRun, emergencySections, emergencyPlanCards, emSituation, emStream, emNow, emSectionProgress, emRunSteps, fmtAgo, selectEmergencyAlert, cancelEmergencyPlan, cancelEmergencyRun, botOpen, botMessages, botInput, botLoading, askBot, sendBot, usersItems, userDlg, userForm,
      isActive, statusText, statusType, evtColor, lvlColor, lvlLabel, revColor, revLabel, fmtTs, fmtDur, fmtArr,
      snapshotUrl, alertStatusLabel, alertStatusType,
      doLogin, doLogout, switchView, onMenuSelect, closeTab, badgeFor,
      setDashboardMapMode, openSourceCreate, openDashboardTarget, openRiskLevel, openMapSource, runBuiltinFromDashboard, askDashboard,
      loadDashboard, loadSources, openSourceEdit, createSource, createSourceAndRun, testSource, delSource, startSourceRun,
      loadPresets, skillsFor,
      loadDetTasks, openTaskDlg, createDetTask, delDetTask, openRunDlg, createRun,
      loadFilters, openFilterDlg, createFilterRule, delFilterRule,
      uploadProgress, uploadStageText, uploadMB, uploadEta, cancelCurrentUpload,
      customUpload, beforeUpload, selectTask, cancelTask, delTask,
      loadAlerts, ackAlert, resolveAlert, openEmergencyFromAlert,
      loadReview, openReview, doReview,
      loadGalleries, openGalleryDlg, createGallery, delGallery, addGalleryItem, delGalleryItem,
      loadNotif, readAllNotif, exportSamples,
      loadReports, generateReport, runBenchmark, runStress, loadEmergency, pushEmergency, generateEmergencyPlan, executeEmergencyFlow, copyEmergencyPlan,
      loadUsers, openUserDlg, createUser, delUser,
    };
  },
}).use(ElementPlus).mount("#app");
