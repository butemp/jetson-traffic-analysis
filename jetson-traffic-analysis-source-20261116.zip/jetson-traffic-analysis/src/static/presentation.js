// Display names only. Requests, model configuration and inference stay unchanged.
(() => {
  const rules = [["(?:qwen|通义千问|千问)[a-z0-9_.+\\-]*", "gi", "视觉研判引擎"], ["yolo[a-z0-9_.+\\-]*|rt[-_]?detr[a-z0-9_.+\\-]*|ultralytics", "gi", "目标检测引擎"], ["x3d[a-z0-9_.+\\-]*", "gi", "行为识别引擎"], ["vllm[a-z0-9_.+\\-]*", "gi", "智能推理服务"], ["tensorrt|onnx(?:runtime|\\s+runtime)?|pytorch(?:video)?|torchvision|transformers|opencv|hugging[ _-]?face|cuda|cudnn", "gi", "推理组件"], ["deepseek[a-z0-9_.+\\-]*|llama[a-z0-9_.+\\-]*|mistral[a-z0-9_.+\\-]*|chatgpt[a-z0-9_.+\\-]*|openai|claude[a-z0-9_.+\\-]*|gemini[a-z0-9_.+\\-]*", "gi", "智能研判引擎"], ["resnet[a-z0-9_.+\\-]*|mobilenet[a-z0-9_.+\\-]*|efficientnet[a-z0-9_.+\\-]*|siglip[a-z0-9_.+\\-]*|\\b(?:clip|blip|dino|sam2?|vit)\\b", "gi", "视觉识别组件"], ["nvidia|jetson|chromium|fastapi|uvicorn|starlette|pydantic|\\bvue\\b|element[ -]?plus", "gi", "系统组件"], ["sharegpt|\\blora\\b|\\bsft\\b", "gi", "样本训练"], ["\\bVLM\\b", "g", "智能研判"]].map(([pattern, flags, label]) => [new RegExp(pattern, flags), label]);
  const text = value => {
    let result = window.Vue.toDisplayString(value);
    for (const [pattern, label] of rules) result = result.replace(pattern, label);
    return result;
  };
  window.Presentation = Object.freeze({text, cell: (_row, _column, value) => text(value)});
})();
