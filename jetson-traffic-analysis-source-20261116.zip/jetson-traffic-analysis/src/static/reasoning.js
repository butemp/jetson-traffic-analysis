(() => {
const {defineComponent,ref,computed,watch,onBeforeUnmount}=Vue;
window.TrafficReasoning=defineComponent({
props:{event:{type:Object,required:true}},
setup(props){
const report=ref(null),error=ref(''),busy=ref(false),selected=ref(0),text=window.Presentation.text;
let generation=0,controller=null,timer=null;
const stateLabel=computed(()=>({basic:'基础分析',queued:'等待研判',processing:'正在对比证据',complete:'研判完成',failed:'详细研判未完成'}[report.value?.state]||'读取证据'));
const photo=computed(()=>report.value?.evidence?.[selected.value]||null);
const imageUrl=f=>'/snapshots/'+encodeURIComponent(f.snapshot_path);
const points=t=>t.points.map(p=>(p.x*1000).toFixed(1)+','+(p.y*1000).toFixed(1)).join(' ');
const stamp=i=>{const f=report.value?.evidence?.[i];return f?Number(f.timestamp_sec).toFixed(2)+'秒':'证据不足';};
function stop(){clearTimeout(timer);controller?.abort();controller=null;generation++;}
async function request(method='GET',id=props.event.id,token=generation){
const response=await fetch('/api/events/'+encodeURIComponent(id)+'/reasoning',{method,credentials:'same-origin',signal:controller.signal});
const data=await response.json();if(!response.ok)throw new Error(data.detail||'研判读取失败');
if(token!==generation)return null;report.value=data;selected.value=Math.min(selected.value,(data.evidence?.length||1)-1);return data;}
async function poll(id,token){try{const d=await request('GET',id,token);if(!d)return;
if(['queued','processing'].includes(d.state))timer=setTimeout(()=>poll(id,token),2000);else busy.value=false;
}catch(e){if(token===generation&&e.name!=='AbortError'){error.value=text(e.message);busy.value=false;}}}
async function generate(){if(busy.value)return;const token=generation,id=props.event.id;busy.value=true;error.value='';
try{const d=await request('POST',id,token);if(token!==generation)return;if(d&&d.state!=='complete')timer=setTimeout(()=>poll(id,token),1500);else busy.value=false;}
catch(e){if(token===generation&&e.name!=='AbortError'){error.value=text(e.message);busy.value=false;}}}
watch(()=>props.event.id,async id=>{stop();controller=new AbortController();report.value=null;selected.value=0;error.value='';busy.value=false;const token=generation;
try{const d=await request('GET',id,token);if(!d)return;if(['queued','processing'].includes(d.state)){busy.value=true;timer=setTimeout(()=>poll(id,token),1500);}else if(d.state!=='complete')generate();}
catch(e){if(token===generation&&e.name!=='AbortError')error.value=text(e.message);}},{immediate:true});
onBeforeUnmount(stop);
function download(){if(!report.value)return;const url=URL.createObjectURL(new Blob([JSON.stringify(report.value,null,2)],{type:'application/json;charset=utf-8'})),a=document.createElement('a');a.href=url;a.download='交通研判_事件'+props.event.id+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
return{report,error,busy,selected,stateLabel,photo,imageUrl,points,stamp,text,generate,download};},
template:`
<section class="reason-card" aria-label="结构化交通研判">
<header class="reason-head"><div><small>证据 · 时序 · 风险</small><h3>结构化交通研判</h3></div><el-tag size="small">{{text(stateLabel)}}</el-tag></header>
<p class="reason-note">按实际画面形成证据摘要。风险提示与处置建议须经人工复核。</p>
<el-alert v-if="error||report?.error" :title="text(error||report.error)" type="warning" :closable="false"/>
<div v-if="report">
<div class="reason-verdict"><strong>{{text(report.verification.verdict)}}</strong><p>{{text(report.verification.reason)}}</p></div>
<h4>01 · 可见证据</h4>
<ol v-if="report.observations.length" class="reason-list"><li v-for="(o,i) in report.observations" :key="i"><b>{{stamp(o.frame)}}</b> {{text(o.text)}}</li></ol>
<p v-else class="reason-note">{{text(report.headline)}}（初始检测描述，等待独立核验）</p>
<div class="reason-frames"><button v-for="(f,i) in report.evidence" :key="i" :class="{selected:i===selected}" @click="selected=i" type="button"><img :src="imageUrl(f)" :alt="'证据帧 '+Number(f.timestamp_sec).toFixed(2)+'秒'"/><span>{{Number(f.timestamp_sec).toFixed(2)}}秒</span></button></div>
<img v-if="photo" :src="imageUrl(photo)" class="reason-photo" :alt="'回溯画面 '+photo.timestamp_sec+'秒'"/>
<h4>02 · 时序回溯</h4><p>{{text(report.temporal.summary)}}</p>
<ul class="reason-list"><li v-for="(c,i) in report.temporal.changes" :key="i"><b>{{stamp(c.from)}} → {{stamp(c.to)}}</b> {{text(c.text)}}</li></ul>
<p v-if="report.temporal.scene_cut" class="reason-caution">画面或时间不连续，已截断更早的证据，不跨片段关联。</p>
<h4>03 · 运动轨迹线索</h4><p>{{text(report.motion.summary)}}</p>
<div v-if="report.motion.tracks.length" class="reason-track"><img :src="imageUrl(report.evidence[report.evidence.length-1])" alt="窗口末帧上的轨迹示意"/><svg viewBox="0 0 1000 1000" preserveAspectRatio="none" aria-label="画面内目标轨迹"><g v-for="t in report.motion.tracks" :key="t.id"><polyline :points="points(t)" fill="none" stroke="#22d3ee" stroke-width="3" vector-effect="non-scaling-stroke"/><circle :cx="t.points[t.points.length-1].x*1000" :cy="t.points[t.points.length-1].y*1000" r="8" fill="#fbbf24"/></g></svg></div>
<ul class="reason-list"><li v-for="t in report.motion.tracks" :key="t.id">目标 {{t.id}} · {{text(t.label)}} · {{text(t.direction)}} · {{t.points.length}}帧连续关联<br><small>画面相对位移：横向 {{t.dx_pct}}%，纵向 {{t.dy_pct}}%；不是实测速度。</small></li></ul>
<h4>04 · 风险评估与预警建议</h4><p v-if="report.risk.visible_targets && Object.keys(report.risk.visible_targets).length" class="reason-note">窗口末帧的目标检测线索：<span v-for="(n,label) in report.risk.visible_targets" :key="label">{{text(label)}} {{n}} 个；</span>数量仅供复核。</p><p><el-tag size="small" type="warning">{{text(report.risk.priority)}} 复核优先级</el-tag> {{text(report.risk.basis)}}</p>
<ul class="reason-list"><li v-for="(r,i) in report.risk.potential" :key="i">{{text(r)}}</li></ul>
<h4>建议核查</h4><ol class="reason-list"><li v-for="(r,i) in report.risk.actions" :key="i">{{text(r)}}</li></ol>
<h4>05 · 不确定性与边界</h4><ul class="reason-list reason-note"><li v-for="(r,i) in [...report.uncertainties,...report.limits]" :key="i">{{text(r)}}</li></ul>
<p v-if="report.cost.total_sec" class="reason-note">本次详细研判用时 {{report.cost.total_sec}} 秒 · 独立后台生成</p>
</div>
<footer class="reason-actions"><el-button v-if="report?.state!=='complete'" :loading="busy" @click="generate">{{busy?'后台研判中':'生成详细研判'}}</el-button><el-button v-if="report" link @click="download">下载结构化结果</el-button></footer>
</section>`});
})();
