"""ROI 警戒区掩膜：模型看掩膜图，截图保留原图。"""
import json

import cv2
import numpy as np


def parse_roi(raw):
    if not raw:
        return None
    if isinstance(raw, dict):
        return raw
    try:
        obj = json.loads(raw)
        return obj if isinstance(obj, dict) else None
    except Exception:
        return None


def _poly_to_points(poly, w, h):
    pts = []
    for p in poly or []:
        if not isinstance(p, (list, tuple)) or len(p) < 2:
            continue
        x = min(1.0, max(0.0, float(p[0])))
        y = min(1.0, max(0.0, float(p[1])))
        pts.append([int(round(x * (w - 1))), int(round(y * (h - 1)))])
    return np.array(pts, dtype=np.int32) if len(pts) >= 3 else None


def apply_roi(frame, roi_json):
    roi = parse_roi(roi_json)
    if not roi or not roi.get("enabled"):
        return frame
    h, w = frame.shape[:2]
    mask = np.zeros((h, w), dtype=np.uint8)
    include = roi.get("include") or []
    if include:
        for poly in include:
            pts = _poly_to_points(poly, w, h)
            if pts is not None:
                cv2.fillPoly(mask, [pts], 255)
    else:
        mask[:, :] = 255
    for poly in roi.get("exclude") or []:
        pts = _poly_to_points(poly, w, h)
        if pts is not None:
            cv2.fillPoly(mask, [pts], 0)
    out = frame.copy()
    out[mask == 0] = 0
    return out
