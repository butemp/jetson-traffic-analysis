"""APScheduler：按 RETENTION_CRON 每日清理过期任务（及其事件/截图/样本）。"""
import logging
from datetime import datetime, timedelta

import config
import db
import storage
import worker

log = logging.getLogger("traffic.scheduler")

_scheduler = None


def cleanup_retention() -> int:
    """删除 created_at 早于 now-RETENTION_DAYS 的已结束任务。返回删除数。"""
    if config.RETENTION_DAYS <= 0:
        return 0
    cutoff = (datetime.now() - timedelta(days=config.RETENTION_DAYS)).isoformat(timespec="seconds")
    with db._connect() as conn:
        rows = conn.execute(
            "SELECT id, file_path FROM analysis_tasks "
            "WHERE created_at < ? AND status IN ('completed','failed','cancelled')",
            (cutoff,),
        ).fetchall()
    if not rows:
        return 0
    n = 0
    for r in rows:
        tid = r["id"]
        if worker.is_running(tid):
            continue
        try:
            storage.delete_task_assets(dict(r))
            n += 1
        except OSError as exc:
            log.warning("清理任务失败 %s: %s", tid, exc)
    log.info("保留清理：删除 %d 个过期任务", n)
    return n


def _parse_cron(expr: str):
    parts = expr.split()
    if len(parts) != 5:
        raise ValueError(f"cron 需 5 字段: {expr}")
    from apscheduler.triggers.cron import CronTrigger
    return CronTrigger(minute=parts[0], hour=parts[1], day=parts[2], month=parts[3], day_of_week=parts[4])


def start() -> None:
    global _scheduler
    if config.RETENTION_DAYS <= 0:
        log.info("保留清理已关闭 (RETENTION_DAYS=0)")
        return
    try:
        from apscheduler.schedulers.background import BackgroundScheduler
        _scheduler = BackgroundScheduler(daemon=True, timezone="Asia/Shanghai")
        _scheduler.add_job(cleanup_retention, _parse_cron(config.RETENTION_CRON), id="retention")
        _scheduler.start()
        log.info("调度器已启动：保留清理 cron='%s' days=%d", config.RETENTION_CRON, config.RETENTION_DAYS)
    except Exception as e:
        log.error("调度器启动失败（不影响主服务）: %s", e)
        _scheduler = None


def shutdown() -> None:
    global _scheduler
    if _scheduler is not None:
        try:
            _scheduler.shutdown(wait=False)
        except Exception:
            pass
        _scheduler = None
