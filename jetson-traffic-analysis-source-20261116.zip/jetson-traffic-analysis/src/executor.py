"""任务执行器：按检测任务(detection_task)对数据源抽帧→分类→事件→底库匹配→告警。

worker.analyze_task 收敛为薄封装调用本模块 run()。
"""
import json
import logging
import math
import threading
import time
import traceback
from collections import deque
from datetime import datetime

import cv2

import alerts
import config
import db
import filters
import traffic_reasoning
import gallery
import local_detector
import roi
import vlm
import voting
import yolo_detector
from local_vlm import VLMCancelled
from escalation import LEVEL_LABEL, compute_severity, escalate_up
from video import VideoProcessor

log = logging.getLogger("traffic.executor")
STOP_REQUESTED = False
STOP_ON_EVENT = set()


def vlm_owner(run_id: str) -> str:
    return f"run:{run_id}"

# 每个运行的 VLM 实时输出日志（内存环形缓冲，供前端轮询展示）
_VLM_LOG_MAX_ENTRIES = 50
_VLM_LOG_MAX_RUNS = 10
_vlm_logs: dict = {}
_vlm_logs_lock = threading.Lock()


def _vlm_log_start(run_id: str) -> None:
    with _vlm_logs_lock:
        _vlm_logs[run_id] = deque(maxlen=_VLM_LOG_MAX_ENTRIES)
        while len(_vlm_logs) > _VLM_LOG_MAX_RUNS:
            _vlm_logs.pop(next(iter(_vlm_logs)))


def _vlm_log_append(run_id: str, entry: dict) -> None:
    with _vlm_logs_lock:
        buf = _vlm_logs.get(run_id)
        if buf is not None:
            buf.append(entry)


def get_vlm_log(run_id: str) -> list:
    with _vlm_logs_lock:
        return list(_vlm_logs.get(run_id, ()))


def drop_vlm_log(run_id: str) -> None:
    with _vlm_logs_lock:
        _vlm_logs.pop(run_id, None)


def _progress(idx: int, total: int) -> int:
    if total <= 0:
        return 1
    return int(idx / total * 100)


def _draw_yolo_boxes(frame, dets):
    """在帧上画 YOLO 检测框 + 标签(英文，避免 OpenCV putText 中文乱码)。"""
    if not dets:
        return frame
    out = frame.copy()
    for d in dets:
        bbox = d.get("bbox")
        if not bbox or len(bbox) != 4:
            continue
        x1, y1, x2, y2 = (int(v) for v in bbox)
        name = str(d.get("name") or d.get("class") or "?")
        conf = float(d.get("confidence") or 0)
        label = f"{name} {conf:.2f}"
        color = (0, 255, 0)  # 绿框
        cv2.rectangle(out, (x1, y1), (x2, y2), color, 2)
        (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)
        cv2.rectangle(out, (x1, max(0, y1 - th - 8)), (x1 + tw + 6, y1), color, -1)
        cv2.putText(out, label, (x1 + 3, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 2)
    return out


def _scale_detections(dets, from_shape, to_shape):
    if not dets or from_shape[:2] == to_shape[:2]:
        return dets
    fh, fw = from_shape[:2]
    th, tw = to_shape[:2]
    sx = tw / max(1, fw)
    sy = th / max(1, fh)
    out = []
    for d in dets:
        item = dict(d)
        bbox = item.get("bbox")
        if bbox and len(bbox) == 4:
            item["bbox"] = [bbox[0] * sx, bbox[1] * sy, bbox[2] * sx, bbox[3] * sy]
        out.append(item)
    return out


def _save_snapshot(run_id: str, idx: int, frame, yolo_dets=None) -> str:
    img = _draw_yolo_boxes(frame, yolo_dets) if yolo_dets else frame
    img = vlm.resize_by_max_edge(img, config.SNAPSHOT_MAX_EDGE)
    fname = f"{run_id}_f{idx:05d}.jpg"
    if not cv2.imwrite(str(config.SNAPSHOT_DIR / fname), img, [cv2.IMWRITE_JPEG_QUALITY, config.SNAPSHOT_QUALITY]):
        raise RuntimeError("交通事件截图保存失败")
    return fname


SAFETY_LABELS = {"knife": "刀具", "fight": "打架斗殴"}


def _safety_confidence(event):
    field = "knife_probability" if event["kind"] == "knife" else "action_score"
    top = max((box.get(field) or box.get("score") or 0. for box in event["boxes"]), default=0.)
    return ("高" if top >= .75 else "中" if top >= .45 else "低"), top


def _safety_summary(event, top):
    if event["kind"] == "knife":
        return f"刀具候选已通过二次视觉核验（概率 {top:.2f}），等待大模型补充描述"
    return f"检测到疑似肢体冲突，涉及 {len(event['track_ids'])} 人（动作分 {top:.2f}），等待大模型核实描述"


def _run_safety(run_id: str, run_row: dict, det: dict, file_path: str) -> None:
    """离线逐帧刀具/打架检测：复用巡检的共享 TensorRT + X3D 模型，事件入库后异步补充大模型描述。"""
    from concurrent.futures import ThreadPoolExecutor, wait as wait_futures
    import video
    from streaming import StreamModels, StreamDetector, render_frame, description_frames, \
        description_messages, description_views, parse_description

    owner = vlm_owner(run_id)
    cancelled = lambda: STOP_REQUESTED or db.get_status(run_id) in (None, config.STATUS_CANCELLED)
    capture = cv2.VideoCapture(file_path)
    if not capture.isOpened():
        db.update_status(run_id, config.STATUS_FAILED, "无法打开视频源"); return
    live = video.is_stream_path(file_path)
    fps = capture.get(cv2.CAP_PROP_FPS) or 25.
    if not math.isfinite(fps) or fps <= 0 or fps > 240:
        fps = 25.
    total = 0 if live else int(capture.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    stride = max(1, round(fps / max(1., config.SAFETY_OFFLINE_FPS)))
    pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix="safety-describe")
    pending = []
    events = processed = described = 0
    frame_index = -1
    last_pts = -1.
    interrupted = event_found = False
    try:
        models = StreamModels(("fight", "knife"), .4, True, "trained-u8")
        models.warmup()
        detector = StreamDetector(models, fight_threshold=.65, async_action=False, async_knife_verify=False)
        detector.session_id = run_id
        if not db.update_status(run_id, config.STATUS_PROCESSING):
            return
        if total <= 0:
            db.update_progress(run_id, 1)
        log.info("[%s] 逐帧刀具/打架检测 fps=%.1f 步长=%d 总帧=%d", run_id, fps, stride, total)

        def describe(event_id, event, views, etype):
            if cancelled():
                return
            started = time.monotonic()
            try:
                raw = vlm.get_engine().generate(description_messages(event, views), max_tokens=192,
                                                owner=owner, priority="batch")
                result = parse_description(raw)
                text = result["description"] + (f"；疑点：{result['uncertainty']}" if result.get("uncertainty") else "")
                db.set_event_description(event_id, text)
                status, output = "called", raw
            except VLMCancelled:
                return
            except Exception as error:
                text, status, output = f"大模型描述失败：{error}", "error", str(error)
            latency = round((time.monotonic() - started) * 1000)
            db.update_task_vlm_result(run_id, status=status, output=output, event_type=etype,
                                      confidence=_safety_confidence(event)[0])
            _vlm_log_append(run_id, {"t": datetime.now().strftime("%H:%M:%S"), "ts": round(float(event["start_pts"]), 1),
                                     "status": status, "event_type": etype, "confidence": _safety_confidence(event)[0],
                                     "has_event": True, "summary": text[:160], "latency_ms": latency, "output": output[:600]})

        while True:
            if processed % 5 == 0 and cancelled():
                interrupted = True
                break
            ok = True
            for _ in range(stride - 1):
                ok = capture.grab()
                frame_index += 1
                if not ok:
                    break
            if ok:
                ok, frame = capture.read()
                frame_index += 1
            if not ok or frame is None:
                break
            pts = float(capture.get(cv2.CAP_PROP_POS_MSEC) or 0.) / 1000.
            if not math.isfinite(pts) or pts <= last_pts:
                pts = last_pts + stride / fps if last_pts >= 0 else frame_index / fps
            last_pts = pts
            result = detector.step(frame, frame_index, pts)
            evidence = result.pop("_event_evidence", {})
            processed += 1
            for event in result["new_events"]:
                if cancelled():
                    interrupted = True
                    break
                etype = SAFETY_LABELS[event["kind"]]
                label, top = _safety_confidence(event)
                source = evidence.get(event["id"])
                event_frame = source["frame"] if source else frame
                event_pts = source["pts"] if source else pts
                event_seq = source["seq"] if source else frame_index
                annotated = vlm.resize_by_max_edge(render_frame(event_frame, {"boxes": event["boxes"]}), config.SNAPSHOT_MAX_EDGE)
                snap = f"{run_id}_f{event_seq:06d}_{event['kind']}.jpg"
                if not cv2.imwrite(str(config.SNAPSHOT_DIR / snap), annotated, [cv2.IMWRITE_JPEG_QUALITY, config.SNAPSHOT_QUALITY]):
                    raise RuntimeError("事件截图写入失败，未创建无证据告警")
                sev = compute_severity(etype, label, True)
                summary = _safety_summary(event, top)
                eid = db.insert_event(run_id, etype, event_pts, summary, snap, label, severity=sev, det_task_id=det["id"],
                                      source_id=run_row.get("source_id"))
                with db._write_lock, db._connect() as connection:
                    evidence_record={"boxes":event.get("boxes",[]), "frame_seq":event_seq, "timestamp_sec":event_pts,
                                     "width":int(event_frame.shape[1]), "height":int(event_frame.shape[0]), "model":det["id"]}
                    connection.execute("UPDATE traffic_events SET evidence_json=? WHERE id=?",(json.dumps(evidence_record,ensure_ascii=False),eid))
                events += 1
                log.info("[%s] %6.2fs [%s/%s] %s", run_id, event_pts, etype, sev or "-", summary)
                _vlm_log_append(run_id, {"t": datetime.now().strftime("%H:%M:%S"), "ts": round(event_pts, 1), "status": "detected",
                                         "event_type": etype, "confidence": label, "has_event": True,
                                         "summary": summary.replace("，等待大模型核实描述", ""), "latency_ms": None, "output": summary})
                if alerts.should_alert(sev, None):
                    try:
                        alerts.create_from_event(eid, run_row.get("source_id"), det["id"], sev or "L2",
                                                 {"event_type": etype, "description": summary}, snap)
                    except Exception as e:
                        log.warning("建告警失败: %s", e)
                if config.VLM_ENABLED:
                    views = description_views(description_frames(detector.history, event_pts, event_frame, event["boxes"]))
                    pending.append(pool.submit(describe, eid, event, views, etype))
                    described += 1
                if run_id in STOP_ON_EVENT:
                    event_found = True
                    break
            if interrupted or event_found:
                break
            if processed % 15 == 0:
                if total > 0:
                    db.update_progress(run_id, min(99, int(frame_index / total * 100)))
                db.update_task_metrics(run_id, sampled_frames=processed, yolo_checked_frames=processed,
                                       vlm_checked_frames=described)
        db.update_task_metrics(run_id, sampled_frames=processed, yolo_checked_frames=processed, vlm_checked_frames=described)
        if not interrupted and not cancelled() and pending:
            wait_futures(pending, timeout=config.VLM_TIMEOUT + 5)
        if db.get_status(run_id) in (None, config.STATUS_CANCELLED):
            return
        if STOP_REQUESTED:
            db.update_status(run_id, config.STATUS_FAILED, "服务停止中断")
        elif interrupted:
            return
        elif event_found or total > 0:
            db.update_progress(run_id, 100)
            db.update_status(run_id, config.STATUS_COMPLETED)
            log.info("[%s] 逐帧检测完成 %d 帧 %d 事件", run_id, processed, events)
        else:
            db.update_status(run_id, config.STATUS_FAILED, "直播流已断开，分析停止")
    finally:
        if interrupted or cancelled():
            vlm.cancel(owner)
        pool.shutdown(wait=False, cancel_futures=True)
        if 'detector' in locals():
            detector.close()
        capture.release()


def run(run_id: str) -> None:
    log.info("[%s] 开始分析", run_id)
    _vlm_log_start(run_id)
    try:
        run_row = db.get_task(run_id)
        if not run_row:
            log.error("[%s] 运行不存在", run_id); return
        if db.get_status(run_id) == config.STATUS_CANCELLED:
            log.info("[%s] 执行前已取消", run_id); return

        det = db.get_task_det(run_row.get("det_task_id") or db.BUILTIN_TASK_ID)
        if not det:
            db.update_status(run_id, config.STATUS_FAILED, "检测任务不存在"); return
        src = db.get_source(run_row["source_id"]) if run_row.get("source_id") else None
        file_path = src["uri"] if src else run_row["file_path"]
        if det.get("kind") == "safety_stream":
            _run_safety(run_id, run_row, det, file_path)
            return

        owner = vlm_owner(run_id)
        interrupted = False
        event_found = False
        interval = det.get("interval_sec") or config.SAMPLE_INTERVAL_SEC
        cancelled = lambda: STOP_REQUESTED or db.get_status(run_id) in (None, config.STATUS_CANCELLED)
        proc = VideoProcessor(file_path, interval_sec=interval, cancelled=cancelled)
        base_interval = proc.interval_sec
        if not db.update_status(run_id, config.STATUS_PROCESSING):
            return
        total = proc.estimated_frames
        if total <= 0:
            db.update_progress(run_id, 1)

        client = vlm.get_engine() if config.VLM_ENABLED else None
        try:
            target_objects = json.loads(det["target_objects"]) if det.get("target_objects") else None
        except Exception:
            target_objects = None
        gallery_groups = gallery.split_for_task(det)
        watch_descs = [i["content"] for i in gallery_groups["watch"]]
        allow_descs = [i["content"] for i in gallery_groups["allow"]]
        is_builtin = det["kind"] == "builtin9"
        reasoning_buffer = traffic_reasoning.EvidenceBuffer() if is_builtin else None

        events = 0
        idx = 0
        sampled_frames = 0
        yolo_checked_frames = 0
        vlm_checked_frames = 0
        metrics_every = max(1, config.TASK_METRICS_UPDATE_EVERY_FRAMES)

        def flush_metrics() -> None:
            db.update_task_metrics(
                run_id,
                sampled_frames=sampled_frames,
                yolo_checked_frames=yolo_checked_frames,
                vlm_checked_frames=vlm_checked_frames,
            )

        def record_vlm_result(result: dict, frame_ts: float = 0.0) -> None:
            called = bool(result.get("_vlm_called"))
            has_error = bool(result.get("_vlm_error"))
            if called and has_error:
                status = "error"
            elif called:
                status = "called"
            elif not config.VLM_ENABLED:
                status = "disabled"
            else:
                status = "skipped"
            output = (result.get("raw") or result.get("description") or "").strip()
            if not output and result.get("_vlm_skip_reason"):
                output = f"本轮未调用VLM：{result.get('_vlm_skip_reason')}"
            summary = str(result.get("description") or "").strip()
            if status == "error":
                summary = summary.replace("<模型输出解析失败>:", "").strip() or "模型输出未通过格式校验"
            elif not called:
                summary = result.get("_vlm_skip_reason") or "本轮未调用模型"
            db.update_task_vlm_result(
                run_id,
                status=status,
                output=output,
                event_type=result.get("event_type") or "Normal",
                confidence=result.get("confidence") or "低",
            )
            _vlm_log_append(run_id, {
                "t": datetime.now().strftime("%H:%M:%S"),
                "ts": round(float(frame_ts), 1),
                "status": status,
                "event_type": result.get("event_type") or "Normal",
                "confidence": result.get("confidence") or "低",
                "has_event": bool(result.get("has_event")),
                "summary": summary[:160],
                "latency_ms": result.get("_vlm_latency_ms"),
                "output": output[:600],
            })

        def adapt_stream_interval(process_sec: float) -> None:
            if not proc.is_stream or not config.STREAM_ADAPTIVE_INTERVAL_ENABLED:
                return
            budget = max(0.1, config.STREAM_INFERENCE_BUDGET_SEC)
            step = max(0.1, config.STREAM_ADAPTIVE_INTERVAL_STEP_SEC)
            max_interval = max(base_interval, config.STREAM_MAX_SAMPLE_INTERVAL_SEC)
            old = proc.interval_sec
            if process_sec > budget and old < max_interval:
                proc.interval_sec = min(max_interval, old + step)
            elif process_sec < budget * 0.45 and old > base_interval:
                proc.interval_sec = max(base_interval, old - step)
            if proc.interval_sec != old:
                log.info("[%s] 自适应调整抽帧间隔 %.2fs -> %.2fs (本轮 %.2fs)", run_id, old, proc.interval_sec, process_sec)

        for ts, frame in proc.iter_frames():
            cycle_started = time.monotonic()
            if cancelled():
                interrupted = True
                log.info("[%s] 取消，已处理 %d 帧", run_id, idx); break

            model_frame = roi.apply_roi(frame, det.get("roi_json"))
            if proc.is_stream:
                model_frame = vlm.resize_by_max_edge(model_frame, config.STREAM_ANALYSIS_MAX_EDGE)
            sampled_frames += 1
            if reasoning_buffer is not None:
                reasoning_buffer.add(float(ts), model_frame)

            yolo_dets = []
            yolo_active = False
            if config.VOTING_MODE != "vlm_only" and yolo_detector.enabled():
                detection_result = yolo_detector.detect(model_frame)
                yolo_dets = detection_result.detections
                yolo_active = detection_result.healthy
                yolo_checked_frames += 1
            yolo_events = yolo_detector.risk_event_candidates(yolo_dets, target_objects if not is_builtin else None)
            yolo_hint = yolo_detector.summarize(yolo_dets)

            if config.VLM_ENABLED and voting.should_call_vlm(idx, yolo_dets, yolo_events, yolo_active=yolo_active):
                if cancelled():
                    interrupted = True
                    break
                vlm_checked_frames += 1
                vlm_started = time.monotonic()
                try:
                    if is_builtin:
                        result = vlm.classify_frame(model_frame, client, context=yolo_hint, owner=owner, priority="batch")
                    else:
                        prompt = det["prompt"] + (f"\n\n辅助信息：{yolo_hint}" if yolo_hint else "")
                        result = vlm.classify_custom(model_frame, prompt, target_objects, client, owner=owner, priority="batch")
                except VLMCancelled:
                    interrupted = True
                    break
                result["_vlm_called"] = True
                result["_vlm_latency_ms"] = round((time.monotonic() - vlm_started) * 1000)
                if str(result.get("description", "")).startswith("<模型输出解析失败>"):
                    result["_vlm_error"] = True
            elif not config.VLM_ENABLED and not yolo_detector.enabled():
                result = local_detector.classify_without_model(det, target_objects)
                result["_vlm_called"] = False
                result["_vlm_skip_reason"] = "VLM未开启"
            else:
                skip_reason = "VLM未开启" if not config.VLM_ENABLED else "未达到VLM复判触发条件"
                result = {
                    "has_event": False,
                    "event_type": "Normal",
                    "description": f"{skip_reason}，跳过VLM复判",
                    "confidence": "低",
                    "raw": "",
                    "_vlm_called": False,
                    "_vlm_skip_reason": skip_reason,
                }
            if cancelled():
                interrupted = True
                break
            record_vlm_result(result, frame_ts=ts)
            result = voting.fuse(result, yolo_events)

            if result["has_event"]:
                blocked, rule = filters.should_filter(result, det.get("id"), run_row.get("source_id"))
                if blocked:
                    log.info("[%s] %6.2fs 被误报规则 #%s 过滤: %s", run_id, ts, rule.get("id"), result["description"])
                    idx += 1
                    db.update_progress(run_id, _progress(idx, total))
                    continue
                if allow_descs:
                    if not config.VLM_ENABLED:
                        allow_match = None
                    else:
                        allow_match = None
                        try:
                            allow_match = vlm.match_gallery(model_frame, allow_descs, engine=client, owner=owner, priority="batch")
                        except VLMCancelled:
                            interrupted = True
                            break
                        except Exception as e:
                            log.warning("白名单匹配失败: %s", e)
                    if allow_match:
                        log.info("[%s] %6.2fs 白名单命中 <%s>，抑制事件", run_id, ts, allow_match)
                        idx += 1
                        db.update_progress(run_id, _progress(idx, total))
                        continue
                snapshot_dets = _scale_detections(yolo_dets, model_frame.shape, frame.shape)
                snap = _save_snapshot(run_id, idx, frame, snapshot_dets)
                sev = compute_severity(result["event_type"], result["confidence"], True)
                gmatch = None
                if watch_descs and config.VLM_ENABLED:
                    try:
                        gmatch = vlm.match_gallery(model_frame, watch_descs, engine=client, owner=owner, priority="batch")
                    except VLMCancelled:
                        interrupted = True
                        break
                    except Exception as e:
                        log.warning("底库匹配失败: %s", e)
                    if gmatch:
                        sev = escalate_up(sev) if sev else "L2"
                if cancelled():
                    interrupted = True
                    break
                eid = db.insert_event(
                    run_id, result["event_type"], float(ts), result["description"], snap,
                    result["confidence"], severity=sev, det_task_id=det["id"],
                    source_id=run_row.get("source_id"), gallery_match=gmatch,
                )
                with db._write_lock, db._connect() as connection:
                    evidence_record={"boxes":snapshot_dets, "coordinate_space":"pixels", "timestamp_sec":float(ts),
                                     "width":int(frame.shape[1]), "height":int(frame.shape[0]), "model":det["id"]}
                    connection.execute("UPDATE traffic_events SET evidence_json=? WHERE id=?",(json.dumps(evidence_record,ensure_ascii=False),eid))
                if reasoning_buffer is not None:
                    try:traffic_reasoning.register(eid, reasoning_buffer)
                    except Exception as exc:log.warning("结构化证据保存失败: %s", exc)
                events += 1
                log.info("[%s] %6.2fs [%s/%s]%s %s", run_id, ts, result["event_type"], sev or "-",
                         (f" <底库:{gmatch}>" if gmatch else ""), result["description"])
                if alerts.should_alert(sev, gmatch):
                    try:
                        alerts.create_from_event(eid, run_row.get("source_id"), det["id"], sev or "L2", result, snap)
                    except Exception as e:
                        log.warning("建告警失败: %s", e)
                if run_id in STOP_ON_EVENT:
                    event_found = True
                    idx += 1
                    log.info("[%s] 应急模式检出首个事件，停止分析", run_id)
                    break
            idx += 1
            if idx % metrics_every == 0:
                db.update_progress(run_id, _progress(idx, total))
                flush_metrics()
            adapt_stream_interval(time.monotonic() - cycle_started)

        flush_metrics()
        if db.get_status(run_id) in (None, config.STATUS_CANCELLED):
            return
        if STOP_REQUESTED:
            db.update_status(run_id, config.STATUS_FAILED, "服务停止中断")
        elif interrupted:
            return
        elif event_found or total > 0:
            db.update_progress(run_id, 100)
            db.update_status(run_id, config.STATUS_COMPLETED)
            if is_builtin:traffic_reasoning.finish_run(run_id)
            log.info("[%s] 完成 %d 帧 %d 事件", run_id, idx, events)
        else:
            db.update_status(run_id, config.STATUS_FAILED, "直播流已断开，分析停止")
            log.warning("[%s] 直播流停止 %d 帧 %d 事件", run_id, idx, events)
    except Exception as e:
        log.error("[%s] 失败: %s\n%s", run_id, e, traceback.format_exc())
        db.update_status(run_id, config.STATUS_FAILED, str(e))
