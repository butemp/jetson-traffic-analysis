"""Public source metadata must not expose device credentials."""
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
import json
import re
import struct
import copy
import tarfile
import tempfile
from pathlib import Path


# Presentation-only vocabulary. Never apply to model inputs, stored evidence,
# credentials, resource identifiers, or the inference configuration.
DISPLAY_RULES = [
    (r'(?i)(?:qwen|通义千问|千问)[a-z0-9_.+\-]*', '视觉研判引擎'),
    (r'(?i)yolo[a-z0-9_.+\-]*|rt[-_]?detr[a-z0-9_.+\-]*|ultralytics', '目标检测引擎'),
    (r'(?i)x3d[a-z0-9_.+\-]*', '行为识别引擎'),
    (r'(?i)vllm[a-z0-9_.+\-]*', '智能推理服务'),
    (r'(?i)tensorrt|onnx(?:runtime|\s+runtime)?|pytorch(?:video)?|torchvision|transformers|opencv|hugging[ _-]?face|cuda|cudnn', '推理组件'),
    (r'(?i)deepseek[a-z0-9_.+\-]*|llama[a-z0-9_.+\-]*|mistral[a-z0-9_.+\-]*|chatgpt[a-z0-9_.+\-]*|openai|claude[a-z0-9_.+\-]*|gemini[a-z0-9_.+\-]*', '智能研判引擎'),
    (r'(?i)resnet[a-z0-9_.+\-]*|mobilenet[a-z0-9_.+\-]*|efficientnet[a-z0-9_.+\-]*|siglip[a-z0-9_.+\-]*|\b(?:clip|blip|dino|sam2?|vit)\b', '视觉识别组件'),
    (r'(?i)nvidia|jetson|chromium|fastapi|uvicorn|starlette|pydantic|\bvue\b|element[ -]?plus', '系统组件'),
    (r'(?i)sharegpt|\blora\b|\bsft\b', '样本训练'),
    (r'\bVLM\b', '智能研判'),
]
_DISPLAY_PATTERNS = [(re.compile(pattern), label) for pattern, label in DISPLAY_RULES]
_PUBLIC_KEYS = {'yolo_checked_frames': 'edge_checked_frames',
                'x3d_queue': 'action_queue', 'x3d_mean_batch': 'action_mean_batch'}
_RESOURCE_KEYS = {'id', 'file', 'filename', 'path', 'file_path', 'snapshot_path', 'image_path',
                  'uri', 'url', 'ws_path', 'api_url', 'ui_url', 'base_url', 'image', 'fingerprint',
                  'sha256', 'engine_sha256', 'key', 'token', 'password', 'pass', 'params_json'}


def display_text(value):
    if not isinstance(value, str):
        return value
    for pattern, label in _DISPLAY_PATTERNS:
        value = pattern.sub(label, value)
    return value


def display_data(value, key=''):
    """Copy response data; opaque identifiers remain usable by the client."""
    if isinstance(value, dict):
        # A ready message exposes capabilities, not weight files or engine paths.
        if key == 'models':
            labels = {'knife': '刀具检测', 'people': '人员定位', 'fight': '打斗行为识别'}
            return {name: {'name': labels.get(name, '视觉检测'), 'status': 'ready'} for name in value}
        return {_PUBLIC_KEYS.get(k, k): display_data(v, k) for k, v in value.items()}
    if isinstance(value, list):
        return [display_data(v, key) for v in value]
    if not isinstance(value, str):
        return value
    if key in _RESOURCE_KEYS or key.endswith(('_id', '_path', '_url')):
        return value
    if key == 'voting_mode' and value == 'yolo_gate':
        return 'edge_gate'
    if key in {'model', 'model_name'}:
        return display_text(value)
    if key in {'backend', 'model_backend'}:
        return '本地推理服务' if value else value
    return display_text(value)


def _display_json(body):
    return json.dumps(display_data(json.loads(body)), ensure_ascii=False, separators=(',', ':')).encode('utf-8')


def display_archive(path):
    """Create a disposable download copy; keep the original dataset intact."""
    with tempfile.NamedTemporaryFile(suffix='.tar.gz', delete=False) as tmp:
        output = Path(tmp.name)
    try:
        with tarfile.open(path, 'r:gz') as source, tarfile.open(output, 'w:gz') as target:
            for member in source:
                if not member.isfile():
                    target.addfile(member)
                    continue
                with source.extractfile(member) as data:
                    if member.name.endswith(('.jsonl', '.txt', '.md')):
                        with tempfile.TemporaryFile() as rendered:
                            for line in data:
                                if member.name.endswith('.jsonl') and line.strip():
                                    rendered.write(_display_json(line) + b'\n')
                                else:
                                    rendered.write(display_text(line.decode('utf-8')).encode('utf-8'))
                            info = copy.copy(member)
                            info.size = rendered.tell()
                            rendered.seek(0)
                            target.addfile(info, rendered)
                    else:
                        target.addfile(member, data)
        return output
    except BaseException:
        output.unlink(missing_ok=True)
        raise


class PresentationMiddleware:
    """Sanitize outgoing display payloads only; leave requests and media intact."""
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope['type'] == 'websocket':
            async def ws_send(message):
                if message['type'] == 'websocket.send':
                    message = dict(message)
                    if message.get('text'):
                        message['text'] = _display_json(message['text']).decode('utf-8')
                    elif message.get('bytes'):
                        packet = message['bytes']
                        size = struct.unpack('>I', packet[:4])[0]
                        header = _display_json(packet[4:4+size])
                        message['bytes'] = struct.pack('>I', len(header)) + header + packet[4+size:]
                await send(message)
            return await self.app(scope, receive, ws_send)
        if scope['type'] != 'http' or not scope.get('path', '').startswith('/api/'):
            return await self.app(scope, receive, send)
        mode, start, pending, delta = '', None, b'', ''

        async def http_send(message):
            nonlocal mode, start, pending, delta
            if message['type'] == 'http.response.start':
                content_type = dict(message['headers']).get(b'content-type', b'').decode()
                mode = ('lines' if 'application/x-ndjson' in content_type else
                        'json' if 'application/json' in content_type else
                        'text' if 'text/csv' in content_type else '')
                if not mode:
                    return await send(message)
                start = dict(message)
                start['headers'] = [(k, v) for k, v in message['headers']
                                    if k.lower() not in (b'content-length', b'etag')]
                return await send(start)
            if message['type'] != 'http.response.body' or not mode:
                return await send(message)
            pending += message.get('body', b'')
            if mode == 'lines':
                output = []
                while b'\n' in pending:
                    line, pending = pending.split(b'\n', 1)
                    if not line.strip():
                        continue
                    item = json.loads(line)
                    # Keep an unfinished word until the next chunk so a model
                    # name split between deltas cannot leak through streaming.
                    if item.get('type') == 'delta':
                        text = delta + item.get('text', '')
                        match = re.search(r'[A-Za-z0-9_.+\-\u4e00-\u9fff]+$', text)
                        cut = match.start() if match else len(text)
                        delta = text[cut:]
                        if cut:
                            output.append({'type': 'delta', 'text': display_text(text[:cut])})
                    else:
                        if delta:
                            output.append({'type': 'delta', 'text': display_text(delta)})
                            delta = ''
                        output.append(display_data(item))
                if not message.get('more_body'):
                    if pending.strip():
                        output.append(display_data(json.loads(pending)))
                    if delta:
                        output.append({'type': 'delta', 'text': display_text(delta)})
                    pending, delta = b'', ''
                body = b''.join(json.dumps(v, ensure_ascii=False).encode('utf-8') + b'\n' for v in output)
                return await send({**message, 'body': body})
            if not message.get('more_body'):
                body = _display_json(pending) if mode == 'json' else display_text(pending.decode('utf-8')).encode('utf-8')
                return await send({**message, 'body': body})
        await self.app(scope, receive, http_send)



def public_uri(uri):
    if not uri or '://' not in uri:
        return uri
    try:
        p = urlsplit(uri)
        query = [(k, '***' if k.lower() in {'password', 'passwd', 'token', 'access_token', 'secret', 'api_key'} else v)
                 for k, v in parse_qsl(p.query, keep_blank_values=True)]
        return urlunsplit((p.scheme, p.netloc.rsplit('@', 1)[-1], p.path,
                          urlencode(query) if query else p.query, p.fragment))
    except ValueError:
        return '[无效地址]'


def source_view(source):
    result = dict(source)
    original = result.get('uri', '')
    result['uri'] = public_uri(original)
    result['has_credentials'] = result['uri'] != original
    return result


def task_view(task):
    result = dict(task)
    result['file_path'] = public_uri(result.get('file_path', ''))
    return result
