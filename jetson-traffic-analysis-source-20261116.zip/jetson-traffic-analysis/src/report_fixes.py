"""Evidence-based incident approval and bounded review helpers."""
import hashlib
import json
from pathlib import Path
from urllib.parse import quote
import db
import config
from datetime import datetime


def validate_batch(ids, window):
    if window not in (300,600) or not isinstance(ids,list) or not 1 <= len(ids) <= 100 or any(type(i) is not int for i in ids) or len(set(ids)) != len(ids):
        raise ValueError('请选择1至100条不同事件，时间窗口仅支持5或10分钟')
    events=[db.get_event(i) for i in ids]
    if any(e is None or e['review_status'] != 'pending' for e in events):
        raise ValueError('存在已处理或不存在的事件，请刷新后重选')
    validate_event_window(events,window)
    return events


def validate_event_window(events,window):
    if len({e['task_id'] for e in events}) != 1:
        raise ValueError('批量复核仅支持同一视频或巡检任务')
    times=[float(e['timestamp_sec']) for e in events]
    dates=[datetime.fromisoformat(e['created_at']).timestamp() for e in events]
    if max(times)-min(times)>window or max(dates)-min(dates)>window:
        raise ValueError('所选事件超出限定时间窗口')
    return events


def validate_alert_batch(ids,window,action):
    if action not in ('ack','resolve','confirmed','rejected'):
        raise ValueError('不支持的告警批量操作')
    if window not in (300,600) or not isinstance(ids,list) or not 1<=len(ids)<=100 or any(type(i) is not int for i in ids) or len(set(ids))!=len(ids):
        raise ValueError('请选择1至100条不同告警，时间窗口仅支持5或10分钟')
    alerts=[db.get_alert(i) for i in ids]
    allowed=('active',) if action=='ack' else ('active','acked')
    if any(not a or a['status'] not in allowed for a in alerts):
        raise ValueError('告警不存在或已被处理，请刷新后重选')
    event_ids=list(dict.fromkeys(a.get('event_id') for a in alerts))
    events=[db.get_event(i) for i in event_ids]
    if any(not e for e in events):raise ValueError('告警关联证据缺失，请单独核查')
    validate_event_window(events,window)
    created=[datetime.fromisoformat(a['created_at']).timestamp() for a in alerts]
    if max(created)-min(created)>window:raise ValueError('告警超出限定时间窗口')
    if action in ('confirmed','rejected') and any(e['review_status']!='pending' for e in events):
        raise ValueError('所选事件已有复核结果，请到复审任务查看')
    return alerts,events


def init():
    with db._connect() as c:
        c.execute('CREATE TABLE IF NOT EXISTS emergency_approvals(event_id INTEGER PRIMARY KEY, fingerprint TEXT, severity TEXT, reviewer TEXT, comment TEXT, approved_at TEXT)')


def fingerprint(event):
    return hashlib.sha256(json.dumps({k:event.get(k) for k in ('id','event_type','description','confidence','snapshot_path','review_status')}, sort_keys=True,ensure_ascii=False).encode()).hexdigest()


def assessment(ctx):
    event = ctx.get('event')
    if not event:
        raise ValueError('事件证据已不存在，不能生成处置方案')
    with db._connect() as c:
        approval = c.execute('SELECT * FROM emergency_approvals WHERE event_id=?', (event['id'],)).fetchone()
    approved = bool(approval and approval['fingerprint'] == fingerprint(event) and event.get('review_status') != 'rejected')
    task=db.get_task(event['task_id'])
    p=Path((task or {}).get('file_path') or '')
    video_url=''
    if p.is_file() and p.resolve().parent == config.UPLOAD_DIR.resolve():
        at=max(0.,float(event.get('timestamp_sec') or 0))
        video_url='/uploads/'+quote(p.name)+'#t='+str(max(0,at-10))+','+str(at+10)
    return {'incident':ctx['incident'], 'approved':approved,
            'approved_severity':approval['severity'] if approved else None,
            'video_url':video_url, 'fingerprint':fingerprint(event)}


def approve(event_id, severity, reviewer, comment, expected_fingerprint):
    if severity not in ('L1','L2','L3'):
        raise ValueError('请选择L1、L2或L3风险等级')
    with db._write_lock, db._connect() as c:
        c.execute('BEGIN IMMEDIATE')
        event=c.execute('SELECT * FROM traffic_events WHERE id=?',(event_id,)).fetchone()
        if not event or event['review_status']=='rejected':
            raise ValueError('事件不存在或已驳回，不能审批应急方案')
        if fingerprint(dict(event)) != expected_fingerprint:
            raise ValueError('事件证据已更新，请重新查阅后审核')
        c.execute('INSERT OR REPLACE INTO emergency_approvals VALUES(?,?,?,?,?,?)',
                  (event_id,fingerprint(dict(event)),severity,reviewer,comment,db._now()))


def require_approval(ctx):
    info=assessment(ctx)
    if not info['approved']:
        raise ValueError('请先查阅事件前后10秒影像并人工确认响应等级，再生成方案')
    ctx['incident']['severity']=info['approved_severity']
    ctx['incident']['human_approved']=True
    return ctx
