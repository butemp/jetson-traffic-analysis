"""全局配置：均可通过环境变量覆盖。"""
import os
from pathlib import Path

OPENCV_FFMPEG_CAPTURE_OPTIONS = os.getenv(
    "OPENCV_FFMPEG_CAPTURE_OPTIONS",
    "rtsp_transport;tcp|stimeout;5000000|max_delay;1000000|analyzeduration;2000000|probesize;2000000",
)
os.environ.setdefault("OPENCV_FFMPEG_CAPTURE_OPTIONS", OPENCV_FFMPEG_CAPTURE_OPTIONS)
os.environ.setdefault("OPENCV_LOG_LEVEL", os.getenv("OPENCV_LOG_LEVEL", "ERROR"))

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.getenv("TRAFFIC_DATA_DIR", str(BASE_DIR))).resolve()
STATIC_DIR = BASE_DIR / "static"
UPLOAD_DIR = DATA_DIR / "uploads"
SNAPSHOT_DIR = DATA_DIR / "snapshots"
DB_PATH = Path(os.getenv("TRAFFIC_DB_PATH", str(DATA_DIR / "data.db"))).resolve()
SAMPLES_DIR = DATA_DIR / "samples"
SAMPLES_IMG_DIR = SAMPLES_DIR / "images"
EXPORTS_DIR = SAMPLES_DIR / "exports"
GALLERY_DIR = DATA_DIR / "gallery"
BENCHMARK_DIR = DATA_DIR / "benchmark"

VLM_ENABLED = os.getenv("VLM_ENABLED", "1").lower() in ("1", "true", "yes")
VLM_BACKEND = os.getenv("VLM_BACKEND", "vllm_http").strip()
VLM_BASE_URL = os.getenv("VLM_BASE_URL", "http://127.0.0.1:8000/v1").strip()
VLM_MODEL = os.getenv("VLM_MODEL", "qwen3.5-4b").strip()
VLM_API_KEY = os.getenv("VLM_API_KEY", "")
VLM_MAX_TOKENS = int(os.getenv("VLM_MAX_TOKENS", "192"))
VLM_TIMEOUT = float(os.getenv("VLM_TIMEOUT", "60"))
VLM_QUEUE_TIMEOUT = float(os.getenv("VLM_QUEUE_TIMEOUT", "5"))
VLM_MAX_IMAGES = int(os.getenv("VLM_MAX_IMAGES", "6"))
VLM_MAX_INFLIGHT = int(os.getenv("VLM_MAX_INFLIGHT", "1"))
VLM_BATCH_INFLIGHT = int(os.getenv("VLM_BATCH_INFLIGHT", "2"))
MAX_STREAMS = int(os.getenv("MAX_STREAMS", "3"))
STREAM_ASYNC_ACTION = os.getenv("STREAM_ASYNC_ACTION", "1").lower() in ("1", "true", "yes")
STREAM_PRELOAD = os.getenv("STREAM_PRELOAD", "0").lower() in ("1", "true", "yes")

# ---- 视频抽帧 / 分析 ----
SAMPLE_INTERVAL_SEC = float(os.getenv("SAMPLE_INTERVAL_SEC", "2"))   # 抽帧间隔（秒）
ANALYSIS_MAX_EDGE = int(os.getenv("ANALYSIS_MAX_EDGE", "768"))       # 离线视频送检图最大边
MAX_FRAMES_PER_TASK = int(os.getenv("MAX_FRAMES_PER_TASK", "600"))   # 超长视频截断
STREAM_ANALYSIS_MAX_FRAMES = int(os.getenv("STREAM_ANALYSIS_MAX_FRAMES", "0"))  # 0 = 在线流持续分析直到手动取消
STREAM_ANALYSIS_MAX_EDGE = int(os.getenv("STREAM_ANALYSIS_MAX_EDGE", "768"))
STREAM_ANALYSIS_DRAIN_FRAMES = int(os.getenv("STREAM_ANALYSIS_DRAIN_FRAMES", "0"))
STREAM_RECONNECT_DELAY_SEC = float(os.getenv("STREAM_RECONNECT_DELAY_SEC", "2"))
STREAM_MAX_READ_FAILURES = int(os.getenv("STREAM_MAX_READ_FAILURES", "30"))
STREAM_READER_IDLE_TTL_SEC = float(os.getenv("STREAM_READER_IDLE_TTL_SEC", "20"))
STREAM_STALE_FRAME_SEC = float(os.getenv("STREAM_STALE_FRAME_SEC", "3"))
VIDEO_OPEN_TIMEOUT_MSEC = int(os.getenv("VIDEO_OPEN_TIMEOUT_MSEC", "5000"))
VIDEO_READ_TIMEOUT_MSEC = int(os.getenv("VIDEO_READ_TIMEOUT_MSEC", "5000"))
USE_GSTREAMER = os.getenv("USE_GSTREAMER", "0").lower() in ("1", "true", "yes")
STREAM_SHARED_READER_ENABLED = os.getenv("STREAM_SHARED_READER_ENABLED", "1").lower() in ("1", "true", "yes")
STREAM_READER_FPS = float(os.getenv("STREAM_READER_FPS", "8"))
STREAM_READER_DRAIN_FRAMES = int(os.getenv("STREAM_READER_DRAIN_FRAMES", "0"))
STREAM_JPEG_QUALITY = int(os.getenv("STREAM_JPEG_QUALITY", "70"))
STREAM_PREVIEW_MAX_EDGE = int(os.getenv("STREAM_PREVIEW_MAX_EDGE", "512"))
STREAM_PREVIEW_FPS = float(os.getenv("STREAM_PREVIEW_FPS", "8"))
STREAM_MAX_VIEWERS = int(os.getenv("STREAM_MAX_VIEWERS", "3"))
STREAM_ADAPTIVE_INTERVAL_ENABLED = os.getenv("STREAM_ADAPTIVE_INTERVAL_ENABLED", "1").lower() in ("1", "true", "yes")
STREAM_INFERENCE_BUDGET_SEC = float(os.getenv("STREAM_INFERENCE_BUDGET_SEC", "1.2"))
STREAM_ADAPTIVE_INTERVAL_STEP_SEC = float(os.getenv("STREAM_ADAPTIVE_INTERVAL_STEP_SEC", "0.5"))
STREAM_MAX_SAMPLE_INTERVAL_SEC = float(os.getenv("STREAM_MAX_SAMPLE_INTERVAL_SEC", "6"))
CLASSIFY_TEMPERATURE = float(os.getenv("CLASSIFY_TEMPERATURE", "0.1"))
CLASSIFY_MAX_RETRIES = int(os.getenv("CLASSIFY_MAX_RETRIES", "2"))   # JSON 解析失败重试次数

# ---- 截图 ----
SNAPSHOT_QUALITY = int(os.getenv("SNAPSHOT_QUALITY", "90"))
SNAPSHOT_MAX_EDGE = int(os.getenv("SNAPSHOT_MAX_EDGE", "1920"))      # 截图存档最大边（高清存证）

# ---- 上传 / 并发 ----
MAX_UPLOAD_SIZE = int(os.getenv("MAX_UPLOAD_SIZE", str(500 * 1024 * 1024)))  # 500MB
MAX_CONCURRENT_ANALYSIS = int(os.getenv("MAX_CONCURRENT_ANALYSIS", "1"))
MAX_PENDING_ANALYSIS = int(os.getenv("MAX_PENDING_ANALYSIS", "4"))
ALLOWED_VIDEO_EXTS = {".mp4", ".mov", ".avi", ".mkv", ".webm", ".wmv", ".flv", ".m4v", ".ts"}

# ---- Web ----
WEB_PORT = int(os.getenv("WEB_PORT", "8002"))

# ---- 地图（高德 JS API）----
MAP_PROVIDER = os.getenv("MAP_PROVIDER", "offline")
AMAP_JS_KEY = os.getenv("AMAP_JS_KEY", "").strip()
AMAP_SECURITY_CODE = os.getenv("AMAP_SECURITY_CODE", "").strip()

# 任务状态枚举
STATUS_PENDING = "pending"
STATUS_PROCESSING = "processing"
STATUS_COMPLETED = "completed"
STATUS_FAILED = "failed"
STATUS_CANCELLED = "cancelled"

# 进度轮询建议间隔（写给前端用）
POLL_INTERVAL_SEC = float(os.getenv("POLL_INTERVAL_SEC", "2.5"))

# ---- 认证（单管理员）----
ADMIN_USER = os.getenv("TRAFFIC_ADMIN_USER", "admin")
ADMIN_PASS = os.getenv("TRAFFIC_ADMIN_PASS", "")
SESSION_TTL_SEC = int(os.getenv("SESSION_TTL_SEC", str(7 * 24 * 3600)))
# 免登录模式：任何能访问 Web 端口的人都以管理员身份操作，仅限可信网络。
AUTH_DISABLED = os.getenv("AUTH_DISABLED", "0").lower() in ("1", "true", "yes")

# ---- 通知 ----
NOTIFY_WEBHOOK_URL = os.getenv("NOTIFY_WEBHOOK_URL", "").strip()
# 触发 webhook 的级别（L3 紧急才外发；L2/L1 只进站内中心）
NOTIFY_OUTBOUND_LEVELS = {x.strip() for x in os.getenv("NOTIFY_OUTBOUND_LEVELS", "L3").split(",") if x.strip()}
# 自定义 webhook 请求头（JSON），如鉴权 token
_hdr = os.getenv("NOTIFY_WEBHOOK_HEADERS", "").strip()
try:
    import json as _json
    NOTIFY_WEBHOOK_HEADERS = _json.loads(_hdr) if _hdr else {}
except Exception:
    NOTIFY_WEBHOOK_HEADERS = {}

# ---- 严重度分级（类型集合可在环境变量里改）----
SEVERITY_HIGH = {x.strip() for x in os.getenv("SEVERITY_HIGH_TYPES", "交通事故,烟火,明火,逆行,刀具,打架斗殴").split(",") if x.strip()}
SAFETY_OFFLINE_FPS = float(os.getenv("SAFETY_OFFLINE_FPS", "15"))
KNIFE_PERSON_ZOOM = os.getenv("KNIFE_PERSON_ZOOM", "1").lower() in ("1", "true", "yes")
KNIFE_ZOOM_MAX_PEOPLE = int(os.getenv("KNIFE_ZOOM_MAX_PEOPLE", "4"))
KNIFE_ZOOM_MAX_SCALE = float(os.getenv("KNIFE_ZOOM_MAX_SCALE", "4"))
KNIFE_VERIFY_ENABLED = os.getenv("KNIFE_VERIFY_ENABLED", "1").lower() in ("1", "true", "yes")
KNIFE_VERIFY_THRESHOLD = float(os.getenv("KNIFE_VERIFY_THRESHOLD", "0.30"))
KNIFE_VERIFY_TINY_MAX_PX = float(os.getenv("KNIFE_VERIFY_TINY_MAX_PX", "80"))
KNIFE_VERIFY_TINY_THRESHOLD = float(os.getenv("KNIFE_VERIFY_TINY_THRESHOLD", "0.10"))
KNIFE_VERIFY_SINGLE_SCORE = float(os.getenv("KNIFE_VERIFY_SINGLE_SCORE", "0.55"))
KNIFE_VERIFY_FALLBACK_SCORE = float(os.getenv("KNIFE_VERIFY_FALLBACK_SCORE", "0.85"))
KNIFE_VERIFY_HOLD_SEC = float(os.getenv("KNIFE_VERIFY_HOLD_SEC", "2.0"))
KNIFE_VERIFY_MAX_PENDING = int(os.getenv("KNIFE_VERIFY_MAX_PENDING", "2"))
SEVERITY_MED = {x.strip() for x in os.getenv("SEVERITY_MED_TYPES", "拥堵").split(",") if x.strip()}

# ---- 存储 / 保留 ----
RETENTION_DAYS = int(os.getenv("RETENTION_DAYS", "30"))          # 0 = 永不自动清理
MIN_FREE_GB = float(os.getenv("MIN_FREE_GB", "5"))
RETENTION_CRON = os.getenv("RETENTION_CRON", "17 3 * * *")        # 5 字段 cron

# ---- Phase 3：告警 / 任务 ----
ALERT_MIN_LEVEL = os.getenv("ALERT_MIN_LEVEL", "L2")             # severity ≥ 该级自动建告警
_LEVELS = {"L1": 1, "L2": 2, "L3": 3}
ALERT_MIN_LEVEL_N = _LEVELS.get(ALERT_MIN_LEVEL, 2)
GALLERY_MAX_EDGE = int(os.getenv("GALLERY_MAX_EDGE", "640"))      # 底库参考图送检最大边

# ---- Phase 4：YOLO / 投票 / ROI / 过滤 / 应急 / 测试 ----
YOLO_API_URL = os.getenv("YOLO_API_URL", "http://127.0.0.1:8200/detect").strip()
YOLO_TIMEOUT = float(os.getenv("YOLO_TIMEOUT", "1.5"))
YOLO_CONF_THRESH = float(os.getenv("YOLO_CONF_THRESH", "0.35"))
VOTING_MODE = os.getenv("VOTING_MODE", "yolo_gate")               # yolo_gate / both_vote / vlm_only
VOTING_VLM_WEIGHT = float(os.getenv("VOTING_VLM_WEIGHT", "0.6"))
YOLO_GATE_FALLBACK_EVERY = int(os.getenv("YOLO_GATE_FALLBACK_EVERY", "10"))
YOLO_DISABLE_AFTER_FAILURES = int(os.getenv("YOLO_DISABLE_AFTER_FAILURES", "3"))
YOLO_DISABLE_BACKOFF_SEC = float(os.getenv("YOLO_DISABLE_BACKOFF_SEC", "60"))
YOLO_RISK_TYPES = {x.strip() for x in os.getenv(
    "YOLO_RISK_TYPES",
    "非机动车,烟火,明火,交通事故,拥堵,逆行,障碍物",
).split(",") if x.strip()}
TASK_METRICS_UPDATE_EVERY_FRAMES = int(os.getenv("TASK_METRICS_UPDATE_EVERY_FRAMES", "5"))

EMERGENCY_API_URL = os.getenv("EMERGENCY_API_URL", "").strip()
EMERGENCY_API_KEY = os.getenv("EMERGENCY_API_KEY", "").strip()
EMERGENCY_UI_URL = os.getenv("EMERGENCY_UI_URL", "").strip()
EMERGENCY_PLAN_MAX_TOKENS = int(os.getenv("EMERGENCY_PLAN_MAX_TOKENS", "1800"))
EMERGENCY_PLAN_TEMPERATURE = float(os.getenv("EMERGENCY_PLAN_TEMPERATURE", "0.2"))

STRESS_MAX_CONCURRENCY = int(os.getenv("STRESS_MAX_CONCURRENCY", "16"))
STRESS_FRAMES_PER_STREAM = int(os.getenv("STRESS_FRAMES_PER_STREAM", "30"))

for _d in (UPLOAD_DIR, SNAPSHOT_DIR, STATIC_DIR, SAMPLES_IMG_DIR, EXPORTS_DIR, GALLERY_DIR, BENCHMARK_DIR / "images"):
    _d.mkdir(parents=True, exist_ok=True)
