"""准确率评测：读取 benchmark/dataset.json 并调用 VLM 分类。"""
import json
import time
from collections import defaultdict
from pathlib import Path

import cv2

import config
import vlm

BENCH_DIR = config.BASE_DIR / "benchmark"
IMG_DIR = BENCH_DIR / "images"
DATASET = BENCH_DIR / "dataset.json"


def info() -> dict:
    if not DATASET.exists():
        return {"exists": False, "samples": 0, "path": str(DATASET), "message": "benchmark/dataset.json 不存在"}
    data = json.loads(DATASET.read_text(encoding="utf-8"))
    samples = data.get("samples") or []
    return {"exists": True, "name": data.get("name", "benchmark"), "samples": len(samples), "path": str(DATASET)}


def _metrics(rows):
    labels = sorted({r["label"] for r in rows} | {r["pred"] for r in rows})
    cm = {a: {b: 0 for b in labels} for a in labels}
    for r in rows:
        cm[r["label"]][r["pred"]] += 1
    per = []
    f1s = []
    for lab in labels:
        tp = cm[lab][lab]
        fp = sum(cm[x][lab] for x in labels if x != lab)
        fn = sum(cm[lab][x] for x in labels if x != lab)
        prec = tp / (tp + fp) if tp + fp else 0
        rec = tp / (tp + fn) if tp + fn else 0
        f1 = 2 * prec * rec / (prec + rec) if prec + rec else 0
        f1s.append(f1)
        per.append({"label": lab, "precision": round(prec, 3), "recall": round(rec, 3),
                    "f1": round(f1, 3), "tp": tp, "fp": fp, "fn": fn})
    acc = sum(1 for r in rows if r["label"] == r["pred"]) / len(rows) if rows else 0
    return {"accuracy": round(acc, 3), "macro_f1": round(sum(f1s) / len(f1s), 3) if f1s else 0,
            "per_class": per, "confusion": cm}


def run(limit: int = 200) -> dict:
    meta = info()
    if not meta.get("exists"):
        return {"ok": False, **meta}
    data = json.loads(DATASET.read_text(encoding="utf-8"))
    rows = []
    missing = 0
    t0 = time.time()
    client = vlm.get_engine()
    for s in (data.get("samples") or [])[:limit]:
        p = BENCH_DIR / s.get("image", "")
        frame = cv2.imread(str(p))
        if frame is None:
            missing += 1
            continue
        r = vlm.classify_frame(frame, client)
        rows.append({"image": s.get("image"), "label": s.get("label", "Normal"),
                     "pred": r.get("event_type", "Normal"), "description": r.get("description", "")})
    m = _metrics(rows)
    return {"ok": True, "elapsed_sec": round(time.time() - t0, 2), "valid": len(rows),
            "missing": missing, "metrics": m, "rows": rows[:100]}
