"""通知分发：站内（写 notifications 表，前端轮询）+ Webhook（httpx，线程池+重试）。"""
import logging
import threading
from concurrent.futures import ThreadPoolExecutor
from typing import Optional

import config
import db
from escalation import channels_for

log = logging.getLogger("traffic.notifier")
_executor: Optional[ThreadPoolExecutor] = None
_lock = threading.Lock()


def start() -> None:
    global _executor
    with _lock:
        if _executor is None:
            _executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="notify")


def shutdown() -> None:
    global _executor
    if _executor is not None:
        _executor.shutdown(wait=False)
        _executor = None


def _build_payload(event: dict, title: str, message: str) -> dict:
    return {
        "title": title,
        "message": message,
        "level": event.get("severity"),
        "event": {
            "id": event.get("id"),
            "type": event.get("event_type"),
            "severity": event.get("severity"),
            "description": event.get("description"),
            "timestamp_sec": event.get("timestamp_sec"),
            "task_id": event.get("task_id") or event.get("task_id"),
            "snapshot": event.get("snapshot_path"),
        },
    }


def notify_event(event: dict, level: str, title: str, message: str) -> None:
    """按级别路由：L2+ 进站内；L3 且配了 webhook 再外发。"""
    if _executor is None:
        start()
    chans = channels_for(level)
    if not chans:
        return
    payload = _build_payload(event, title, message)
    for ch in chans:
        if ch == "in_app":
            db.insert_notification(event.get("id"), level, title, message, "in_app", "sent", payload)
            log.info("站内通知 [%s] %s", level, title)
        elif ch == "webhook":
            nid = db.insert_notification(event.get("id"), level, title, message, "webhook", "pending", payload)
            _executor.submit(_send_webhook, nid, payload)


def _send_webhook(notif_id: int, payload: dict) -> None:
    import httpx
    url = config.NOTIFY_WEBHOOK_URL
    last_err = None
    for attempt in range(3):
        try:
            r = httpx.post(url, json=payload, headers=config.NOTIFY_WEBHOOK_HEADERS, timeout=10)
            if 200 <= r.status_code < 300:
                db.update_notification_status(notif_id, "sent")
                log.info("webhook 发送成功 notif=%s", notif_id)
                return
            last_err = f"HTTP {r.status_code}: {r.text[:120]}"
        except Exception as e:
            last_err = str(e)
        log.warning("webhook 发送失败(第%d次) notif=%s: %s", attempt + 1, notif_id, last_err)
    db.update_notification_status(notif_id, "failed", last_err)
