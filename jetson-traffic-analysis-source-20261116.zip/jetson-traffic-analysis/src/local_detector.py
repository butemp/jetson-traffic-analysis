"""无外部模型时的保守兜底。

默认不再做相似度/帧差检测，避免摄像头链路额外耗时。
"""


def classify_without_model(det: dict = None, target_objects=None) -> dict:
    return {
        "has_event": False,
        "event_type": "Normal",
        "description": "未启用本地帧差初筛，未发现可自动确认的风险事件",
        "confidence": "低",
        "raw": "",
    }


def classify_by_motion(_unused=None, det: dict = None, target_objects=None) -> dict:
    return classify_without_model(det, target_objects)
