"""数据源管理：file / rtsp / rtmp 注册 + 连通测试（实时多路抽帧本轮不做，仅单帧测试）。"""
import logging

import db
import video

log = logging.getLogger("traffic.sources")


def test_source(sid: str) -> dict:
    """抓 1 帧验证连通，更新 online 状态。"""
    src = db.get_source(sid)
    if not src:
        return {"online": False, "error": "源不存在"}
    ok, err = False, None
    cap = video.open_capture(src["uri"])
    try:
        if not cap.isOpened():
            err = "无法打开（检查 URI/编码/网络）"
        else:
            for _ in range(3):  # RTSP 缓冲：最多读 3 次拿有效帧
                ret, _ = cap.read()
                if ret:
                    ok = True
                    break
            if not ok:
                err = "打开但读不到帧"
    except Exception as e:
        err = str(e)
    finally:
        cap.release()
    db.update_source_status(sid, ok, db._now() if ok else None)
    log.info("源 %s 测试: online=%s (%s)", sid, ok, err or "ok")
    return {"online": ok, "error": err}
