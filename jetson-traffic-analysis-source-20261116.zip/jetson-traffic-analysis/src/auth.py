"""用户认证：SQLite 用户表 + 三角色 session。"""
import hmac
import hashlib
import logging
import secrets
import time
from typing import Optional

from fastapi import HTTPException, Request

import config
import db

log = logging.getLogger("traffic.auth")
_sessions: dict = {}  # token -> {"user": str, "role": str, "ts": float}
COOKIE_NAME = "tvlm_session"
ROLES = {"admin", "operator", "viewer"}


def hash_password(plain: str, salt: str = None) -> tuple[str, str]:
    salt = salt or secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", plain.encode("utf-8"), salt.encode("utf-8"), 200000)
    return dk.hex(), salt


def verify_password(plain: str, pass_hash: str, salt: str) -> bool:
    h, _ = hash_password(plain, salt)
    return hmac.compare_digest(h, pass_hash or "")


def seed_default_admin() -> None:
    """首次启动播种默认管理员。"""
    if db.user_count() > 0:
        return
    if len(config.ADMIN_PASS) < 12 or config.ADMIN_PASS == "changeme":
        raise RuntimeError("首次启动请设置至少12位的 TRAFFIC_ADMIN_PASS；已有用户不会被重置")
    h, salt = hash_password(config.ADMIN_PASS)
    db.insert_user(config.ADMIN_USER, h, salt, "admin", 1)
    log.info("已创建管理员 %s", config.ADMIN_USER)


def login(user: str, plain: str) -> Optional[str]:
    u = db.get_user_by_name(user)
    if not u or not u.get("enabled") or not verify_password(plain, u.get("pass_hash"), u.get("salt")):
        return None
    token = secrets.token_urlsafe(32)
    _sessions[token] = {"user": u["username"], "role": u["role"], "ts": time.time()}
    return token


def logout(token: Optional[str]) -> None:
    if token:
        _sessions.pop(token, None)


def get_actor(request: Request) -> Optional[str]:
    s = get_session(request)
    return s["user"] if s else None


def get_session(request: Request) -> Optional[dict]:
    token = request.cookies.get(COOKIE_NAME)
    s = _sessions.get(token) if token else None
    if s and time.time() - s["ts"] > config.SESSION_TTL_SEC:
        _sessions.pop(token, None)
        s = None
    if s is None and config.AUTH_DISABLED:
        return {"user": config.ADMIN_USER, "role": "admin", "ts": time.time()}
    return s


def get_role(request: Request) -> Optional[str]:
    s = get_session(request)
    return s.get("role") if s else None


def drop_user_sessions(username: str) -> None:
    for token, s in list(_sessions.items()):
        if s.get("user") == username:
            _sessions.pop(token, None)


def can_write(role: Optional[str]) -> bool:
    return role in ("admin", "operator")


def can_admin(role: Optional[str]) -> bool:
    return role == "admin"


def client_ip(request: Request) -> str:
    if request and request.client:
        return request.client.host
    return "unknown"


async def require_auth(request: Request) -> str:
    """FastAPI 依赖：返回 actor，未登录 401。"""
    actor = get_actor(request)
    if not actor:
        raise HTTPException(401, "未登录或会话过期")
    return actor
