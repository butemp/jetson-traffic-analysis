"""YOLO + VLM 结果融合。"""
import config

_CONF_N = {"低": 1, "中": 2, "高": 3}


def _raise_conf(conf: str) -> str:
    n = min(3, _CONF_N.get(conf, 2) + 1)
    return {1: "低", 2: "中", 3: "高"}[n]


def should_call_vlm(frame_index: int, yolo_dets: list, yolo_events: list = None, yolo_active: bool = True) -> bool:
    mode = config.VOTING_MODE
    if mode == "vlm_only":
        return True
    if mode == "both_vote":
        return True
    if yolo_events:
        return True
    # yolo_gate 但小模型未配置/熔断中/本轮调用失败：没有初筛结果可依赖，
    # 退化为每帧直调 VLM，避免漏检（之前落到 %N 抽检导致大量帧跳过复判）。
    if not yolo_active:
        return True
    every = max(1, config.YOLO_GATE_FALLBACK_EVERY)
    return frame_index % every == 0


def fuse(vlm_result: dict, yolo_events: list) -> dict:
    result = dict(vlm_result or {
        "has_event": False, "event_type": "Normal", "description": "未调用 VLM", "confidence": "低", "raw": "",
        "_vlm_called": False, "_vlm_skip_reason": "未调用VLM",
    })
    if not yolo_events:
        return result
    primary = yolo_events[0]
    if result.get("has_event"):
        if result.get("event_type") == primary or result.get("event_type") in ("车辆", "Normal", ""):
            result["event_type"] = primary if result.get("event_type") == "车辆" else result.get("event_type", primary)
        result["confidence"] = _raise_conf(result.get("confidence", "中"))
        result["description"] = (result.get("description") or "") + f"；YOLO辅助检出{primary}"
        return result
    if config.VOTING_MODE in ("both_vote", "yolo_gate"):
        if not result.get("_vlm_called"):
            reason = result.get("_vlm_skip_reason") or "未调用VLM"
            desc = f"小模型检测到{primary}，{reason}，建议人工复核"
        elif result.get("_vlm_error"):
            desc = f"小模型检测到{primary}，VLM复判未返回有效结论，建议人工复核"
        else:
            desc = f"小模型检测到{primary}，VLM复判未确认，建议人工复核"
        return {
            "has_event": True,
            "event_type": primary,
            "description": desc,
            "confidence": "低",
            "raw": result.get("raw", ""),
        }
    return result
