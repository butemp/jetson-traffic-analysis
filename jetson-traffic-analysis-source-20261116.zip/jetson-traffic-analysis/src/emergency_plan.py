"""应急指挥方案生成。

这里不引入独立 agent 服务，直接复用当前视频理解同源的小模型做文本推理。
模型不可用时返回模板化方案，保证告警处置链路仍可演示和使用。
"""
import logging
from datetime import datetime
from typing import Optional

import config
import db
import vlm
import report_fixes

log = logging.getLogger("traffic.emergency_plan")


PLAN_SECTIONS = [
    "1. 事件概述",
    "2. 响应定级",
    "3. 指挥架构",
    "4. 预警发布",
    "5. 处置行动方案",
    "6. 资源调度方案",
    "7. 信息报送与新闻发布",
    "8. 风险提示与注意事项",
    "9. 依据引用",
]


REFERENCE_LIBRARY = {
    "交通事故": {
        "scene": "道路交通事故应急处置",
        "basis": "快速警戒、先期救援、交通分流、伤员转运、现场勘查、道路恢复。",
        "actions": ["封控事故点上下游车道", "同步通知交警、120、消防和养护单位", "设置绕行路径并持续发布诱导信息"],
    },
    "烟火": {
        "scene": "火情及次生事故应急处置",
        "basis": "优先确认火源、隔离危险区域、组织消防力量、疏散滞留车辆和人员。",
        "actions": ["建立不少于 200 米安全警戒区", "调派消防救援和危化排查力量", "关闭邻近入口并组织反向疏散"],
    },
    "逆行": {
        "scene": "严重交通违法风险处置",
        "basis": "快速发现、就近拦截、远端诱导、避免正面冲突。",
        "actions": ["锁定逆行目标轨迹", "联动交警在下游节点拦截", "通过情报板和广播提醒正常车辆避让"],
    },
    "拥堵": {
        "scene": "交通拥堵疏导",
        "basis": "分级疏导、削峰控流、节点管控、动态诱导。",
        "actions": ["开启路网诱导和可变情报板", "排查拥堵源头并派出巡逻力量", "视情况在上游收费站限流"],
    },
    "停车": {
        "scene": "异常停车处置",
        "basis": "确认占道位置、预警后方车辆、救援拖移、恢复通行。",
        "actions": ["提醒后方车辆减速变道", "派巡逻车和清障车到场", "确认人员安全后拖移故障车辆"],
    },
    "抛洒物": {
        "scene": "路面障碍物清理",
        "basis": "远端预警、现场防护、快速清障、复核恢复。",
        "actions": ["布设上游警示和锥桶", "通知养护清障力量", "清理后复核路面并恢复车道"],
    },
}


SEVERITY_GUIDE = {
    "L3": "重大风险：立即启动现场联动处置，形成指挥专班并持续滚动研判。",
    "L2": "较高风险：启动部门协同处置，重点控制扩散和二次事故。",
    "L1": "一般风险：值守跟踪、预警提示、必要时派员核查。",
}


def _latest_active_alert() -> Optional[dict]:
    rows = db.list_alerts(status="active", limit=1)
    return rows[0] if rows else None


def _pick_reference(event_type: str, title: str = "", message: str = "") -> dict:
    text = f"{event_type} {title} {message}"
    for key, ref in REFERENCE_LIBRARY.items():
        if key in text:
            return {"event_key": key, **ref}
    return {
        "event_key": event_type or "综合交通事件",
        "scene": "综合交通突发事件处置",
        "basis": "先期核实、风险控制、交通组织、资源调度、信息报送、恢复评估。",
        "actions": ["核实事件位置和影响范围", "组织警戒与交通诱导", "滚动评估并按需升级响应"],
    }


def build_context(alert_id=None, event_id=None, extra: str = "") -> dict:
    alert = None
    event = None
    source = None

    if alert_id:
        alert = db.get_alert(int(alert_id))
        if not alert:
            raise ValueError("告警不存在")
        event_id = alert.get("event_id") or event_id
    elif not event_id:
        alert = _latest_active_alert()
        if alert:
            event_id = alert.get("event_id")

    if event_id:
        event = db.get_event(int(event_id))
        if not event:
            raise ValueError("事件不存在")

    source_id = (alert or {}).get("source_id") or (event or {}).get("source_id")
    if source_id:
        source = db.get_source(source_id)

    event_type = (event or {}).get("event_type") or (alert or {}).get("title") or "交通异常"
    severity = (alert or {}).get("severity") or (event or {}).get("severity") or "L2"
    message = (alert or {}).get("message") or (event or {}).get("description") or extra or "监测到交通异常，需要研判处置。"
    reference = _pick_reference(event_type, (alert or {}).get("title", ""), f"{message} {extra}")

    return {
        "alert": alert,
        "event": event,
        "source": source,
        "reference": reference,
        "incident": {
            "alert_id": (alert or {}).get("id"),
            "event_id": (event or {}).get("id"),
            "event_type": event_type,
            "severity": severity,
            "severity_guide": SEVERITY_GUIDE.get(severity, SEVERITY_GUIDE["L2"]),
            "title": (alert or {}).get("title") or f"{event_type}告警",
            "message": message,
            "confidence": (event or {}).get("confidence"),
            "timestamp_sec": (event or {}).get("timestamp_sec"),
            "snapshot_path": (alert or {}).get("snapshot_path") or (event or {}).get("snapshot_path"),
            "source_id": source_id,
            "source_name": (source or {}).get("name") or source_id or "未绑定数据源",
            "source_kind": (source or {}).get("kind"),
            "address": (source or {}).get("address"),
            "lat": (source or {}).get("lat"),
            "lng": (source or {}).get("lng"),
            "created_at": (alert or event or {}).get("created_at"),
            "extra": extra.strip(),
        },
    }


def _format_context(ctx: dict) -> str:
    inc = ctx["incident"]
    ref = ctx["reference"]
    fields = [
        ("告警ID", inc.get("alert_id")),
        ("事件ID", inc.get("event_id")),
        ("事件类型", inc.get("event_type")),
        ("风险级别", inc.get("severity")),
        ("告警标题", inc.get("title")),
        ("告警描述", inc.get("message")),
        ("置信度", inc.get("confidence")),
        ("数据源", inc.get("source_name")),
        ("位置", inc.get("address") or (f"{inc.get('lng')},{inc.get('lat')}" if inc.get("lng") and inc.get("lat") else None)),
        ("发生时间", inc.get("created_at")),
        ("现场补充", inc.get("extra")),
        ("匹配场景", ref.get("scene")),
        ("参考要点", ref.get("basis")),
        ("建议动作", "；".join(ref.get("actions", []))),
    ]
    return "\n".join(f"- {k}: {v}" for k, v in fields if v not in (None, ""))


def _fallback_plan(ctx: dict, reason: str = "") -> str:
    inc = ctx["incident"]
    ref = ctx["reference"]
    actions = ref.get("actions") or []
    location = inc.get("address") or inc.get("source_name") or "事件现场"
    now = datetime.now().isoformat(timespec="minutes")
    return f"""# 应急指挥方案

## 1. 事件概述
{now}，系统在 {location} 识别到“{inc.get('event_type')}”相关告警。告警内容：{inc.get('message')}。当前级别建议为 {inc.get('severity')}，数据源为 {inc.get('source_name')}。

## 2. 响应定级
按“{ref.get('scene')}”处置，建议执行 {inc.get('severity')} 响应。定级依据：{inc.get('severity_guide')}

## 3. 指挥架构
由值班负责人牵头建立临时指挥组，交警负责交通组织，养护/清障负责现场恢复，医疗和消防按事件性质待命或出动，监控席持续回传画面和处置进展。

## 4. 预警发布
立即向上游车辆发布减速、避让和绕行提示；同步更新可变情报板、导航诱导和内部值班群。若影响扩大，升级为区域路网预警。

## 5. 处置行动方案
1. {actions[0] if len(actions) > 0 else '核实事件位置、车道占用和人员伤亡情况。'}
2. {actions[1] if len(actions) > 1 else '安排最近巡逻或处置力量赶赴现场。'}
3. {actions[2] if len(actions) > 2 else '根据拥堵长度和事故影响实施分流、限流或临时封控。'}
4. 处置期间每 5 分钟复核一次视频画面、告警状态和交通流变化。

## 6. 资源调度方案
调度交警巡逻单元 1 组、清障/养护单元 1 组；{('消防救援 1 组、医疗救护 1 组' if inc.get('event_type') in ('交通事故', '烟火') else '应急备勤力量按需增援')}。优先保障上游警戒、现场处置和下游恢复通行。

## 7. 信息报送与新闻发布
10 分钟内形成首报，包含时间、地点、事件类型、影响范围、已采取措施和资源到位情况。对外发布只采用审核后的简短交通提示，避免扩散未经核实信息。

## 8. 风险提示与注意事项
重点防范二次事故、拥堵回溢、人员滞留和恶劣天气叠加风险。现场人员进入车道前必须完成上游警戒，夜间或低能见度情况下增加警示距离。

## 9. 依据引用
参考场景：{ref.get('scene')}。参考原则：{ref.get('basis')}。本方案由系统依据告警上下文自动生成，需由值班人员结合现场情况确认后执行。{('模型调用异常，已使用兜底模板：' + reason) if reason else ''}
"""


def _call_model(ctx: dict, on_delta=None, owner=None) -> str:
    if not config.VLM_ENABLED:
        raise RuntimeError("VLM_ENABLED 未开启，使用本地应急模板")
    engine = vlm.get_engine()
    prompt = f"""你是交通应急指挥辅助系统，请根据告警上下文生成一份可执行的应急指挥方案。

要求：
- 用中文 Markdown 输出。
- 必须包含以下 9 个二级标题，标题名称严格一致：{', '.join(PLAN_SECTIONS)}。
- 内容要面向交通管理/交警/养护/消防/医疗协同处置，给出明确动作、责任分工、时限和风险提示。
- 不要编造具体单位名称、伤亡人数、车牌号；没有信息时写“待核实”。
- 总长度控制在 1200 字以内。

告警上下文：
{_format_context(ctx)}
"""
    return engine.generate(
        messages=[
            {"role": "system", "content": "你负责把交通视频告警转化为结构化应急指挥方案。"},
            {"role": "user", "content": prompt},
        ],
        max_tokens=config.EMERGENCY_PLAN_MAX_TOKENS,
        temperature=0,
        owner=owner,
        on_delta=on_delta,
    ).strip()


def generate(alert_id=None, event_id=None, extra: str = "") -> dict:
    ctx = build_context(alert_id=alert_id, event_id=event_id, extra=extra or "")
    report_fixes.require_approval(ctx)
    ctx["incident"]["severity_guide"] = SEVERITY_GUIDE[ctx["incident"]["severity"]]
    fallback_used = False
    reason = ""
    try:
        plan = _call_model(ctx)
        if not plan:
            raise RuntimeError("模型返回为空")
    except Exception as exc:
        fallback_used = True
        reason = str(exc)
        log.warning("应急方案模型调用失败，使用兜底模板: %s", exc)
        plan = _fallback_plan(ctx, reason)
    return {
        "ok": True,
        "generated_by": "vlm_text" if not fallback_used else "fallback_template",
        "model": config.VLM_MODEL,
        "fallback_used": fallback_used,
        "fallback_reason": reason,
        "incident": ctx["incident"],
        "reference": ctx["reference"],
        "plan_markdown": plan,
    }


def prepare(alert_id=None, event_id=None, extra: str = ""):
    import time
    ctx = build_context(alert_id=alert_id, event_id=event_id, extra=extra or "")
    report_fixes.require_approval(ctx)
    ctx["incident"]["severity_guide"] = SEVERITY_GUIDE[ctx["incident"]["severity"]]
    started = time.monotonic()
    return ctx, started


def finish(ctx: dict, plan: str, started: float, fallback_reason: str = "") -> dict:
    import time
    fallback_used = bool(fallback_reason)
    if fallback_used:
        plan = _fallback_plan(ctx, fallback_reason)
    return {
        "ok": True,
        "generated_by": "vlm_text" if not fallback_used else "fallback_template",
        "model": config.VLM_MODEL,
        "fallback_used": fallback_used,
        "fallback_reason": fallback_reason,
        "incident": ctx["incident"],
        "reference": ctx["reference"],
        "plan_markdown": plan,
        "elapsed_sec": round(time.monotonic() - started, 1),
    }
