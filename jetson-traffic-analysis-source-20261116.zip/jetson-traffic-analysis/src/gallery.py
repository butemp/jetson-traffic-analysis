"""底库（Gallery）服务层：CRUD 薄封装 + 取任务关联条目。匹配在 vlm.match_gallery。"""
import logging
import shutil

import config
import db

log = logging.getLogger("traffic.gallery")


def items_for_task(det_task: dict) -> list:
    """返回任务关联的所有底库条目（text 描述）。"""
    groups = split_for_task(det_task)
    return groups["watch"] + groups["allow"]


def split_for_task(det_task: dict) -> dict:
    """按底库 mode 拆分关注组(watch)和白名单组(allow)。"""
    import json as _json
    raw = det_task.get("gallery_ids") if det_task else None
    if not raw or raw == "[]":
        return {"watch": [], "allow": []}
    try:
        gids = _json.loads(raw)
    except Exception:
        return {"watch": [], "allow": []}
    out = {"watch": [], "allow": []}
    for gid in gids:
        gs = [g for g in db.list_galleries() if str(g.get("id")) == str(gid)]
        mode = (gs[0].get("mode") if gs else "watch") or "watch"
        key = "allow" if mode == "allow" else "watch"
        out[key].extend(db.list_gallery_items(gid))
    return {
        "watch": [i for i in out["watch"] if i.get("kind") == "text" and i.get("content")],
        "allow": [i for i in out["allow"] if i.get("kind") == "text" and i.get("content")],
    }


def save_item_image(item_id: int, upload_file) -> str:
    """保存底库参考图，返回相对文件名。"""
    import uuid as _uuid
    ext = ".jpg"
    fname = f"{_uuid.uuid4().hex[:10]}_{item_id}{ext}" if item_id else f"{_uuid.uuid4().hex[:10]}{ext}"
    dest = config.GALLERY_DIR / fname
    with open(dest, "wb") as f:
        shutil.copyfileobj(upload_file, f)
    return fname
