"""Persistent, local-only streaming model wrappers; callers own scheduling/history.

Frames are uint8 BGR arrays, boxes are normalized xyxy. Relative model paths are
resolved against this module. Put .vendor on PYTHONPATH (as run.sh does).
Construct one instance per inference worker; neither constructor runs a warmup.
"""

import ast
import hashlib
import json
import os
from pathlib import Path
import threading
from time import perf_counter

import cv2
import numpy as np
import torch  # Import before ONNX Runtime to make PyTorch CUDA/cuDNN libraries available.

ROOT = Path(__file__).resolve().parent
KNIFE_PATH = ROOT / "models/knife-onnx/model.onnx"
PEOPLE_PATH = ROOT / "models/people-yolov8n.onnx"
FIGHT_PATH = ROOT / "models/fight-x3d/model.safetensors"
KNIFE_SHA = "d300e36bb5c1939e0ca0717e7523fcee93d8a4cb502ec407e21f596d26935068"
PEOPLE_SHA = "65158dad735be799c2466fa15e260c09558080bd530b42a8d0c3d1b419afd8b5"
FIGHT_SHA = "20bd520400449726d25da42b7b65a16c6ebcfb56433a54aaaaa404a46422be33"
KNIFE_CLASSES = {0: "Gun", 1: "explosion", 2: "grenade", 3: "knife"}
COCO_CLASSES = dict(enumerate((
    "person|bicycle|car|motorcycle|airplane|bus|train|truck|boat|traffic light|"
    "fire hydrant|stop sign|parking meter|bench|bird|cat|dog|horse|sheep|cow|"
    "elephant|bear|zebra|giraffe|backpack|umbrella|handbag|tie|suitcase|frisbee|"
    "skis|snowboard|sports ball|kite|baseball bat|baseball glove|skateboard|"
    "surfboard|tennis racket|bottle|wine glass|cup|fork|knife|spoon|bowl|banana|"
    "apple|sandwich|orange|broccoli|carrot|hot dog|pizza|donut|cake|chair|couch|"
    "potted plant|bed|dining table|toilet|tv|laptop|mouse|remote|keyboard|"
    "cell phone|microwave|oven|toaster|sink|refrigerator|book|clock|vase|scissors|"
    "teddy bear|hair drier|toothbrush"
).split("|")))


def _verified(path, allowed):
    path = Path(path).expanduser()
    path = (path if path.is_absolute() else ROOT / path).resolve(strict=True)
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    sha = digest.hexdigest()
    if sha not in allowed:
        raise ValueError(f"Unregistered model SHA256 {sha}: {path}")
    return path, sha


def _frame(frame):
    if (not isinstance(frame, np.ndarray) or frame.ndim != 3
            or frame.shape[2] != 3 or min(frame.shape[:2]) < 1
            or frame.dtype != np.uint8):
        raise ValueError("Expected a nonempty uint8 BGR ndarray [H,W,3]")


def _names(value):
    items = value.items() if isinstance(value, dict) else enumerate(value)
    return {int(index): name for index, name in items}


def _nms(detections):
    if not detections:
        return []
    boxes = np.asarray([d["box"] for d in detections], dtype=np.float64)
    areas = np.prod(boxes[:, 2:] - boxes[:, :2], axis=1)
    order = np.argsort([-d["score"] for d in detections], kind="stable")
    keep = []
    while order.size:
        current, rest = int(order[0]), order[1:]
        keep.append(detections[current])
        intersection = np.prod(np.maximum(
            np.minimum(boxes[current, 2:], boxes[rest, 2:])
            - np.maximum(boxes[current, :2], boxes[rest, :2]), 0), axis=1)
        union = areas[current] + areas[rest] - intersection
        iou = np.divide(intersection, union, out=np.zeros_like(union), where=union > 0)
        order = rest[iou <= .5]
    return keep


class YoloDetector:
    """detect(bgr) -> list of {label, box: [x1,y1,x2,y2], score, source}.

    classes is an optional id->name mapping (or full names list); subsets are
    checked, never used to restrict argmax. Defaults use the pinned model names.
    path=None selects knife, or the copied/parent asset for target_label='person'.
    backend='cuda' requires CUDA:0; explicit 'cpu' is only for the pinned models.
    The registered knife-yolov8n artifact requires CUDA and batches current-frame
    views up to max_batch (1..8); pinned static models always use one view/run.
    tile_size <= 640 is native pixels; tile_stride defaults to 75% with no view
    cap. Images fitting 640x640 use only the full view. confidence is uncalibrated.
    last_metrics records completed views, attempted batches, timing and completion.
    """

    def __init__(self, path=None, classes=None, confidence=.25, target_label="knife",
                 tiled=False, *, backend="cuda", tile_size=640, tile_stride=None,
                 max_batch=8):
        if backend not in ("cuda", "cpu"):
            raise ValueError("backend must be 'cuda' or explicit 'cpu'")
        if not np.isfinite(confidence) or not 0 <= confidence <= 1:
            raise ValueError("confidence must be finite and in [0,1]")
        if type(tile_size) is not int or not 1 <= tile_size <= 640:
            raise ValueError("tile_size must be an integer in [1,640]")
        tile_stride = max(1, tile_size * 3 // 4) if tile_stride is None else tile_stride
        if type(tile_stride) is not int or not 1 <= tile_stride <= tile_size:
            raise ValueError("tile_stride must be an integer in [1,tile_size]")
        if type(max_batch) is not int or not 1 <= max_batch <= 8:
            raise ValueError("max_batch must be an integer in [1,8]")
        if path is None:
            path = KNIFE_PATH if target_label != "person" else (
                PEOPLE_PATH if PEOPLE_PATH.is_file() else ROOT.parent / "models/yolov8n.onnx")
        path = Path(path).expanduser()
        path = (path if path.is_absolute() else ROOT / path).resolve(strict=True)
        trained_paths = ('knife-yolov8n/model.onnx','knife-yolov8n-u8/model.onnx')
        trained = path in tuple((ROOT/'models'/name).resolve() for name in trained_paths)
        if trained:
            if backend != "cuda":
                raise ValueError("The trained knife artifact requires CUDA:0; no CPU fallback")
            manifest_path = ROOT / "models/manifest.json"
            records = json.loads(manifest_path.read_text(encoding="utf-8"))["models"]
            matches = [m for m in records if isinstance(m, dict)
                       and m.get("path") == path.relative_to(ROOT/'models').as_posix()]
            if len(matches) != 1:
                raise ValueError(f"Expected one trained knife entry in {manifest_path}")
            entry = matches[0]
            digest = entry.get("sha256")
            if (entry.get("kind") != "trained_knife" or entry.get("classes") != {"0": "knife"}
                    or not isinstance(digest, str) or len(digest) != 64
                    or any(c not in "0123456789abcdefABCDEF" for c in digest)
                    or entry.get("expected_sha256") != digest):
                raise ValueError("Invalid trained knife manifest kind, classes or SHA256 pair")
            path, sha = _verified(path, (digest.lower(),))
            expected = {0: "knife"}
        else:
            path, sha = _verified(path, (KNIFE_SHA, PEOPLE_SHA))
            expected = KNIFE_CLASSES if sha == KNIFE_SHA else COCO_CLASSES
            manifest_path = path.parent / "manifest.json"
            if not manifest_path.is_file():
                manifest_path = path.parent.parent / "manifest.json"
            records = json.loads(manifest_path.read_text(encoding="utf-8"))["models"]
            entry = next((m for m in records if m.get("expected_sha256", m.get("sha256")) == sha
                          and m.get("sha256", sha) == sha), None)
            if entry is None:
                raise ValueError(f"Model hash must be registered in {manifest_path}")

        import onnxruntime as ort
        provider = "CUDAExecutionProvider" if backend == "cuda" else "CPUExecutionProvider"
        if provider not in ort.get_available_providers():
            raise RuntimeError(f"Required ONNX Runtime provider unavailable: {provider}")
        if backend == "cuda" and not torch.cuda.is_available():
            raise RuntimeError("CUDA:0 is required; no CPU fallback")
        options = ort.SessionOptions()
        options.intra_op_num_threads = 2
        if os.environ.get('TRAFFIC_ORT_PROFILE_DIR'):
            options.enable_profiling=True
            options.profile_file_prefix=str(Path(os.environ['TRAFFIC_ORT_PROFILE_DIR'])/sha[:12])
        providers = [(provider, {"device_id": 0})] if backend == "cuda" else [provider]
        self.session = ort.InferenceSession(str(path), sess_options=options,
                                           providers=providers, enable_fallback=False)
        self.session.disable_fallback()
        if self.session.get_providers()[0] != provider:
            raise RuntimeError(f"Requested provider failed to load: {provider}")
        inputs, outputs = self.session.get_inputs(), self.session.get_outputs()
        if len(inputs) != 1 or len(outputs) != 1:
            raise ValueError("Expected one RGB input and one raw YOLO output")
        self.output_shape = (None if trained else 1, 4 + len(expected), 8400)
        self.dtype = np.float32
        self.output_dtype = np.float32
        self.batch_capacity = max_batch if trained else 1
        if trained:
            def symbolic(dim):
                return isinstance(dim, str) and bool(dim)

            input_shape, output_shape = inputs[0].shape, outputs[0].shape
            if (len(input_shape) != 4 or len(output_shape) != 3
                    or not symbolic(input_shape[0]) or not symbolic(output_shape[0])
                    or input_shape[1] != 3 or (output_shape[1] != 5 and not symbolic(output_shape[1]))
                    or any(dim != 640 and not symbolic(dim) for dim in input_shape[2:])
                    or (output_shape[2] != 8400 and not symbolic(output_shape[2]))
                    or inputs[0].type not in ("tensor(float16)", "tensor(float)", "tensor(uint8)")
                    or outputs[0].type not in ("tensor(float16)", "tensor(float)")):
                raise ValueError("Expected registered dynamic-batch RGB input and raw [B,5,A] output")
            self.dtype = {'tensor(float16)':np.float16,'tensor(float)':np.float32,'tensor(uint8)':np.uint8}[inputs[0].type]
            self.output_dtype = np.float16 if outputs[0].type == 'tensor(float16)' else np.float32
        elif (inputs[0].shape != [1, 3, 640, 640]
              or tuple(outputs[0].shape) != self.output_shape
              or inputs[0].type != "tensor(float)" or outputs[0].type != "tensor(float)"):
            raise ValueError("Expected fixed FP32 NCHW RGB input and raw cxcywh+scores output")
        metadata = self.session.get_modelmeta().custom_metadata_map
        if self.dtype == np.uint8 and metadata.get('input_format') != 'RGB_NCHW_UINT8':
            raise ValueError('UINT8 input requires an explicit GPU preprocessing contract')
        if "names" in metadata:
            names = _names(ast.literal_eval(metadata["names"]))
        elif sha == PEOPLE_SHA:
            # This exact Kalray export lacks labels; the pinned COCO manifest supplies them.
            names = _names(entry.get("class_names", entry.get("classes", COCO_CLASSES)))
        else:
            raise ValueError("Knife ONNX must contain class names metadata")
        if names != expected:
            raise ValueError("ONNX/manifest names disagree with pinned class ordering")
        supplied = names if classes is None else _names(classes)
        if (target_label not in supplied.values()
                or any(names.get(index) != name for index, name in supplied.items())):
            raise ValueError("Passed class mapping/target_label disagrees with model names")
        if metadata.get("task", None if trained else "detect") != "detect":
            raise ValueError("Expected detection metadata")
        if "imgsz" in metadata and list(ast.literal_eval(metadata["imgsz"])) != [640, 640]:
            raise ValueError("Metadata input size disagrees with graph")
        args = ast.literal_eval(metadata.get("args", "{}"))
        if not isinstance(args, dict) or (trained and args.get("nms") is not False):
            raise ValueError("Trained knife metadata must explicitly declare nms=False")
        if args.get("nms", False) or args.get("end2end", False):
            raise ValueError("Only non-end-to-end exports with external NMS are supported")
        self.input_name, self.output_name = inputs[0].name, outputs[0].name
        self.target_id = next(index for index, name in names.items() if name == target_label)
        self.label, self.classes, self.confidence = target_label, names, float(confidence)
        self.tiled, self.tile_size, self.tile_stride = tiled, tile_size, tile_stride
        self.source = Path(entry['path']).parent.name if trained else (
            "knife-onnx" if sha == KNIFE_SHA else "people-yolov8n")
        self.backend = "onnxruntime-cuda:0" if backend == "cuda" else "onnxruntime-cpu"
        self.info = {"path": str(path), "sha256": sha, "backend": self.backend,
                     "providers": self.session.get_providers(), "metadata": dict(metadata),
                     "provenance": entry, "input_shape": inputs[0].shape,
                     "output_shape": outputs[0].shape, "precision": np.dtype(self.output_dtype).name,
                     "input_dtype":np.dtype(self.dtype).name, "batch_capacity": self.batch_capacity}
        self.last_metrics = {}
        self.dynamic_batch = False
        self.view_shape, self.host_dtype = (3, 640, 640), self.dtype

    def _prepare(self, bgr, tensor, offset, native=False):
        h, w = bgr.shape[:2]
        scale = 1.0 if native else 640 / max(h, w)
        rw, rh = max(1, round(w * scale)), max(1, round(h * scale))
        left, top = (640 - rw) // 2, (640 - rh) // 2
        canvas = np.full((640, 640, 3), 114, dtype=np.uint8)
        resized = bgr if (rw, rh) == (w, h) else cv2.resize(
            bgr, (rw, rh), interpolation=cv2.INTER_LINEAR)
        canvas[top:top + rh, left:left + rw] = resized
        if self.dtype == np.uint8:
            tensor[:] = canvas[...,::-1].transpose(2,0,1)
        else:
            blob=cv2.dnn.blobFromImage(canvas,scalefactor=1/255.,swapRB=True,crop=False)
            np.copyto(tensor,blob[0],casting='unsafe')
        return h, w, rh, rw, top, left, offset, native

    def _decode(self, output, geometry, frame_hw, confidence=None):
        confidence = self.confidence if confidence is None else confidence
        pred = output.T
        if np.any(pred[:, 2:4] < 0) or np.any((pred[:, 4:] < 0) | (pred[:, 4:] > 1)):
            raise ValueError("Expected nonnegative cxcywh sizes and probability class scores")
        winners = pred[:, 4:].argmax(axis=1)
        # Preserve the confidence cutoff instead of rounding it to FP16.
        scores = pred[np.arange(len(pred)), winners + 4].astype(np.float32, copy=False)
        selected = (winners == self.target_id) & (scores >= confidence)
        return self._boxes(pred[selected, :4].astype(np.float64), scores[selected], geometry, frame_hw)

    def _boxes(self, pred, scores, geometry, frame_hw):
        h, w, rh, rw, top, left, offset, native = geometry
        boxes = np.concatenate((pred[:, :2] - pred[:, 2:4] / 2,
                                pred[:, :2] + pred[:, 2:4] / 2), axis=1)
        # Invert actual rounded resize dimensions and integer padding/crop origins.
        boxes[:, [0, 2]] = np.clip((boxes[:, [0, 2]] - left) / (rw / w), 0, w)
        boxes[:, [1, 3]] = np.clip((boxes[:, [1, 3]] - top) / (rh / h), 0, h)
        valid = np.all(boxes[:, 2:] > boxes[:, :2], axis=1)
        fh, fw = frame_hw
        boxes = (boxes + [*offset, *offset]) / [fw, fh, fw, fh]
        source = self.source + (":tile" if native else ":full")
        return [{"label": self.label, "box": box.tolist(), "score": float(score),
                 "source": source} for box, score in zip(boxes[valid], scores[valid])]

    def _infer(self, tensor):
        return self.session.run([self.output_name], {self.input_name: tensor})[0]

    def _candidates(self, tensor, confidence):
        """Returns one (cxcywh float64 [n,4], scores float32 [n]) pair per view in tensor."""
        output = self._infer(tensor)
        if (output.shape != (len(tensor), *self.output_shape[1:])
                or output.dtype != self.output_dtype or not np.isfinite(output).all()):
            raise ValueError("Invalid raw YOLO output shape, dtype or nonfinite values")
        result = []
        for raw in output:
            pred = raw.T
            if np.any(pred[:, 2:4] < 0) or np.any((pred[:, 4:] < 0) | (pred[:, 4:] > 1)):
                raise ValueError("Expected nonnegative cxcywh sizes and probability class scores")
            winners = pred[:, 4:].argmax(axis=1)
            scores = pred[np.arange(len(pred)), winners + 4].astype(np.float32, copy=False)
            selected = (winners == self.target_id) & (scores >= confidence)
            result.append((pred[selected, :4].astype(np.float64), scores[selected]))
        return result

    def detect(self, bgr, confidence=None, tiled=None):
        detections, self.last_metrics = self.detect_with_metrics(bgr, confidence, tiled)
        return detections

    def detect_with_metrics(self, bgr, confidence=None, tiled=None, zoom_regions=(), zoom_confidence=None,
                            max_views=None, tile_cursor=0):
        """zoom_regions: pixel xyxy crops (e.g. around people) letterboxed up to 640 so small objects get more pixels.
        max_views caps views per call (zoom first, then native tiles rotated by tile_cursor across calls)."""
        _frame(bgr)
        confidence = self.confidence if confidence is None else float(confidence)
        tiled = self.tiled if tiled is None else bool(tiled)
        started = perf_counter()
        metrics = {"full_count": 0, "tile_count": 0, "zoom_count": 0, "view_count": 0, "batch_count": 0, "padded_views":0,
                   "prepare_ms":0., "inference_ms":0., "postprocess_ms":0.,
                   "elapsed_ms": 0.0, "backend": self.backend, "complete": False}
        try:
            h, w = bgr.shape[:2]
            views = [(0, 0, w, h, False)]
            if tiled and max(h, w) > 640:
                def starts(length):
                    end = max(0, length - self.tile_size)
                    positions = list(range(0, end + 1, self.tile_stride))
                    return positions if positions[-1] == end else positions + [end]

                views.extend((x, y, min(w, x + self.tile_size), min(h, y + self.tile_size), True)
                             for y in starts(h) for x in starts(w))
            zooms = [(int(x1), int(y1), int(x2), int(y2), "zoom") for x1, y1, x2, y2 in zoom_regions
                     if x2 - x1 >= 8 and y2 - y1 >= 8]
            tiles = views[1:]
            metrics["tiles_total"] = len(tiles)
            if max_views and tiles and 1 + len(tiles) + len(zooms) > max_views:
                zooms = zooms[:max(0, max_views - 3)]
                budget = max(2, max_views - 1 - len(zooms))
                if budget < len(tiles):
                    tiles = [tiles[(tile_cursor + i) % len(tiles)] for i in range(budget)]
            views = views[:1] + tiles + zooms
            zoom_confidence = confidence if zoom_confidence is None else float(zoom_confidence)
            detections = []
            for start in range(0, len(views), self.batch_capacity):
                batch = views[start:start + self.batch_capacity]
                size = len(batch) if self.dynamic_batch else self.batch_capacity
                tensor = np.empty((size, *self.view_shape), dtype=self.host_dtype, order="C")
                tick=perf_counter()
                geometry = [self._prepare(bgr[y1:y2, x1:x2], tensor[i], (x1, y1), native is True)
                            + ((native == "zoom"),)
                            for i, (x1, y1, x2, y2, native) in enumerate(batch)]
                if len(batch)<len(tensor):
                    tensor[len(batch):].fill(0)
                    metrics['padded_views']+=len(tensor)-len(batch)
                metrics['prepare_ms']+=(perf_counter()-tick)*1000
                metrics["batch_count"] += 1
                tick=perf_counter()
                candidates = self._candidates(tensor, min(confidence, zoom_confidence))
                metrics['inference_ms']+=(perf_counter()-tick)*1000
                tick=perf_counter()
                for (pred, scores), transform in zip(candidates, geometry):
                    zoomed = transform[-1]
                    keep = scores >= (zoom_confidence if zoomed else confidence)
                    found = self._boxes(pred[keep], scores[keep], transform[:-1], (h, w))
                    if zoomed:
                        for item in found:
                            item["source"] = self.source + ":zoom"
                    detections.extend(found)
                    metrics["zoom_count" if zoomed else ("tile_count" if transform[-2] else "full_count")] += 1
                metrics['postprocess_ms']+=(perf_counter()-tick)*1000
            detections = _nms(detections)
            metrics["complete"] = True
            return detections, metrics
        finally:
            metrics["view_count"] = metrics["full_count"] + metrics["tile_count"] + metrics["zoom_count"]
            metrics["elapsed_ms"] = (perf_counter() - started) * 1000


class TensorRTYoloDetector(YoloDetector):
    def __init__(self, path, engine_path, confidence=.25, target_label="knife",
                 tiled=False, tile_size=640, tile_stride=None, max_batch=8):
        if not torch.cuda.is_available():
            raise RuntimeError("TensorRT detector requires CUDA:0")
        if not np.isfinite(confidence) or not 0 <= confidence <= 1:
            raise ValueError("confidence must be finite and in [0,1]")
        if type(tile_size) is not int or not 1 <= tile_size <= 640:
            raise ValueError("tile_size must be an integer in [1,640]")
        tile_stride = max(1, tile_size * 3 // 4) if tile_stride is None else tile_stride
        if type(tile_stride) is not int or not 1 <= tile_stride <= tile_size:
            raise ValueError("tile_stride must be an integer in [1,tile_size]")
        path = Path(path).resolve(strict=True)
        engine_path = Path(engine_path).resolve(strict=True)
        if target_label == "knife":
            records = json.loads((ROOT / "models/manifest.json").read_text())["models"]
            entry = next(item for item in records if item.get("path") == "knife-yolov8n-u8/model.onnx")
            path, sha = _verified(path, (entry["sha256"],))
            names = {0: "knife"}
            self.dtype, self.output_dtype = np.uint8, np.float16
            self.output_shape, self.batch_capacity = (None, 5, 8400), max_batch
            source = "knife-yolov8n-u8"
        elif target_label == "person":
            path, sha = _verified(path, (PEOPLE_SHA,))
            names = COCO_CLASSES
            self.dtype, self.output_dtype = np.float32, np.float32
            self.output_shape, self.batch_capacity = (1, 84, 8400), 1
            source = "people-yolov8n"
        else:
            raise ValueError("TensorRT detector only supports knife or person")
        self.target_id = next(index for index, name in names.items() if name == target_label)
        self.label, self.classes, self.confidence = target_label, names, float(confidence)
        self.tiled, self.tile_size, self.tile_stride = tiled, tile_size, tile_stride
        self.source, self.last_metrics = source, {}
        self.backend = "tensorrt-cuda:0"
        self.dynamic_batch = self.batch_capacity > 1
        self.lock = threading.Lock()
        self.view_shape, self.host_dtype = (640, 640, 3), np.uint8

        import tensorrt as trt
        self._trt = trt
        self._logger = trt.Logger(trt.Logger.WARNING)
        self._runtime = trt.Runtime(self._logger)
        self._engine = self._runtime.deserialize_cuda_engine(engine_path.read_bytes())
        if self._engine is None:
            raise RuntimeError(f"Cannot deserialize TensorRT engine: {engine_path}")
        self._context = self._engine.create_execution_context()
        inputs, outputs = [], []
        for index in range(self._engine.num_io_tensors):
            name = self._engine.get_tensor_name(index)
            mode = self._engine.get_tensor_mode(name)
            (inputs if mode == trt.TensorIOMode.INPUT else outputs).append(name)
        if len(inputs) != 1 or len(outputs) != 1:
            raise RuntimeError("TensorRT YOLO engine must have one input and one output")
        self.input_name, self.output_name = inputs[0], outputs[0]
        input_dtype = self._engine.get_tensor_dtype(self.input_name)
        output_dtype = self._engine.get_tensor_dtype(self.output_name)
        expected_input = trt.uint8 if self.dtype == np.uint8 else trt.float32
        expected_output = trt.float16 if self.output_dtype == np.float16 else trt.float32
        if input_dtype != expected_input or output_dtype != expected_output:
            raise RuntimeError(f"TensorRT dtype mismatch: {input_dtype} -> {output_dtype}")
        digest = hashlib.sha256(engine_path.read_bytes()).hexdigest()
        self._stream = torch.cuda.Stream(device="cuda:0")
        torch_in = torch.uint8 if self.dtype == np.uint8 else torch.float32
        torch_out = torch.float16 if self.output_dtype == np.float16 else torch.float32
        self._input_gpu = torch.empty((self.batch_capacity, 3, 640, 640), dtype=torch_in, device="cuda:0")
        self._staging_gpu = torch.empty((self.batch_capacity, 640, 640, 3), dtype=torch.uint8, device="cuda:0")
        self._output_gpu = torch.empty((self.batch_capacity, self.output_shape[1], 8400), dtype=torch_out, device="cuda:0")
        self.info = {
            "path": str(path), "sha256": sha, "engine_path": str(engine_path),
            "engine_sha256": digest, "backend": "tensorrt-cuda:0",
            "input_name": self.input_name, "output_name": self.output_name,
            "precision": np.dtype(self.output_dtype).name,
            "input_dtype": np.dtype(self.dtype).name,
            "batch_capacity": self.batch_capacity,
        }

    def _prepare(self, bgr, canvas, offset, native=False):
        """Letterbox BGR HWC uint8 on CPU; RGB/CHW/scaling happen on the GPU in _run_engine."""
        h, w = bgr.shape[:2]
        scale = 1.0 if native else 640 / max(h, w)
        rw, rh = max(1, round(w * scale)), max(1, round(h * scale))
        left, top = (640 - rw) // 2, (640 - rh) // 2
        if rw != 640 or rh != 640:
            canvas.fill(114)
        target = canvas[top:top + rh, left:left + rw]
        if (rw, rh) == (w, h):
            target[:] = bgr
        else:
            cv2.resize(bgr, (rw, rh), dst=target, interpolation=cv2.INTER_LINEAR)
        return h, w, rh, rw, top, left, offset, native

    def _run_engine(self, tensor):
        count = len(tensor)
        staging = self._staging_gpu[:count]
        staging.copy_(torch.from_numpy(tensor))
        chw = staging.permute(0, 3, 1, 2).flip(1)
        if self.dtype == np.uint8:
            self._input_gpu[:count].copy_(chw)
        else:
            torch.mul(chw, np.float32(1 / 255.), out=self._input_gpu[:count])
        self._context.set_input_shape(self.input_name, (count, 3, 640, 640))
        output_shape = tuple(self._context.get_tensor_shape(self.output_name))
        if output_shape != (count, self.output_shape[1], 8400):
            raise RuntimeError(f"Invalid TensorRT output shape: {output_shape}")
        input_gpu, output_gpu = self._input_gpu[:count], self._output_gpu[:count]
        self._context.set_tensor_address(self.input_name, input_gpu.data_ptr())
        self._context.set_tensor_address(self.output_name, output_gpu.data_ptr())
        if not self._context.execute_async_v3(self._stream.cuda_stream):
            raise RuntimeError("TensorRT execution failed")
        return output_gpu

    def _infer(self, tensor):
        with self.lock, torch.cuda.stream(self._stream):
            return self._run_engine(tensor).cpu().numpy()

    def _candidates(self, tensor, confidence):
        with self.lock, torch.cuda.stream(self._stream):
            output = self._run_engine(tensor)
            classes = output[:, 4:, :]
            invalid = ((~torch.isfinite(output)).any() | (output[:, 2:4, :] < 0).any()
                       | (classes < 0).any() | (classes > 1).any())
            if classes.shape[1] == 1:
                scores = classes[:, 0, :].float()
                selected = scores >= confidence
            else:
                values, winners = classes.max(dim=1)
                scores = values.float()
                selected = (winners == self.target_id) & (scores >= confidence)
            view, anchor = selected.nonzero(as_tuple=True)
            boxes = output[view, :4, anchor].double()
            picked = scores[view, anchor]
            invalid, view, boxes, picked = invalid.cpu().item(), view.cpu().numpy(), boxes.cpu().numpy(), picked.cpu().numpy()
        if invalid:
            raise ValueError("Invalid raw YOLO output: nonfinite, negative sizes or non-probability scores")
        return [(boxes[view == index], picked[view == index]) for index in range(len(tensor))]


class _FightNet(torch.nn.Module):
    def __init__(self):
        super().__init__()
        from pytorchvideo.models.x3d import create_x3d

        # Exactly upstream hub x3d_m defaults, except the intentional logits head.
        self.backbone = create_x3d(input_clip_length=16, input_crop_size=224,
                                   head_activation=None)
        self.backbone.blocks[-1].proj = torch.nn.Sequential(
            torch.nn.Dropout(.3), torch.nn.Linear(2048, 2))
        if tuple(self.backbone.blocks[-1].pool.pool.kernel_size) != (16, 7, 7):
            raise RuntimeError("Unexpected X3D-M pooling configuration")

    def forward(self, inputs):
        return self.backbone(inputs)


class FightClassifier:
    """CUDA:0 FP16 X3D-M; score(frames) -> float P(fight), class index 1.

    Supply exactly 16 chronological past BGR frames of identical shape, ending
    at the current packet. No seeking, temporal resampling, padding, or tracking.
    score_regions(frames, regions) -> list[float] in the same order; each region
    is normalized xyxy, fixed across all frames, cropped floor(start)/ceil(end).
    All regions are processed in chunks of batch_size (1..4), never truncated.
    Scores are unvalidated candidates, not localized proof; no decision threshold.
    """

    def __init__(self, path=FIGHT_PATH, *, batch_size=4):
        if type(batch_size) is not int or not 1 <= batch_size <= 8:
            raise ValueError("batch_size must be an integer in [1,8]")
        path, sha = _verified(path, (FIGHT_SHA,))
        if not torch.cuda.is_available():
            raise RuntimeError("FightClassifier requires CUDA:0; no CPU fallback")
        from safetensors.torch import load_file

        self.model = _FightNet()
        self.model.load_state_dict(load_file(str(path), device="cpu"), strict=True)
        self.device, self.batch_size = torch.device("cuda:0"), batch_size
        self.model.to(device=self.device, dtype=torch.float16).eval().requires_grad_(False)
        self.info = {"path": str(path), "sha256": sha, "backend": "pytorch-cuda:0",
                     "dtype": "float16", "input_shape": [None, 3, 16, 224, 224],
                     "probability": "single softmax, fight index 1; uncalibrated"}

    def score(self, frames):
        return self.score_regions(frames, [(0., 0., 1., 1.)])[0]

    @torch.inference_mode()
    def upload(self, frames):
        """16 chronological BGR frames -> float GPU tensor [16,3,H,W] reused for every region crop."""
        frames = tuple(frames)
        if len(frames) != 16:
            raise ValueError("Exactly 16 past frames are required")
        for frame in frames:
            _frame(frame)
            if frame.shape != frames[0].shape:
                raise ValueError("All frames must share a shape and coordinate system")
        return torch.from_numpy(np.stack(frames)).to(self.device).permute(0, 3, 1, 2).float()

    @torch.inference_mode()
    def score_uploaded(self, items, batch_size=None):
        """items: [(uploaded video, normalized xyxy)] -> P(fight) per item; GPU bilinear crop/resize."""
        import torch.nn.functional as F
        batch_size = batch_size or self.batch_size
        tensors = []
        for video, region in items:
            h, w = video.shape[2:]
            box = np.asarray(region, dtype=np.float64)
            if (box.shape != (4,) or not np.isfinite(box).all()
                    or np.any(box < 0) or np.any(box > 1) or np.any(box[2:] <= box[:2])):
                raise ValueError("Regions must be finite, positive-area normalized xyxy boxes")
            x1, y1 = np.floor(box[:2] * [w, h]).astype(int)
            x2, y2 = np.ceil(box[2:] * [w, h]).astype(int)
            crop = F.interpolate(video[:, :, y1:y2, x1:x2], size=(224, 224), mode="bilinear",
                                 align_corners=False).round_().clamp_(0, 255)
            tensors.append(crop.flip(1).permute(1, 0, 2, 3))
        scores = []
        for start in range(0, len(tensors), batch_size):
            inputs = torch.stack(tensors[start:start + batch_size]).div_(255.).sub_(.45).div_(.225).half()
            logits = self.model(inputs)
            if logits.shape != (len(inputs), 2) or not torch.isfinite(logits).all().item():
                raise ValueError("Invalid X3D logits shape or nonfinite values")
            scores.extend(torch.softmax(logits.float(), dim=1)[:, 1].cpu().tolist())
        return scores

    @torch.inference_mode()
    def score_items(self, items, batch_size=None):
        """items: [(16 frames, normalized xyxy)] possibly from different clips; returns P(fight) per item."""
        batch_size = batch_size or self.batch_size
        clips = []
        for frames, region in items:
            frames = tuple(frames)
            if len(frames) != 16:
                raise ValueError("Exactly 16 past frames are required")
            for frame in frames:
                _frame(frame)
                if frame.shape != frames[0].shape:
                    raise ValueError("All frames must share a shape and coordinate system")
            h, w = frames[0].shape[:2]
            box = np.asarray(region, dtype=np.float64)
            if (box.shape != (4,) or not np.isfinite(box).all()
                    or np.any(box < 0) or np.any(box > 1) or np.any(box[2:] <= box[:2])):
                raise ValueError("Regions must be finite, positive-area normalized xyxy boxes")
            x1, y1 = np.floor(box[:2] * [w, h]).astype(int)
            x2, y2 = np.ceil(box[2:] * [w, h]).astype(int)
            clips.append(np.stack([cv2.resize(frame[y1:y2, x1:x2], (224, 224),
                                              interpolation=cv2.INTER_LINEAR)[..., ::-1]
                                   for frame in frames]))
        scores = []
        for start in range(0, len(clips), batch_size):
            rgb = torch.from_numpy(np.stack(clips[start:start + batch_size])).to(self.device)
            inputs = rgb.permute(0, 4, 1, 2, 3).contiguous().float().div_(255.).sub_(.45).div_(.225).half()
            logits = self.model(inputs)
            if logits.shape != (len(inputs), 2) or not torch.isfinite(logits).all().item():
                raise ValueError("Invalid X3D logits shape or nonfinite values")
            scores.extend(torch.softmax(logits.float(), dim=1)[:, 1].cpu().tolist())
        return scores

    @torch.inference_mode()
    def score_regions(self, frames, regions):
        frames = tuple(frames)
        if len(frames) != 16:
            raise ValueError("Exactly 16 past frames are required")
        for frame in frames:
            _frame(frame)
            if frame.shape != frames[0].shape:
                raise ValueError("All frames must share a shape and coordinate system")
        h, w = frames[0].shape[:2]
        bounds = []
        for region in regions:
            box = np.asarray(region, dtype=np.float64)
            if (box.shape != (4,) or not np.isfinite(box).all()
                    or np.any(box < 0) or np.any(box > 1) or np.any(box[2:] <= box[:2])):
                raise ValueError("Regions must be finite, positive-area normalized xyxy boxes")
            x1, y1 = np.floor(box[:2] * [w, h]).astype(int)
            x2, y2 = np.ceil(box[2:] * [w, h]).astype(int)
            bounds.append((x1, y1, x2, y2))
        scores = []
        for start in range(0, len(bounds), self.batch_size):
            clips = []
            for x1, y1, x2, y2 in bounds[start:start + self.batch_size]:
                rgb = np.stack([cv2.resize(frame[y1:y2, x1:x2], (224, 224),
                                          interpolation=cv2.INTER_LINEAR)[..., ::-1]
                                for frame in frames])
                clip = torch.from_numpy(rgb).permute(3, 0, 1, 2).float()
                clips.append(clip.div_(255.).sub_(.45).div_(.225))
            inputs = torch.stack(clips).to(device=self.device, dtype=torch.float16)
            logits = self.model(inputs)
            if logits.shape != (len(clips), 2) or not torch.isfinite(logits).all().item():
                raise ValueError("Invalid X3D logits shape or nonfinite values")
            # Fixed 16x224x224 input pools to 1x1x1 before projection, so moving
            # softmax after the final global average is equivalent, not a second softmax.
            scores.extend(torch.softmax(logits.float(), dim=1)[:, 1].cpu().tolist())
        return scores


class RTDetrKnifeDetector:
    def __init__(self, confidence=.5, tiled=True):
        from transformers import RTDetrForObjectDetection, RTDetrImageProcessor
        path, sha = _verified(ROOT/'models/knife-rtdetr/model.safetensors',
                              ('8cbec5cda1ddefe8f9daaeba676ff68063648b0b7c9e9ab38aa67a7c63dc5df0',))
        if not torch.cuda.is_available():
            raise RuntimeError('RT-DETR requires CUDA; no CPU fallback')
        self.processor = RTDetrImageProcessor.from_pretrained(path.parent, local_files_only=True)
        self.model = RTDetrForObjectDetection.from_pretrained(
            path.parent, local_files_only=True, use_safetensors=True,
            dtype=torch.float16, disable_custom_kernels=True).to('cuda:0').eval()
        if self.model.config.id2label.get(5) != 'knife':
            raise ValueError('RT-DETR knife class mapping mismatch')
        self.confidence, self.tiled = confidence, tiled
        self.info = {'path':str(path),'sha256':sha,'backend':'pytorch-cuda:0','dtype':'float16',
                     'input_shape':[None,3,480,480],'knife_class':5,'batch_size':4}
        self.last_metrics = {}

    @torch.inference_mode()
    def detect(self, bgr):
        _frame(bgr)
        tick = perf_counter()
        h, w = bgr.shape[:2]
        views = [(0,0,w,h)]
        if self.tiled and max(h,w)>640:
            def starts(length):
                end=max(0,length-640)
                return sorted(set(list(range(0,end+1,480))+[end]))
            views.extend((x,y,min(w,x+640),min(h,y+640)) for y in starts(h) for x in starts(w))
        detections=[]
        for start in range(0,len(views),4):
            batch=views[start:start+4]
            images=[np.ascontiguousarray(bgr[y1:y2,x1:x2,::-1]) for x1,y1,x2,y2 in batch]
            inputs=self.processor(images=images,return_tensors='pt').to('cuda:0')
            inputs['pixel_values']=inputs['pixel_values'].half()
            output=self.model(**inputs)
            probabilities=output.logits.float().sigmoid()
            values, labels=probabilities.max(dim=-1)
            raw_boxes=output.pred_boxes.float()
            for i,(x1,y1,x2,y2) in enumerate(batch):
                chosen=(labels[i]==5)&(values[i]>=self.confidence)
                boxes=raw_boxes[i,chosen].cpu().numpy()
                scores=values[i,chosen].cpu().tolist()
                xyxy=np.concatenate((boxes[:,:2]-boxes[:,2:]/2,boxes[:,:2]+boxes[:,2:]/2),axis=1)
                xyxy=np.clip(xyxy,0,1)*[x2-x1,y2-y1,x2-x1,y2-y1]+[x1,y1,x1,y1]
                xyxy/=np.array([w,h,w,h])
                for box,score in zip(xyxy,scores):
                    if box[2]>box[0] and box[3]>box[1]:
                        detections.append({'label':'knife','box':box.tolist(),'score':score,
                                           'source':'knife-rtdetr:'+('full' if start+i==0 else 'tile')})
        self.last_metrics={'full_count':1,'tile_count':len(views)-1,'view_count':len(views),
                           'elapsed_ms':(perf_counter()-tick)*1000,'backend':'pytorch-cuda:0','complete':True}
        return _nms(detections)
