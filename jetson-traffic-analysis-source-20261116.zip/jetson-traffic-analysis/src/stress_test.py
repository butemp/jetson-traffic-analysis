"""多路压力测试：模拟多线程抽帧并调用 VLM。"""
import platform
import resource
import statistics
import threading
import time

import config
import vlm
from video import VideoProcessor


def _mem_mb():
    rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return round(rss / (1024 * 1024), 1) if platform.system() == "Darwin" else round(rss / 1024, 1)


def run(video_path: str, concurrency: int = 2, frames_per_stream: int = None) -> dict:
    concurrency = max(1, min(int(concurrency), config.STRESS_MAX_CONCURRENCY))
    frames_per_stream = frames_per_stream or config.STRESS_FRAMES_PER_STREAM
    latencies = []
    errors = []
    lock = threading.Lock()
    client = vlm.get_engine()

    def worker():
        try:
            proc = VideoProcessor(video_path, interval_sec=config.SAMPLE_INTERVAL_SEC, max_frames=frames_per_stream)
            n = 0
            for _, frame in proc.iter_frames():
                if n >= frames_per_stream:
                    break
                t0 = time.time()
                vlm.classify_frame(frame, client)
                with lock:
                    latencies.append(time.time() - t0)
                n += 1
        except Exception as e:
            with lock:
                errors.append(str(e))

    t0 = time.time()
    threads = [threading.Thread(target=worker, daemon=True) for _ in range(concurrency)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    elapsed = time.time() - t0
    vals = sorted(latencies)
    pct = lambda p: round(vals[min(len(vals) - 1, int(len(vals) * p))], 3) if vals else 0
    return {
        "concurrency": concurrency,
        "total_frames": len(vals),
        "elapsed_sec": round(elapsed, 2),
        "throughput_fps": round(len(vals) / elapsed, 3) if elapsed else 0,
        "avg_latency_sec": round(statistics.mean(vals), 3) if vals else 0,
        "p50_latency_sec": pct(0.50),
        "p95_latency_sec": pct(0.95),
        "p99_latency_sec": pct(0.99),
        "mem_peak_mb": _mem_mb(),
        "errors": errors[:5],
    }
