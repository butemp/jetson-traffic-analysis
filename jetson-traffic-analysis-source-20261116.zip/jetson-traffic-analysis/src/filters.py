"""误报规则引擎。命中规则的事件在入库前被抑制。"""
import json
from datetime import datetime

import db

_CONF_N = {"低": 1, "中": 2, "高": 3}


def _params(rule):
    try:
        return json.loads(rule.get("params_json") or "{}")
    except Exception:
        return {}


def _in_scope(rule, det_task_id, source_id) -> bool:
    scope = rule.get("scope") or "global"
    if scope == "global":
        return True
    if scope == "task":
        return not rule.get("det_task_id") or rule.get("det_task_id") == det_task_id
    if scope == "source":
        return not rule.get("source_id") or rule.get("source_id") == source_id
    return False


def _match_time_window(params, now=None) -> bool:
    now = now or datetime.now()
    weekdays = params.get("weekdays")
    if weekdays and now.isoweekday() not in set(int(x) for x in weekdays):
        return False
    start = params.get("start") or "00:00"
    end = params.get("end") or "23:59"
    cur = now.strftime("%H:%M")
    if start <= end:
        in_window = start <= cur <= end
    else:
        in_window = cur >= start or cur <= end
    mode = params.get("mode") or "mute"
    return in_window if mode == "mute" else not in_window


def should_filter(result: dict, det_task_id=None, source_id=None) -> tuple[bool, dict]:
    if not result or not result.get("has_event"):
        return False, {}
    for rule in db.list_filter_rules(enabled=True):
        if not _in_scope(rule, det_task_id, source_id):
            continue
        p = _params(rule)
        rt = rule.get("rule_type")
        hit = False
        if rt == "confidence":
            min_conf = p.get("min", "中")
            hit = _CONF_N.get(result.get("confidence"), 2) < _CONF_N.get(min_conf, 2)
        elif rt == "mute_type":
            hit = result.get("event_type") in set(p.get("event_types") or [])
        elif rt == "keyword":
            desc = result.get("description") or ""
            hit = any(k and k in desc for k in (p.get("keywords") or []))
        elif rt == "time_window":
            hit = _match_time_window(p)
        if hit:
            db.inc_filter_hit(rule["id"])
            return True, rule
    return False, {}
