"""可选 YOLO HTTP 客户端：失败自动降级，不中断分析。"""
import logging
import math
import threading
import time
from collections import Counter
from dataclasses import dataclass
from typing import Optional

import cv2

import config

log = logging.getLogger("traffic.yolo")
_fail_count = 0
_disabled_until = 0.0
_backoff_sec = 0.0
_last_error = "尚未完成检测"
_state_lock = threading.RLock()


@dataclass(frozen=True)
class DetectionResult:
    detections: list
    healthy: bool
    error: str = ""

_EVENT_MAP = {
    "bicycle": "非机动车",
    "motorcycle": "非机动车",
    "accident": "交通事故",
    "crash": "交通事故",
    "fire": "明火",
    "flame": "明火",
    "smoke": "烟火",
    "obstacle": "障碍物",
    "wrong-way": "逆行",
    "congestion": "拥堵",
    "jam": "拥堵",
}
_VEHICLES = {"car", "bus", "truck", "van"}


def enabled() -> bool:
    with _state_lock:
        return bool(config.YOLO_API_URL) and time.monotonic() >= _disabled_until


def healthy() -> bool:
    with _state_lock:
        return enabled() and not _last_error


def configured() -> bool:
    return bool(config.YOLO_API_URL)


def detect(frame, conf: Optional[float] = None) -> DetectionResult:
    global _fail_count, _disabled_until, _backoff_sec, _last_error
    if not enabled():
        return DetectionResult([], False, "检测器未配置或处于退避状态")
    try:
        import httpx
        ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 85])
        if not ok:
            raise RuntimeError("JPEG encode failed")
        files = {"file": ("frame.jpg", buf.tobytes(), "image/jpeg")}
        data = {"conf": str(conf if conf is not None else config.YOLO_CONF_THRESH)}
        timeout = httpx.Timeout(config.YOLO_TIMEOUT, connect=min(0.5, config.YOLO_TIMEOUT))
        response = httpx.post(config.YOLO_API_URL, files=files, data=data, timeout=timeout)
        response.raise_for_status()
        payload = response.json()
        detections = payload if isinstance(payload, list) else payload.get("detections") if isinstance(payload, dict) else None
        if not isinstance(detections, list):
            raise ValueError("检测器返回值缺少有效 detections 列表")
        height, width = frame.shape[:2]
        for item in detections:
            if not isinstance(item, dict) or not isinstance(item.get("name") or item.get("class"), str):
                raise ValueError("检测项必须包含类别名称")
            bbox = item.get("bbox")
            if not isinstance(bbox, list) or len(bbox) != 4 or not all(
                type(value) in (int, float) and math.isfinite(value) for value in bbox
            ):
                raise ValueError("检测框必须是四个有限像素坐标")
            if not (0 <= bbox[0] < bbox[2] <= width and 0 <= bbox[1] < bbox[3] <= height):
                raise ValueError("检测框超出当前帧")
            score = item.get("confidence")
            if type(score) not in (int, float) or not math.isfinite(score) or not 0 <= score <= 1:
                raise ValueError("检测置信度无效")
        with _state_lock:
            _fail_count = 0
            _backoff_sec = 0.0
            _disabled_until = 0.0
            _last_error = ""
        return DetectionResult(detections, True)
    except Exception as exc:
        with _state_lock:
            _last_error = str(exc)
            _fail_count += 1
            if _fail_count >= max(1, config.YOLO_DISABLE_AFTER_FAILURES):
                base = max(1.0, config.YOLO_DISABLE_BACKOFF_SEC)
                _backoff_sec = min(600.0, _backoff_sec * 2 if _backoff_sec > 0 else base)
                _disabled_until = time.monotonic() + _backoff_sec
        log.warning("YOLO 检测不可用: %s", exc)
        return DetectionResult([], False, str(exc))


def map_event(det: dict) -> Optional[str]:
    name = str(det.get("name") or det.get("class") or "").strip().lower()
    if name in _EVENT_MAP:
        return _EVENT_MAP[name]
    raw = str(det.get("name") or det.get("class") or "").strip()
    if raw in config.YOLO_RISK_TYPES:
        return raw
    if name in _VEHICLES:
        return "车辆"
    return None


def event_candidates(detections: list) -> list:
    out = []
    for d in detections or []:
        ev = map_event(d)
        if ev:
            out.append(ev)
    return out


def risk_event_candidates(detections: list, target_objects: Optional[list] = None) -> list:
    out = []
    targets = {str(x).strip() for x in (target_objects or []) if str(x).strip()}
    for ev in event_candidates(detections):
        if ev in config.YOLO_RISK_TYPES or ev in targets:
            out.append(ev)
    return out


def has_candidate(detections: list) -> bool:
    return bool(event_candidates(detections))


def summarize(detections: list) -> str:
    if not detections:
        return ""
    names = []
    for d in detections:
        ev = map_event(d)
        if ev:
            names.append(ev)
    if not names:
        return ""
    c = Counter(names)
    return "YOLO预检测到: " + "、".join(f"{k}{v}个" for k, v in c.items())


def status() -> dict:
    with _state_lock:
        return {"enabled": enabled(), "configured": configured(), "url": config.YOLO_API_URL,
                "ok": healthy(), "message": _last_error if configured() else "YOLO_API_URL 未配置",
                "retry_after_seconds": max(0, round(_disabled_until - time.monotonic(), 1))}
