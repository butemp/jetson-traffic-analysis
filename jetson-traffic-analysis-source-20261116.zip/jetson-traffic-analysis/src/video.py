"""视频抽帧：固定间隔、带时间戳的生成器。seek 优先，失败回退顺序读。"""
import logging
import threading
import time
from typing import Callable, Dict, Iterator, Optional, Set, Tuple

import config
import cv2
import numpy as np

log = logging.getLogger("traffic.video")
STREAM_PREFIXES = ("http://", "https://", "rtsp://", "rtmp://", "tcp://", "udp://")
CANCEL_POLL_SEC = 0.25
_readers: Dict[str, "SharedStreamReader"] = {}
# Always take _readers_lock before a reader's condition when both are needed.
_readers_lock = threading.Lock()
# Retiring readers may still be inside native release(); retain their join handles.
_reader_threads: Set[threading.Thread] = set()


def _is_cancelled(cancelled: Optional[Callable[[], bool]]) -> bool:
    return cancelled is not None and cancelled()


def _wait_cancelled(delay: float, cancelled: Optional[Callable[[], bool]]) -> bool:
    deadline = time.monotonic() + max(0.0, delay)
    while not _is_cancelled(cancelled):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return False
        time.sleep(min(remaining, CANCEL_POLL_SEC))
    return True


def normalize_stream_url(path: str) -> str:
    """修正常见 RTSP/RTMP 误写：rtsp:user:pwd@host/path -> rtsp://user:pwd@host/path。"""
    s = str(path or "").strip()
    low = s.lower()
    for scheme in ("rtsp", "rtmp", "http", "https", "tcp", "udp"):
        prefix = scheme + ":"
        if low.startswith(prefix) and not low.startswith(prefix + "//"):
            return scheme + "://" + s[len(prefix):].lstrip("/")
    return s


def is_stream_path(path: str) -> bool:
    return normalize_stream_url(path).lower().startswith(STREAM_PREFIXES)


def _gst_pipeline(url: str) -> str:
    """Jetson GStreamer 硬解 pipeline，兼容 H264/H265 网络流。"""
    quoted_url = url.replace("\\", "\\\\").replace('"', '\\"')
    if url.lower().startswith("rtsp://"):
        return (
            f'rtspsrc location="{quoted_url}" latency=200 protocols=tcp ! '
            "decodebin ! nvvidconv ! video/x-raw,format=BGRx ! "
            "videoconvert ! video/x-raw,format=BGR ! appsink drop=1 max-buffers=1 sync=false"
        )
    return (
        f'uridecodebin uri="{quoted_url}" ! nvvidconv ! video/x-raw,format=BGRx ! '
        "videoconvert ! video/x-raw,format=BGR ! appsink drop=1 max-buffers=1 sync=false"
    )


def open_capture(
    path: str, cancelled: Optional[Callable[[], bool]] = None,
) -> Optional[cv2.VideoCapture]:
    """设置网络超时；取消时返回 None，不预读丢弃首帧。"""
    if _is_cancelled(cancelled):
        return None
    path = normalize_stream_url(path)
    if is_stream_path(path):
        if config.USE_GSTREAMER and getattr(cv2, "CAP_GSTREAMER", None) is not None:
            cap = None
            try:
                cap = cv2.VideoCapture(_gst_pipeline(path), cv2.CAP_GSTREAMER)
                if not _is_cancelled(cancelled) and cap.isOpened():
                    return cap
            except Exception:
                # Backend exception messages can contain URL credentials.
                log.debug("GStreamer open failed, fallback to FFmpeg/default capture")
            if cap is not None:
                cap.release()
            if _is_cancelled(cancelled):
                return None
        params = []
        for name, value in (
            ("CAP_PROP_OPEN_TIMEOUT_MSEC", config.VIDEO_OPEN_TIMEOUT_MSEC),
            ("CAP_PROP_READ_TIMEOUT_MSEC", config.VIDEO_READ_TIMEOUT_MSEC),
        ):
            prop = getattr(cv2, name, None)
            if prop is not None:
                params.extend([prop, int(value)])
        if params and hasattr(cv2, "CAP_FFMPEG"):
            if _is_cancelled(cancelled):
                return None
            cap = None
            try:
                cap = cv2.VideoCapture(path, cv2.CAP_FFMPEG, params)
                if not _is_cancelled(cancelled) and cap.isOpened():
                    _set_low_latency_props(cap)
                    if not _is_cancelled(cancelled):
                        return cap
            except Exception:
                log.debug("VideoCapture params unsupported, fallback to property setter")
            if cap is not None:
                cap.release()
            if _is_cancelled(cancelled):
                return None
    if _is_cancelled(cancelled):
        return None
    cap = cv2.VideoCapture(path)
    if _is_cancelled(cancelled):
        cap.release()
        return None
    if is_stream_path(path):
        for name, value in (
            ("CAP_PROP_OPEN_TIMEOUT_MSEC", config.VIDEO_OPEN_TIMEOUT_MSEC),
            ("CAP_PROP_READ_TIMEOUT_MSEC", config.VIDEO_READ_TIMEOUT_MSEC),
        ):
            prop = getattr(cv2, name, None)
            if prop is not None:
                try:
                    cap.set(prop, int(value))
                except Exception:
                    pass
        _set_low_latency_props(cap)
    if _is_cancelled(cancelled):
        cap.release()
        return None
    return cap


def _set_low_latency_props(cap: cv2.VideoCapture) -> None:
    """尽量压低 OpenCV 内部缓冲，减少 RTSP 延迟和积压。"""
    prop = getattr(cv2, "CAP_PROP_BUFFERSIZE", None)
    if prop is not None:
        try:
            cap.set(prop, 1)
        except Exception:
            pass


def _resize_by_max_edge(frame, max_edge: int):
    if not max_edge or max_edge <= 0:
        return frame
    h, w = frame.shape[:2]
    edge = max(h, w)
    if edge <= max_edge:
        return frame
    scale = max_edge / float(edge)
    return cv2.resize(frame, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)


class SharedStreamReader:
    """单个 URL 只维护一路解码，把最新帧/JPEG 缓存在内存里给预览和分析复用。"""

    # 按需产物保活窗口：最近该时间内有消费者才生成 JPEG/分析帧，省 Jetson CPU
    WANTED_TTL_SEC = 10.0

    def __init__(self, path: str):
        self.path = normalize_stream_url(path)
        self._cond = threading.Condition()
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._refs = 0
        self._full_rate_refs = 0
        self._frame = None
        self._analysis_frame = None
        self._jpeg = None
        self._frame_id = 0
        self._frame_ts = 0.0
        self._idle_since = time.monotonic()
        self._last_error = ""
        self._jpeg_wanted_until = 0.0
        self._analysis_wanted_until = 0.0

    def acquire(self) -> "SharedStreamReader":
        with _readers_lock:
            reader = _readers.get(self.path)
            if reader is None:
                reader = SharedStreamReader(self.path) if self._stop.is_set() else self
                _readers[self.path] = reader
            return reader._acquire_locked()

    def _acquire_locked(self, full_rate=False) -> "SharedStreamReader":
        with self._cond:
            self._refs += 1
            self._full_rate_refs += int(full_rate)
            if self._thread is None:
                _reader_threads.difference_update([t for t in _reader_threads if not t.is_alive()])
                try:
                    self._thread = threading.Thread(target=self._loop, name="stream-reader", daemon=True)
                    self._thread.start()
                    _reader_threads.add(self._thread)
                except Exception:
                    self._refs -= 1
                    self._retire_locked()
                    raise
            self._cond.notify_all()
        return self

    def release(self, full_rate=False) -> None:
        with self._cond:
            self._full_rate_refs = max(0,self._full_rate_refs-int(full_rate))
            if self._refs > 0:
                self._refs -= 1
                if self._refs == 0:
                    self._idle_since = time.monotonic()
                    self._cond.notify_all()

    def _retire_locked(self) -> None:
        # A retired reader is terminal: resetting its event could revive an exiting thread.
        self._stop.set()
        if _readers.get(self.path) is self:
            del _readers[self.path]
        self._frame = self._analysis_frame = self._jpeg = None
        self._frame_ts = 0.0
        self._jpeg_wanted_until = self._analysis_wanted_until = 0.0
        self._cond.notify_all()

    def _should_stop(self) -> bool:
        with _readers_lock:
            with self._cond:
                if self._stop.is_set():
                    return True
                if self._refs == 0 and (time.monotonic() - self._idle_since) >= config.STREAM_READER_IDLE_TTL_SEC:
                    self._retire_locked()
                    return True
                return False

    def stop(self) -> None:
        with _readers_lock:
            with self._cond:
                self._retire_locked()

    def read_frame(
        self, after_id: Optional[int] = None, timeout: float = 3.0,
        cancelled: Optional[Callable[[], bool]] = None,
    ):
        return self._read_cached("_frame", after_id, timeout, cancelled)

    def read_analysis_frame(
        self, after_id: Optional[int] = None, timeout: float = 3.0,
        cancelled: Optional[Callable[[], bool]] = None,
    ):
        return self._read_cached("_analysis_frame", after_id, timeout, cancelled)

    def read_jpeg(
        self, after_id: Optional[int] = None, timeout: float = 3.0,
        cancelled: Optional[Callable[[], bool]] = None,
    ):
        return self._read_cached("_jpeg", after_id, timeout, cancelled)

    def read_packet(self, after_id=None, timeout=.5, cancelled=None):
        return self._read_cached('_frame',after_id,timeout,cancelled,with_time=True)

    def _read_cached(self, attribute, after_id, timeout, cancelled, with_time=False):
        deadline = time.monotonic() + max(0.1, timeout)
        # External callbacks run without _cond held to avoid reversing the lock order.
        while not _is_cancelled(cancelled):
            with self._cond:
                if self._stop.is_set():
                    break
                now = time.monotonic()
                if attribute == "_analysis_frame":
                    self._analysis_wanted_until = now + self.WANTED_TTL_SEC
                elif attribute == "_jpeg":
                    self._jpeg_wanted_until = now + self.WANTED_TTL_SEC
                value = getattr(self, attribute)
                if self._fresh(value) and (after_id is None or self._frame_id != after_id):
                    frame_id = self._frame_id
                    captured = self._frame_ts
                    payload = bytes(value) if attribute == "_jpeg" else value.copy()
                else:
                    remaining = deadline - now
                    if remaining <= 0:
                        break
                    self._cond.wait(min(remaining, CANCEL_POLL_SEC))
                    continue
            if _is_cancelled(cancelled) or self._stop.is_set():
                break
            return (frame_id,captured,payload) if with_time else (frame_id,payload)
        return (None,None,None) if with_time else (None,None)

    def _fresh(self, value) -> bool:
        return value is not None and (time.monotonic() - self._frame_ts) <= config.STREAM_STALE_FRAME_SEC

    def _publish(self, frame) -> None:
        now = time.monotonic()
        with self._cond:
            if self._stop.is_set():
                return
            jpeg_wanted = now < self._jpeg_wanted_until
            analysis_wanted = now < self._analysis_wanted_until
        analysis = _resize_by_max_edge(frame, config.STREAM_ANALYSIS_MAX_EDGE) if analysis_wanted else None
        jpeg = None
        if jpeg_wanted:
            preview = _resize_by_max_edge(frame, config.STREAM_PREVIEW_MAX_EDGE)
            ok, buf = cv2.imencode(".jpg", preview, [cv2.IMWRITE_JPEG_QUALITY, config.STREAM_JPEG_QUALITY])
            jpeg = buf.tobytes() if ok else None
        with self._cond:
            if self._stop.is_set():
                return
            self._frame = frame
            self._analysis_frame = analysis
            self._jpeg = jpeg
            self._frame_id += 1
            self._frame_ts = now
            self._last_error = ""
            self._cond.notify_all()

    def _loop(self) -> None:
        cap = None
        failures = 0
        next_publish = 0.0
        try:
            delay = 1.0 / max(0.5, config.STREAM_READER_FPS)
            log.info("共享取流器启动: fps=%.1f", config.STREAM_READER_FPS)
            while not self._should_stop():
                if cap is None or not cap.isOpened():
                    if cap is not None:
                        cap.release()
                    cap = open_capture(self.path, cancelled=self._should_stop)
                    if cap is None or self._should_stop():
                        break
                    if not cap.isOpened():
                        failures += 1
                        with self._cond:
                            self._last_error = "无法打开视频流"
                        if _wait_cancelled(config.STREAM_RECONNECT_DELAY_SEC, self._should_stop):
                            break
                        continue
                    failures = 0

                # Keep draining decoder buffers; throttle publication, not capture.
                if self._should_stop():
                    break
                try:
                    ok = cap.grab()
                except Exception:
                    ok = False
                if self._should_stop():
                    break
                if ok and (self._full_rate_refs > 0 or time.monotonic() >= next_publish):
                    try:
                        ok, frame = cap.retrieve()
                    except Exception:
                        ok, frame = False, None
                    if self._should_stop():
                        break
                    if ok and frame is not None:
                        failures = 0
                        self._publish(frame)
                        next_publish = max(next_publish + delay, time.monotonic())
                        continue
                elif ok:
                    failures = 0
                    continue

                failures += 1
                if failures >= config.STREAM_MAX_READ_FAILURES:
                    log.warning("共享取流器连续读帧失败，重连")
                    cap.release()
                    cap = None
                    failures = 0
                    retry_delay = config.STREAM_RECONNECT_DELAY_SEC
                else:
                    retry_delay = 0.05
                if _wait_cancelled(retry_delay, self._should_stop):
                    break
        except Exception as exc:
            log.warning("共享取流器异常停止 (%s)", type(exc).__name__)
        finally:
            with _readers_lock:
                with self._cond:
                    self._retire_locked()
            frame = None
            if cap is not None:
                try:
                    cap.release()
                except Exception as exc:
                    log.warning("共享取流器释放失败 (%s)", type(exc).__name__)
            log.info("共享取流器停止")


def acquire_stream_reader(path: str, *, full_rate=False) -> SharedStreamReader:
    key = normalize_stream_url(path)
    with _readers_lock:
        reader = _readers.get(key)
        if reader is None:
            reader = SharedStreamReader(key)
            _readers[key] = reader
        return reader._acquire_locked(full_rate=full_rate)


def peek_stream_frame(path: str, timeout: float = 0.1):
    key = normalize_stream_url(path)
    with _readers_lock:
        reader = _readers.get(key)
    if reader is None:
        return None
    _, frame = reader.read_frame(timeout=timeout)
    return frame


def shutdown_stream_readers(timeout: float = 3.0) -> bool:
    """停止当前取流器；仅在线程确已退出时返回 True，总 join 等待不超过 timeout。"""
    with _readers_lock:
        readers = list(_readers.values())
        _readers.clear()
        for reader in readers:
            with reader._cond:
                reader._retire_locked()
        threads = list(_reader_threads)
    deadline = time.monotonic() + max(0.0, timeout)
    for thread in threads:
        if thread is not threading.current_thread():
            thread.join(max(0.0, deadline - time.monotonic()))
    with _readers_lock:
        pending = [thread for thread in threads if thread.is_alive()]
        _reader_threads.difference_update([thread for thread in threads if not thread.is_alive()])
    if pending:
        log.warning("共享取流器关闭超时，仍有 %d 个线程未退出", len(pending))
    return not pending


def probe(
    path: str, cancelled: Optional[Callable[[], bool]] = None,
) -> Tuple[float, int, float]:
    """返回 (fps, total_frames, duration_sec)；读不到则 fps=0/total=0/duration=0。"""
    cap = open_capture(path, cancelled=cancelled)
    if cap is None:
        return 0.0, 0, 0.0
    try:
        if _is_cancelled(cancelled) or not cap.isOpened():
            return 0.0, 0, 0.0
        fps = cap.get(cv2.CAP_PROP_FPS) or 0.0
        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        if _is_cancelled(cancelled):
            return 0.0, 0, 0.0
        duration = (total / fps) if (fps > 0 and total > 0) else 0.0
        return fps, total, duration
    finally:
        cap.release()


class VideoProcessor:
    """按 SAMPLE_INTERVAL_SEC 间隔抽帧。

    yield 出的是原始分辨率帧（截图存档用），送检的缩放交给 vlm.frame_to_b64。
    cancelled 必须快速返回；检查无法中断正在执行的原生 OpenCV 调用。
    """

    def __init__(
        self,
        path: str,
        interval_sec: float = None,
        max_frames: int = None,
        cancelled: Optional[Callable[[], bool]] = None,
    ):
        self.path = path
        self._cancelled = cancelled
        self.interval_sec = config.SAMPLE_INTERVAL_SEC if interval_sec is None else interval_sec
        self.is_stream = is_stream_path(path)
        default_max = config.STREAM_ANALYSIS_MAX_FRAMES if self.is_stream else config.MAX_FRAMES_PER_TASK
        self.max_frames = default_max if max_frames is None else max_frames
        if self.is_stream:
            self.fps, self.total, self.duration = 0.0, 0, 0.0
        else:
            self.fps, self.total, self.duration = probe(path, cancelled=cancelled)
        self._plan()

    def _plan(self) -> None:
        """预算抽帧时间点列表（秒）。"""
        if self.is_stream:
            self._timestamps = []
            return
        if self.duration > 0:
            n = int(-(-self.duration // self.interval_sec))  # ceil
            # 均匀落在每个区间中点，避免漏掉结尾
            ts = [(i + 0.5) * self.interval_sec for i in range(n) if (i + 0.5) * self.interval_sec < self.duration]
        else:
            # 无法估时长（某些流/损坏）：退化为单次探测读取
            ts = []
        if len(ts) > self.max_frames:
            log.warning("视频过长，抽帧从 %d 截断到 %d（可调 MAX_FRAMES_PER_TASK）", len(ts), self.max_frames)
            ts = ts[: self.max_frames]
        self._timestamps = ts

    @property
    def estimated_frames(self) -> int:
        if self.is_stream and self.max_frames <= 0:
            return 0
        if self.is_stream or self.duration <= 0 or not self._timestamps:
            return self.max_frames
        return max(1, len(self._timestamps))

    def _iter_stream_frames(self) -> Iterator[Tuple[float, np.ndarray]]:
        """直播流持续抽帧：按墙钟时间采样，断流后自动重连。"""
        if _is_cancelled(self._cancelled):
            return
        if config.STREAM_SHARED_READER_ENABLED:
            yield from self._iter_shared_stream_frames()
            return
        count = 0
        started = time.monotonic()
        next_emit = started
        failures = 0
        cap = None
        log.info(
            "直播流持续分析模式: interval=%.2fs max_frames=%s",
            self.interval_sec,
            "unlimited" if self.max_frames <= 0 else self.max_frames,
        )
        try:
            while not _is_cancelled(self._cancelled) and (self.max_frames <= 0 or count < self.max_frames):
                if cap is None or not cap.isOpened():
                    if cap is not None:
                        cap.release()
                    cap = open_capture(self.path, cancelled=self._cancelled)
                    if cap is None or _is_cancelled(self._cancelled):
                        return
                    if not cap.isOpened():
                        failures += 1
                        if failures >= config.STREAM_MAX_READ_FAILURES:
                            log.warning("直播流重连失败过多，停止分析")
                            break
                        if _wait_cancelled(config.STREAM_RECONNECT_DELAY_SEC, self._cancelled):
                            return
                        continue
                    failures = 0

                now = time.monotonic()
                if now < next_emit:
                    if _wait_cancelled(next_emit - now, self._cancelled):
                        return
                    continue

                for _ in range(max(0, config.STREAM_ANALYSIS_DRAIN_FRAMES)):
                    if _is_cancelled(self._cancelled):
                        return
                    try:
                        ok = cap.grab()
                    except Exception:
                        ok = False
                    if _is_cancelled(self._cancelled):
                        return
                    if not ok:
                        break

                if _is_cancelled(self._cancelled):
                    return
                try:
                    ok, frame = cap.read()
                except Exception:
                    ok, frame = False, None
                if _is_cancelled(self._cancelled):
                    return
                if not ok or frame is None:
                    failures += 1
                    if failures >= config.STREAM_MAX_READ_FAILURES:
                        log.warning("直播流连续读帧失败，准备重连")
                        cap.release()
                        cap = None
                        failures = 0
                        retry_delay = config.STREAM_RECONNECT_DELAY_SEC
                    else:
                        retry_delay = 0.05
                    if _wait_cancelled(retry_delay, self._cancelled):
                        return
                    continue
                failures = 0

                now = time.monotonic()
                yield now - started, frame
                count += 1
                next_emit = now + self.interval_sec
        finally:
            if cap is not None:
                cap.release()

    def _iter_shared_stream_frames(self) -> Iterator[Tuple[float, np.ndarray]]:
        """从共享取流器取最新帧，避免预览和分析重复打开同一路摄像头。"""
        if _is_cancelled(self._cancelled):
            return
        count = 0
        started = time.monotonic()
        next_emit = started
        last_id = None
        reader = acquire_stream_reader(self.path)
        log.info(
            "直播流共享取帧模式: interval=%.2fs max_frames=%s",
            self.interval_sec,
            "unlimited" if self.max_frames <= 0 else self.max_frames,
        )
        try:
            while not _is_cancelled(self._cancelled) and (self.max_frames <= 0 or count < self.max_frames):
                if reader._stop.is_set():
                    return
                now = time.monotonic()
                if now < next_emit:
                    if _wait_cancelled(min(CANCEL_POLL_SEC, next_emit - now), self._cancelled):
                        return
                    continue
                frame_id, frame = reader.read_analysis_frame(
                    after_id=last_id, timeout=max(2.0, self.interval_sec + 1.0),
                    cancelled=self._cancelled,
                )
                if _is_cancelled(self._cancelled) or reader._stop.is_set():
                    return
                if frame is None:
                    log.warning("直播流共享取帧超时")
                    next_emit = time.monotonic() + config.STREAM_RECONNECT_DELAY_SEC
                    continue
                last_id = frame_id
                now = time.monotonic()
                yield now - started, frame
                count += 1
                next_emit = now + self.interval_sec
        finally:
            reader.release()

    def iter_frames(self) -> Iterator[Tuple[float, np.ndarray]]:
        """生成 (timestamp_sec, frame_bgr)。"""
        if _is_cancelled(self._cancelled):
            return
        if self.is_stream:
            yield from self._iter_stream_frames()
            return
        cap = open_capture(self.path, cancelled=self._cancelled)
        if cap is None:
            return
        try:
            if _is_cancelled(self._cancelled):
                return
            if not cap.isOpened():
                raise RuntimeError("无法打开视频")
            if self.duration <= 0 or self.fps <= 0 or not self._timestamps:
                # 无固定时长时顺序读取；失败不产出占位帧。
                step = max(1, int(round(self.fps * self.interval_sec))) if self.fps > 0 else 1
                ts = 0.0
                count = 0
                log.info("流式抽帧模式: 每 %d 帧取 1 帧 (约 %.1fs/帧, 上限 %d 帧)", step, self.interval_sec, self.max_frames)
                while count < self.max_frames and not _is_cancelled(self._cancelled):
                    ok, frame = cap.read()
                    if _is_cancelled(self._cancelled):
                        return
                    if not ok or frame is None:
                        log.info("流结束/断开，已抽 %d 帧", count)
                        break
                    for _ in range(step - 1):
                        if _is_cancelled(self._cancelled):
                            return
                        skipped, skipped_frame = cap.read()
                        if _is_cancelled(self._cancelled):
                            return
                        if not skipped or skipped_frame is None:
                            break
                    if _is_cancelled(self._cancelled):
                        return
                    yield ts, frame
                    ts += self.interval_sec
                    count += 1
                return
            for ts in self._timestamps:
                if _is_cancelled(self._cancelled):
                    return
                target = int(ts * self.fps)
                if target < self.total:
                    cap.set(cv2.CAP_PROP_POS_FRAMES, target)
                if _is_cancelled(self._cancelled):
                    return
                ok, frame = cap.read()
                if _is_cancelled(self._cancelled):
                    return
                if not ok or frame is None:
                    # seek 偶发失败：顺序往后找最多 8 帧
                    for _ in range(8):
                        if _is_cancelled(self._cancelled):
                            return
                        ok, frame = cap.read()
                        if _is_cancelled(self._cancelled):
                            return
                        if ok and frame is not None:
                            break
                if not ok or frame is None:
                    log.warning("读取时间点 %.2fs 失败，跳过", ts)
                    continue
                yield ts, frame
        finally:
            cap.release()
