"""SQLite 持久化（标准库 sqlite3 + WAL）。

表：analysis_tasks / traffic_events（Phase 1）
    notifications / samples / audit_logs（Phase 2）
启动时 init_db() 幂等建表并迁移旧库（加列 + 回填 severity）。
"""
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime
from typing import Optional

import config

_write_lock = threading.Lock()


@contextmanager
def _connect():
    conn = sqlite3.connect(config.DB_PATH, timeout=30)
    try:
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON;")
        with conn:
            yield conn
    finally:
        conn.close()


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _ensure_column(conn, table: str, col: str, ddl: str) -> None:
    cols = {row[1] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}
    if col not in cols:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {ddl}")


def init_db() -> None:
    from pathlib import Path
    mounts = Path("/proc/self/mountinfo")
    if mounts.exists():
        matches = []
        for line in mounts.read_text().splitlines():
            fields = line.split()
            separator = fields.index("-")
            mount = Path(fields[4].replace("\\040", " "))
            if config.DB_PATH.is_relative_to(mount):
                matches.append((len(mount.parts), fields[separator + 1]))
        if matches and max(matches)[1] in ("nfs", "nfs4", "cifs", "smb3"):
            raise RuntimeError("SQLite WAL 数据库不能放在网络文件系统；请用 TRAFFIC_DB_PATH 指定节点本地磁盘，视频目录可保持不变")
    with _connect() as conn:
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS owned_uploads (
                path TEXT PRIMARY KEY,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS streaming_events (
                id TEXT PRIMARY KEY,
                task_id TEXT NOT NULL,
                event_id INTEGER,
                payload TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY(task_id) REFERENCES analysis_tasks(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS analysis_tasks (
                id           TEXT PRIMARY KEY,
                filename     TEXT,
                file_path    TEXT,
                duration_sec REAL,
                status       TEXT DEFAULT 'pending',
                progress     INTEGER DEFAULT 0,
                error        TEXT,
                created_at   TEXT,
                updated_at   TEXT
            );
            CREATE TABLE IF NOT EXISTS traffic_events (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id       TEXT,
                event_type    TEXT,
                timestamp_sec REAL,
                description   TEXT,
                snapshot_path TEXT,
                confidence    TEXT,
                created_at    TEXT,
                FOREIGN KEY (task_id) REFERENCES analysis_tasks(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS notifications (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id    INTEGER,
                level       TEXT,
                title       TEXT,
                message     TEXT,
                channel     TEXT,
                status      TEXT DEFAULT 'pending',
                payload     TEXT,
                error       TEXT,
                created_at  TEXT,
                sent_at     TEXT,
                read_at     TEXT
            );
            CREATE TABLE IF NOT EXISTS samples (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id     INTEGER,
                image_path   TEXT,
                label        TEXT,
                event_type   TEXT,
                prompt       TEXT,
                gt_json      TEXT,
                source_task  TEXT,
                reviewer     TEXT,
                exported     INTEGER DEFAULT 0,
                exported_at  TEXT,
                created_at   TEXT
            );
            CREATE TABLE IF NOT EXISTS audit_logs (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                ts           TEXT,
                actor        TEXT,
                action       TEXT,
                target_type  TEXT,
                target_id    TEXT,
                detail_json  TEXT,
                ip           TEXT
            );
            CREATE TABLE IF NOT EXISTS users (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                username     TEXT UNIQUE,
                pass_hash    TEXT,
                salt         TEXT,
                role         TEXT DEFAULT 'viewer',
                enabled      INTEGER DEFAULT 1,
                created_at   TEXT,
                updated_at   TEXT
            );
            CREATE TABLE IF NOT EXISTS data_sources (
                id            TEXT PRIMARY KEY,
                name          TEXT,
                kind          TEXT,
                uri           TEXT,
                lat           REAL,
                lng           REAL,
                address       TEXT,
                online        INTEGER DEFAULT 0,
                last_frame_at TEXT,
                created_at    TEXT
            );
            CREATE TABLE IF NOT EXISTS detection_tasks (
                id             TEXT PRIMARY KEY,
                name           TEXT,
                kind           TEXT,
                prompt         TEXT,
                target_objects TEXT,
                require_review INTEGER DEFAULT 1,
                min_confidence TEXT,
                severity_map   TEXT,
                interval_sec   REAL,
                gallery_ids    TEXT,
                roi_json       TEXT,
                status         TEXT DEFAULT 'enabled',
                created_at     TEXT
            );
            CREATE TABLE IF NOT EXISTS galleries (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                name        TEXT,
                description TEXT,
                mode        TEXT DEFAULT 'watch',
                created_at  TEXT
            );
            CREATE TABLE IF NOT EXISTS gallery_items (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                gallery_id  INTEGER,
                kind        TEXT,
                content     TEXT,
                image_path  TEXT,
                metadata    TEXT,
                created_at  TEXT,
                FOREIGN KEY (gallery_id) REFERENCES galleries(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS alerts (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                source_id     TEXT,
                event_id      INTEGER,
                det_task_id   TEXT,
                severity      TEXT,
                status        TEXT DEFAULT 'active',
                title         TEXT,
                message       TEXT,
                snapshot_path TEXT,
                assigned_to   TEXT,
                ack_comment   TEXT,
                resolve_comment TEXT,
                created_at    TEXT,
                ack_at        TEXT,
                resolved_at   TEXT
            );
            CREATE TABLE IF NOT EXISTS filter_rules (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                name          TEXT,
                rule_type     TEXT,
                params_json   TEXT,
                scope         TEXT DEFAULT 'global',
                det_task_id   TEXT,
                source_id     TEXT,
                enabled       INTEGER DEFAULT 1,
                hit_count     INTEGER DEFAULT 0,
                created_at    TEXT,
                updated_at    TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_events_task ON traffic_events(task_id, timestamp_sec);
            CREATE INDEX IF NOT EXISTS idx_events_created ON traffic_events(created_at);
            CREATE INDEX IF NOT EXISTS idx_notif_unread ON notifications(read_at, created_at);
            CREATE INDEX IF NOT EXISTS idx_samples_label ON samples(label, exported);
            CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_logs(ts DESC);
            CREATE INDEX IF NOT EXISTS idx_sources_online ON data_sources(online, kind);
            CREATE INDEX IF NOT EXISTS idx_alerts_status ON alerts(status, severity, created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_filter_rules_scope ON filter_rules(enabled, scope, det_task_id, source_id);
            """
        )
        # 迁移：给旧 traffic_events 加 Phase 2 列
        _ensure_column(conn, "traffic_events", "evidence_json", "evidence_json TEXT")
        _ensure_column(conn, "traffic_events", "severity", "severity TEXT")
        _ensure_column(conn, "traffic_events", "review_status", "review_status TEXT DEFAULT 'pending'")
        _ensure_column(conn, "traffic_events", "reviewer", "reviewer TEXT")
        _ensure_column(conn, "traffic_events", "review_comment", "review_comment TEXT")
        _ensure_column(conn, "traffic_events", "reviewed_at", "reviewed_at TEXT")
        _ensure_column(conn, "traffic_events", "sample_id", "sample_id INTEGER")
        _ensure_column(conn, "traffic_events", "det_task_id", "det_task_id TEXT")
        _ensure_column(conn, "traffic_events", "source_id", "source_id TEXT")
        _ensure_column(conn, "traffic_events", "gallery_match", "gallery_match TEXT")
        _ensure_column(conn, "analysis_tasks", "archived", "archived INTEGER DEFAULT 0")
        _ensure_column(conn, "data_sources", "archived", "archived INTEGER DEFAULT 0")
        _ensure_column(conn, "analysis_tasks", "det_task_id", "det_task_id TEXT")
        _ensure_column(conn, "analysis_tasks", "source_id", "source_id TEXT")
        _ensure_column(conn, "analysis_tasks", "sampled_frames", "sampled_frames INTEGER DEFAULT 0")
        _ensure_column(conn, "analysis_tasks", "similarity_skipped_frames", "similarity_skipped_frames INTEGER DEFAULT 0")
        _ensure_column(conn, "analysis_tasks", "yolo_checked_frames", "yolo_checked_frames INTEGER DEFAULT 0")
        _ensure_column(conn, "analysis_tasks", "vlm_checked_frames", "vlm_checked_frames INTEGER DEFAULT 0")
        _ensure_column(conn, "analysis_tasks", "last_frame_similarity", "last_frame_similarity REAL")
        _ensure_column(conn, "analysis_tasks", "last_vlm_output", "last_vlm_output TEXT")
        _ensure_column(conn, "analysis_tasks", "last_vlm_status", "last_vlm_status TEXT")
        _ensure_column(conn, "analysis_tasks", "last_vlm_event_type", "last_vlm_event_type TEXT")
        _ensure_column(conn, "analysis_tasks", "last_vlm_confidence", "last_vlm_confidence TEXT")
        _ensure_column(conn, "analysis_tasks", "last_vlm_at", "last_vlm_at TEXT")
        _ensure_column(conn, "detection_tasks", "roi_json", "roi_json TEXT")
        _ensure_column(conn, "galleries", "mode", "mode TEXT DEFAULT 'watch'")
        # 列加完后再建依赖这些列的索引
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_events_review ON traffic_events(review_status, severity)"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_events_dettask ON traffic_events(det_task_id, severity)"
        )


BUILTIN_TASK_ID = "builtin9"
STREAM_TASK_ID = "safety-stream"


def seed_stream_task():
    with _write_lock, _connect() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO detection_tasks(id,name,kind,prompt,target_objects,require_review,"
            "min_confidence,severity_map,gallery_ids,status,created_at) VALUES(?,?,?,?,?,1,?,?,?,'enabled',?)",
            (STREAM_TASK_ID, "逐帧刀具与斗殴巡检", "safety_stream", "先检测红框，后 vLLM 模型描述", '["刀具","打架斗殴"]',
             "中", "{}", "[]", _now()),
        )


def save_stream_event(task_id, payload, snapshot=None):
    import json
    with _write_lock, _connect() as conn:
        existing = conn.execute("SELECT event_id,payload FROM streaming_events WHERE id=? AND task_id=?",
                                (payload['id'], task_id)).fetchone()
        if existing:
            merged = {**json.loads(existing['payload']), **payload}
            conn.execute("UPDATE streaming_events SET payload=?,updated_at=? WHERE id=?",
                         (json.dumps(merged,ensure_ascii=False), _now(), payload['id']))
            if payload.get('description_status') == 'ready':
                text = payload['description']
                if payload.get('uncertainty'):
                    text += '；疑点：' + payload['uncertainty']
                conn.execute("UPDATE traffic_events SET description=? WHERE id=?", (text, existing['event_id']))
            return merged
        if snapshot is None:
            return None
        kind = '刀具' if payload['kind'] == 'knife' else '打架斗殴'
        probability = max((box.get('knife_probability') or 0. for box in payload.get('boxes', [])), default=0.)
        if payload['kind'] == 'knife':
            confidence = '高' if probability >= .75 else ('中' if probability >= .45 else '低')
            severity = 'L3' if confidence == '高' else 'L2'
            description = f'刀具候选已通过二次视觉核验（概率 {probability:.2f}），等待大模型补充描述'
        else:
            confidence, severity = '中', 'L2'
            description = '动作模型检出疑似肢体冲突，等待大模型补充描述'
        result = conn.execute(
            "INSERT INTO traffic_events(task_id,event_type,timestamp_sec,description,snapshot_path,confidence,"
            "severity,review_status,det_task_id,created_at,source_id) VALUES(?,?,?,?,?,?,?,'pending',?,?,(SELECT source_id FROM analysis_tasks WHERE id=?))",
            (task_id, kind, payload['start_pts'], description, snapshot, confidence, severity, STREAM_TASK_ID, _now(), task_id),
        )
        stored = {**payload, 'review_event_id': result.lastrowid}
        conn.execute("INSERT INTO streaming_events(id,task_id,event_id,payload,updated_at) VALUES(?,?,?,?,?)",
                     (payload['id'],task_id,result.lastrowid,json.dumps(stored,ensure_ascii=False),_now()))
        return stored


def list_stream_events(task_id):
    import json
    with _connect() as conn:
        rows = conn.execute("SELECT payload FROM streaming_events WHERE task_id=? ORDER BY updated_at DESC LIMIT 50",
                            (task_id,)).fetchall()
        return [json.loads(row['payload']) for row in rows]


def seed_builtin_task() -> None:
    """插入/同步内置默认检测任务（若不存在）。prompt 来自 prompts.SYSTEM_PROMPT。"""
    from prompts import EVENT_TYPES, SYSTEM_PROMPT, USER_TEXT
    import json as _json
    with _write_lock, _connect() as conn:
        if conn.execute("SELECT 1 FROM detection_tasks WHERE id=?", (BUILTIN_TASK_ID,)).fetchone():
            conn.execute(
                "UPDATE detection_tasks SET name=?, kind=?, prompt=?, target_objects=? WHERE id=?",
                (
                    "6类交通异常检测(内置)",
                    "builtin9",
                    SYSTEM_PROMPT + "\n\n" + USER_TEXT,
                    _json.dumps(EVENT_TYPES, ensure_ascii=False),
                    BUILTIN_TASK_ID,
                ),
            )
            return
        conn.execute(
            "INSERT INTO detection_tasks(id,name,kind,prompt,target_objects,require_review,"
            "min_confidence,severity_map,interval_sec,gallery_ids,roi_json,status,created_at) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?, 'enabled', ?)",
            (BUILTIN_TASK_ID, "6类交通异常检测(内置)", "builtin9", SYSTEM_PROMPT + "\n\n" + USER_TEXT,
             _json.dumps(EVENT_TYPES, ensure_ascii=False), 1, "中",
             "{}", None, "[]", None, _now()),
        )


def backfill_det_task() -> int:
    """存量 traffic_events/analysis_tasks 的 det_task_id 回填为 builtin9。"""
    n = 0
    with _write_lock, _connect() as conn:
        cur = conn.execute(
            "UPDATE traffic_events SET det_task_id=? WHERE det_task_id IS NULL", (BUILTIN_TASK_ID,)
        )
        n += cur.rowcount
        cur = conn.execute(
            "UPDATE analysis_tasks SET det_task_id=? WHERE det_task_id IS NULL", (BUILTIN_TASK_ID,)
        )
        n += cur.rowcount
    return n


def backfill_severity() -> int:
    """对存量 severity 为空的事件回填级别。返回回填条数。"""
    from escalation import compute_severity  # 延迟导入，避免循环
    n = 0
    with _connect() as conn:
        rows = conn.execute(
            "SELECT id, event_type, confidence FROM traffic_events WHERE severity IS NULL"
        ).fetchall()
        for r in rows:
            sev = compute_severity(r["event_type"], r["confidence"], True)
            if sev:
                conn.execute("UPDATE traffic_events SET severity=? WHERE id=?", (sev, r["id"]))
                n += 1
    return n


# ---------------- tasks ----------------
def create_task(task_id: str, filename: str, file_path: str, duration_sec: float = 0.0,
                det_task_id: str = None, source_id: str = None) -> None:
    with _write_lock, _connect() as conn:
        conn.execute(
            "INSERT INTO analysis_tasks(id, filename, file_path, duration_sec, status, det_task_id, source_id, "
            "created_at, updated_at) VALUES(?,?,?,?, 'pending', ?, ?, ?, ?)",
            (task_id, filename, file_path, duration_sec, det_task_id, source_id, _now(), _now()),
        )


def get_task(task_id: str) -> Optional[dict]:
    with _connect() as conn:
        row = conn.execute("SELECT * FROM analysis_tasks WHERE id=?", (task_id,)).fetchone()
        return dict(row) if row else None


def get_status(task_id: str) -> Optional[str]:
    with _connect() as conn:
        row = conn.execute("SELECT status FROM analysis_tasks WHERE id=?", (task_id,)).fetchone()
        return row["status"] if row else None


def list_tasks(limit: int = 200) -> list:
    with _connect() as conn:
        rows = conn.execute(
            "SELECT t.*, (SELECT COUNT(*) FROM traffic_events e WHERE e.task_id=t.id) AS event_count, "
            "(SELECT COUNT(*) FROM traffic_events e WHERE e.task_id=t.id AND e.review_status='pending') AS pending_review "
            "FROM analysis_tasks t WHERE COALESCE(t.archived,0)=0 ORDER BY created_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [dict(r) for r in rows]


def update_status(task_id: str, status: str, error: Optional[str] = None) -> bool:
    with _write_lock, _connect() as conn:
        result = conn.execute(
            "UPDATE analysis_tasks SET status=?, error=?, updated_at=? "
            "WHERE id=? AND status IN ('pending','processing')",
            (status, error, _now(), task_id),
        )
        return result.rowcount > 0


def update_progress(task_id: str, progress: int) -> None:
    progress = max(0, min(100, int(progress)))
    with _write_lock, _connect() as conn:
        conn.execute(
            "UPDATE analysis_tasks SET progress=?, updated_at=? WHERE id=?", (progress, _now(), task_id)
        )


def update_task_metrics(task_id: str, **fields) -> None:
    allowed = {
        "sampled_frames",
        "similarity_skipped_frames",
        "yolo_checked_frames",
        "vlm_checked_frames",
        "last_frame_similarity",
        "last_vlm_output",
        "last_vlm_status",
        "last_vlm_event_type",
        "last_vlm_confidence",
        "last_vlm_at",
    }
    sets = []
    args = []
    for k, v in fields.items():
        if k in allowed:
            sets.append(f"{k}=?")
            args.append(v)
    if not sets:
        return
    sets.append("updated_at=?")
    args.extend([_now(), task_id])
    with _write_lock, _connect() as conn:
        conn.execute(f"UPDATE analysis_tasks SET {', '.join(sets)} WHERE id=?", args)


def update_task_vlm_result(task_id: str, status: str, output: str,
                           event_type: str = "Normal", confidence: str = "低") -> None:
    text = (output or "").strip()
    if len(text) > 4000:
        text = text[:4000]
    with _write_lock, _connect() as conn:
        conn.execute(
            "UPDATE analysis_tasks SET last_vlm_output=?, last_vlm_status=?, "
            "last_vlm_event_type=?, last_vlm_confidence=?, last_vlm_at=?, updated_at=? WHERE id=?",
            (text, status, event_type or "Normal", confidence or "低", _now(), _now(), task_id),
        )


def reset_stale_tasks(reason: str = "服务重启，任务中断") -> int:
    with _write_lock, _connect() as conn:
        cur = conn.execute(
            "UPDATE analysis_tasks SET status='failed', error=?, updated_at=? "
            "WHERE status IN ('pending','processing')",
            (reason, _now()),
        )
        return cur.rowcount


def cancel_task(task_id: str) -> bool:
    with _write_lock, _connect() as conn:
        cur = conn.execute(
            "UPDATE analysis_tasks SET status='cancelled', updated_at=? "
            "WHERE id=? AND status IN ('pending','processing')",
            (_now(), task_id),
        )
        return cur.rowcount > 0


def delete_task(task_id: str) -> None:
    with _write_lock, _connect() as conn:
        conn.execute("DELETE FROM traffic_events WHERE task_id=?", (task_id,))
        conn.execute("DELETE FROM analysis_tasks WHERE id=?", (task_id,))


# ---------------- events ----------------
def insert_event(
    task_id: str,
    event_type: str,
    timestamp_sec: float,
    description: str,
    snapshot_path: Optional[str],
    confidence: str,
    severity: Optional[str] = None,
    det_task_id: Optional[str] = None,
    source_id: Optional[str] = None,
    gallery_match: Optional[str] = None,
) -> int:
    with _write_lock, _connect() as conn:
        cur = conn.execute(
            "INSERT INTO traffic_events(task_id, event_type, timestamp_sec, description, snapshot_path, "
            "confidence, severity, review_status, det_task_id, source_id, gallery_match, created_at) "
            "VALUES(?,?,?,?,?,?,?, 'pending', ?, ?, ?, ?)",
            (task_id, event_type, timestamp_sec, description, snapshot_path, confidence, severity,
             det_task_id, source_id, gallery_match, _now()),
        )
        return cur.lastrowid


def list_events(task_id: str) -> list:
    with _connect() as conn:
        rows = conn.execute(
            "SELECT * FROM traffic_events WHERE task_id=? ORDER BY timestamp_sec ASC", (task_id,)
        ).fetchall()
        return [dict(r) for r in rows]


def get_event(event_id: int) -> Optional[dict]:
    with _connect() as conn:
        row = conn.execute(
            "SELECT e.*, t.filename, t.id AS task_id FROM traffic_events e "
            "LEFT JOIN analysis_tasks t ON t.id=e.task_id WHERE e.id=?",
            (event_id,),
        ).fetchone()
        return dict(row) if row else None


def set_event_review(event_id: int, status: str, reviewer: str, comment: str) -> bool:
    with _write_lock, _connect() as conn:
        cur = conn.execute(
            "UPDATE traffic_events SET review_status=?, reviewer=?, review_comment=?, reviewed_at=? "
            "WHERE id=? AND COALESCE(review_status,'pending')='pending'",
            (status, reviewer, comment, _now(), event_id),
        )
        if cur.rowcount and status=='rejected':
            conn.execute("UPDATE alerts SET status='resolved',resolved_at=?,assigned_to=?,resolve_comment=? "
                         "WHERE event_id=? AND status IN ('active','acked')",
                         (_now(),reviewer,'人工驳回误报：'+comment,event_id))
        return cur.rowcount > 0


def set_event_description(event_id: int, description: str) -> None:
    with _write_lock, _connect() as conn:
        conn.execute("UPDATE traffic_events SET description=? WHERE id=?", (description, event_id))


def set_event_sample(event_id: int, sample_id: int) -> None:
    with _write_lock, _connect() as conn:
        conn.execute("UPDATE traffic_events SET sample_id=? WHERE id=?", (sample_id, event_id))


def list_review_queue(
    status: Optional[str] = None, event_type: Optional[str] = None, level: Optional[str] = None,
    limit: int = 100, offset: int = 0,
) -> list:
    sql = (
        "SELECT e.*, t.filename FROM traffic_events e "
        "LEFT JOIN analysis_tasks t ON t.id=e.task_id WHERE e.event_type<>'Normal'"
    )
    args = []
    if status:
        sql += " AND e.review_status=?"; args.append(status)
    if event_type:
        sql += " AND e.event_type=?"; args.append(event_type)
    if level:
        sql += " AND e.severity=?"; args.append(level)
    sql += " ORDER BY e.severity DESC, e.created_at DESC LIMIT ? OFFSET ?"
    args += [limit, offset]
    with _connect() as conn:
        return [dict(r) for r in conn.execute(sql, args).fetchall()]


def review_queue_count(status: Optional[str] = None) -> int:
    sql = "SELECT COUNT(*) FROM traffic_events WHERE event_type<>'Normal'"
    args = []
    if status:
        sql += " AND review_status=?"; args.append(status)
    with _connect() as conn:
        return conn.execute(sql, args).fetchone()[0]


# ---------------- notifications ----------------
def insert_notification(event_id, level, title, message, channel, status="pending", payload=None) -> int:
    import json as _json
    with _write_lock, _connect() as conn:
        cur = conn.execute(
            "INSERT INTO notifications(event_id, level, title, message, channel, status, payload, created_at) "
            "VALUES(?,?,?,?,?,?,?,?)",
            (event_id, level, title, message, channel, status,
             _json.dumps(payload, ensure_ascii=False) if payload else None, _now()),
        )
        return cur.lastrowid


def list_notifications(unread_only: bool = False, channel: str = "in_app", limit: int = 100) -> list:
    sql = "SELECT * FROM notifications WHERE channel=?"
    args = [channel]
    if unread_only:
        sql += " AND read_at IS NULL"
    sql += " ORDER BY created_at DESC LIMIT ?"
    args.append(limit)
    with _connect() as conn:
        return [dict(r) for r in conn.execute(sql, args).fetchall()]


def unread_notification_count(channel: str = "in_app") -> int:
    with _connect() as conn:
        return conn.execute(
            "SELECT COUNT(*) FROM notifications WHERE channel=? AND read_at IS NULL", (channel,)
        ).fetchone()[0]


def mark_notification_read(notif_id: int) -> bool:
    with _write_lock, _connect() as conn:
        cur = conn.execute(
            "UPDATE notifications SET read_at=? WHERE id=? AND read_at IS NULL", (_now(), notif_id)
        )
        return cur.rowcount > 0


def mark_all_notifications_read(channel: str = "in_app") -> int:
    with _write_lock, _connect() as conn:
        cur = conn.execute(
            "UPDATE notifications SET read_at=? WHERE channel=? AND read_at IS NULL", (_now(), channel)
        )
        return cur.rowcount


def get_notification(notif_id: int) -> Optional[dict]:
    with _connect() as conn:
        row = conn.execute("SELECT * FROM notifications WHERE id=?", (notif_id,)).fetchone()
        return dict(row) if row else None


def update_notification_status(notif_id: int, status: str, error: Optional[str] = None) -> None:
    with _write_lock, _connect() as conn:
        conn.execute(
            "UPDATE notifications SET status=?, error=?, sent_at=? WHERE id=?",
            (status, error, _now(), notif_id),
        )


# ---------------- samples ----------------
def insert_sample(event_id, snapshot_path, label, event_type, prompt, gt_json, source_task, reviewer) -> int:
    with _write_lock, _connect() as conn:
        cur = conn.execute(
            "INSERT INTO samples(event_id, image_path, label, event_type, prompt, gt_json, source_task, "
            "reviewer, created_at) VALUES(?,?,?,?,?,?,?,?,?)",
            (event_id, snapshot_path, label, event_type, prompt, gt_json, source_task, reviewer, _now()),
        )
        return cur.lastrowid


def set_sample_image(sample_id: int, image_name: str) -> None:
    with _write_lock, _connect() as conn:
        conn.execute("UPDATE samples SET image_path=? WHERE id=?", (image_name, sample_id))


def list_samples(label=None, event_type=None, exported=None, limit=200, offset=0) -> list:
    sql = "SELECT * FROM samples WHERE 1=1"
    args = []
    if label:
        sql += " AND label=?"; args.append(label)
    if event_type:
        sql += " AND event_type=?"; args.append(event_type)
    if exported is not None:
        sql += " AND exported=?"; args.append(1 if exported else 0)
    sql += " ORDER BY created_at DESC LIMIT ? OFFSET ?"
    args += [limit, offset]
    with _connect() as conn:
        return [dict(r) for r in conn.execute(sql, args).fetchall()]


def sample_stats() -> dict:
    with _connect() as conn:
        total = conn.execute("SELECT COUNT(*) FROM samples").fetchone()[0]
        pos = conn.execute("SELECT COUNT(*) FROM samples WHERE label='pos'").fetchone()[0]
        neg = conn.execute("SELECT COUNT(*) FROM samples WHERE label='neg'").fetchone()[0]
        exported = conn.execute("SELECT COUNT(*) FROM samples WHERE exported=1").fetchone()[0]
        return {"total": total, "pos": pos, "neg": neg, "unexported": total - exported, "exported": exported}


# ---------------- audit ----------------
def insert_audit(actor, action, target_type=None, target_id=None, detail=None, ip=None) -> None:
    import json as _json
    with _write_lock, _connect() as conn:
        conn.execute(
            "INSERT INTO audit_logs(ts, actor, action, target_type, target_id, detail_json, ip) "
            "VALUES(?,?,?,?,?,?,?)",
            (_now(), actor, action, target_type, str(target_id) if target_id is not None else None,
             _json.dumps(detail, ensure_ascii=False) if detail else None, ip),
        )


def list_audit(action=None, actor=None, limit=200, offset=0) -> list:
    sql = "SELECT * FROM audit_logs WHERE 1=1"
    args = []
    if action:
        sql += " AND action LIKE ?"; args.append(f"%{action}%")
    if actor:
        sql += " AND actor=?"; args.append(actor)
    sql += " ORDER BY ts DESC LIMIT ? OFFSET ?"
    args += [limit, offset]
    with _connect() as conn:
        return [dict(r) for r in conn.execute(sql, args).fetchall()]


# ---------------- users ----------------
def user_count() -> int:
    with _connect() as conn:
        return conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]


def admin_count(exclude_user_id=None) -> int:
    sql = "SELECT COUNT(*) FROM users WHERE role='admin' AND enabled=1"
    args = []
    if exclude_user_id is not None:
        sql += " AND id<>?"; args.append(exclude_user_id)
    with _connect() as conn:
        return conn.execute(sql, args).fetchone()[0]


def insert_user(username, pass_hash, salt, role="viewer", enabled=1) -> int:
    with _write_lock, _connect() as conn:
        cur = conn.execute(
            "INSERT INTO users(username,pass_hash,salt,role,enabled,created_at,updated_at) "
            "VALUES(?,?,?,?,?,?,?)",
            (username, pass_hash, salt, role, 1 if enabled else 0, _now(), _now()),
        )
        return cur.lastrowid


def get_user_by_name(username) -> Optional[dict]:
    with _connect() as conn:
        row = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        return dict(row) if row else None


def get_user(user_id) -> Optional[dict]:
    with _connect() as conn:
        row = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        return dict(row) if row else None


def list_users() -> list:
    with _connect() as conn:
        rows = conn.execute(
            "SELECT id,username,role,enabled,created_at,updated_at FROM users ORDER BY id ASC"
        ).fetchall()
        return [dict(r) for r in rows]


def update_user(user_id, **fields) -> bool:
    allowed = {"username", "pass_hash", "salt", "role", "enabled"}
    fields = {k: v for k, v in fields.items() if k in allowed}
    if not fields:
        return False
    fields["updated_at"] = _now()
    sets = ", ".join(f"{k}=?" for k in fields)
    with _write_lock, _connect() as conn:
        cur = conn.execute(f"UPDATE users SET {sets} WHERE id=?", list(fields.values()) + [user_id])
        return cur.rowcount > 0


def delete_user(user_id) -> bool:
    with _write_lock, _connect() as conn:
        cur = conn.execute("DELETE FROM users WHERE id=?", (user_id,))
        return cur.rowcount > 0


# ============ Phase 3: data_sources ============
def create_source(sid, name, kind, uri, lat=None, lng=None, address=None) -> None:
    with _write_lock, _connect() as conn:
        conn.execute(
            "INSERT INTO data_sources(id,name,kind,uri,lat,lng,address,online,created_at) "
            "VALUES(?,?,?,?,?,?,?,0,?)",
            (sid, name, kind, uri, lat, lng, address, _now()),
        )


def get_source(sid) -> Optional[dict]:
    with _connect() as conn:
        row = conn.execute("SELECT * FROM data_sources WHERE id=?", (sid,)).fetchone()
        return dict(row) if row else None


def list_sources() -> list:
    with _connect() as conn:
        return [dict(r) for r in conn.execute("SELECT * FROM data_sources WHERE COALESCE(archived,0)=0 ORDER BY created_at DESC").fetchall()]


def update_source(sid, **fields) -> bool:
    allowed = {"name", "uri", "lat", "lng", "address", "kind"}
    sets = []
    vals = []
    for k, v in fields.items():
        if k in allowed:
            sets.append(f"{k}=?")
            vals.append(v)
    if not sets:
        return False
    vals.append(sid)
    with _write_lock, _connect() as conn:
        cur = conn.execute(f"UPDATE data_sources SET {','.join(sets)} WHERE id=?", vals)
        return cur.rowcount > 0


def update_source_status(sid, online, last_frame_at=None) -> None:
    with _write_lock, _connect() as conn:
        conn.execute("UPDATE data_sources SET online=?, last_frame_at=? WHERE id=?",
                     (1 if online else 0, last_frame_at, sid))


def delete_source(sid) -> None:
    with _write_lock, _connect() as conn:
        conn.execute("UPDATE data_sources SET archived=1 WHERE id=?", (sid,))


# ============ Phase 3: detection_tasks ============
def create_task_det(tid, name, kind, prompt, target_objects, require_review=1,
                    min_confidence="中", severity_map="{}", interval_sec=None,
                    gallery_ids="[]", status="enabled", roi_json=None) -> None:
    with _write_lock, _connect() as conn:
        conn.execute(
            "INSERT INTO detection_tasks(id,name,kind,prompt,target_objects,require_review,"
            "min_confidence,severity_map,interval_sec,gallery_ids,roi_json,status,created_at) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (tid, name, kind, prompt, target_objects, require_review, min_confidence,
             severity_map, interval_sec, gallery_ids, roi_json, status, _now()),
        )


def get_task_det(tid) -> Optional[dict]:
    with _connect() as conn:
        row = conn.execute("SELECT * FROM detection_tasks WHERE id=?", (tid,)).fetchone()
        return dict(row) if row else None


def list_task_det() -> list:
    with _connect() as conn:
        return [dict(r) for r in conn.execute("SELECT * FROM detection_tasks ORDER BY created_at DESC").fetchall()]


def update_task_det(tid, **fields) -> None:
    if not fields:
        return
    sets = ", ".join(f"{k}=?" for k in fields)
    with _write_lock, _connect() as conn:
        conn.execute(f"UPDATE detection_tasks SET {sets} WHERE id=?",
                     list(fields.values()) + [tid])


def delete_task_det(tid) -> None:
    with _write_lock, _connect() as conn:
        conn.execute("DELETE FROM detection_tasks WHERE id=?", (tid,))


# ============ Phase 3: galleries / gallery_items ============
def create_gallery(name, description="", mode="watch") -> int:
    with _write_lock, _connect() as conn:
        cur = conn.execute("INSERT INTO galleries(name,description,mode,created_at) VALUES(?,?,?,?)",
                           (name, description, mode, _now()))
        return cur.lastrowid


def list_galleries() -> list:
    with _connect() as conn:
        rows = conn.execute(
            "SELECT g.*, (SELECT COUNT(*) FROM gallery_items i WHERE i.gallery_id=g.id) AS item_count "
            "FROM galleries g ORDER BY g.created_at DESC"
        ).fetchall()
        return [dict(r) for r in rows]


def delete_gallery(gid) -> None:
    with _write_lock, _connect() as conn:
        conn.execute("DELETE FROM gallery_items WHERE gallery_id=?", (gid,))
        conn.execute("DELETE FROM galleries WHERE id=?", (gid,))


def add_gallery_item(gallery_id, kind, content, image_path=None, metadata=None) -> int:
    import json as _json
    with _write_lock, _connect() as conn:
        cur = conn.execute(
            "INSERT INTO gallery_items(gallery_id,kind,content,image_path,metadata,created_at) "
            "VALUES(?,?,?,?,?,?)",
            (gallery_id, kind, content, image_path,
             _json.dumps(metadata, ensure_ascii=False) if metadata else None, _now()),
        )
        return cur.lastrowid


def list_gallery_items(gallery_id) -> list:
    with _connect() as conn:
        return [dict(r) for r in conn.execute(
            "SELECT * FROM gallery_items WHERE gallery_id=? ORDER BY id DESC", (gallery_id,)).fetchall()]


def get_gallery_items(ids) -> list:
    if not ids:
        return []
    q = ",".join("?" * len(ids))
    with _connect() as conn:
        return [dict(r) for r in conn.execute(
            f"SELECT * FROM gallery_items WHERE id IN ({q})", ids).fetchall()]


def delete_gallery_item(item_id) -> None:
    with _write_lock, _connect() as conn:
        conn.execute("DELETE FROM gallery_items WHERE id=?", (item_id,))


# ============ Phase 4: filter_rules ============
def create_filter_rule(name, rule_type, params_json, scope="global", det_task_id=None, source_id=None,
                       enabled=1) -> int:
    with _write_lock, _connect() as conn:
        cur = conn.execute(
            "INSERT INTO filter_rules(name,rule_type,params_json,scope,det_task_id,source_id,enabled,"
            "hit_count,created_at,updated_at) VALUES(?,?,?,?,?,?,?,0,?,?)",
            (name, rule_type, params_json, scope, det_task_id, source_id, 1 if enabled else 0, _now(), _now()),
        )
        return cur.lastrowid


def list_filter_rules(enabled=None, scope=None, det_task_id=None, source_id=None) -> list:
    sql = "SELECT * FROM filter_rules WHERE 1=1"
    args = []
    if enabled is not None:
        sql += " AND enabled=?"; args.append(1 if enabled else 0)
    if scope:
        sql += " AND scope=?"; args.append(scope)
    if det_task_id:
        sql += " AND det_task_id=?"; args.append(det_task_id)
    if source_id:
        sql += " AND source_id=?"; args.append(source_id)
    sql += " ORDER BY enabled DESC, id DESC"
    with _connect() as conn:
        return [dict(r) for r in conn.execute(sql, args).fetchall()]


def update_filter_rule(rule_id, **fields) -> bool:
    allowed = {"name", "rule_type", "params_json", "scope", "det_task_id", "source_id", "enabled"}
    fields = {k: v for k, v in fields.items() if k in allowed}
    if not fields:
        return False
    fields["updated_at"] = _now()
    sets = ", ".join(f"{k}=?" for k in fields)
    with _write_lock, _connect() as conn:
        cur = conn.execute(f"UPDATE filter_rules SET {sets} WHERE id=?", list(fields.values()) + [rule_id])
        return cur.rowcount > 0


def delete_filter_rule(rule_id) -> bool:
    with _write_lock, _connect() as conn:
        cur = conn.execute("DELETE FROM filter_rules WHERE id=?", (rule_id,))
        return cur.rowcount > 0


def inc_filter_hit(rule_id) -> None:
    with _write_lock, _connect() as conn:
        conn.execute("UPDATE filter_rules SET hit_count=hit_count+1, updated_at=? WHERE id=?", (_now(), rule_id))


def filter_rule_stats() -> dict:
    with _connect() as conn:
        total = conn.execute("SELECT COUNT(*) FROM filter_rules").fetchone()[0]
        enabled = conn.execute("SELECT COUNT(*) FROM filter_rules WHERE enabled=1").fetchone()[0]
        hits = conn.execute("SELECT COALESCE(SUM(hit_count),0) FROM filter_rules").fetchone()[0]
        by_type = conn.execute(
            "SELECT rule_type, COUNT(*) AS count, COALESCE(SUM(hit_count),0) AS hits "
            "FROM filter_rules GROUP BY rule_type ORDER BY hits DESC"
        ).fetchall()
        return {"total": total, "enabled": enabled, "hits": hits, "by_type": [dict(r) for r in by_type]}


# ============ Phase 3: alerts ============
def insert_alert(source_id, event_id, det_task_id, severity, title, message, snapshot_path=None,
                 assigned_to=None) -> int:
    with _write_lock, _connect() as conn:
        cur = conn.execute(
            "INSERT INTO alerts(source_id,event_id,det_task_id,severity,status,title,message,"
            "snapshot_path,assigned_to,created_at) VALUES(?,?,?,?, 'active',?,?,?,?,?)",
            (source_id, event_id, det_task_id, severity, title, message, snapshot_path, assigned_to, _now()),
        )
        return cur.lastrowid


def list_alerts(status=None, severity=None, source_id=None, limit=200, offset=0) -> list:
    sql = (
        "SELECT a.*, e.event_type, e.timestamp_sec, e.confidence, "
        "s.name AS source_name, s.address AS source_address, s.lng AS source_lng, s.lat AS source_lat "
        "FROM alerts a "
        "LEFT JOIN traffic_events e ON e.id=a.event_id "
        "LEFT JOIN data_sources s ON s.id=a.source_id "
        "WHERE 1=1"
    )
    args = []
    if status:
        sql += " AND a.status=?"; args.append(status)
    if severity:
        sql += " AND a.severity=?"; args.append(severity)
    if source_id:
        sql += " AND a.source_id=?"; args.append(source_id)
    sql += " ORDER BY a.created_at DESC LIMIT ? OFFSET ?"
    args += [limit, offset]
    with _connect() as conn:
        return [dict(r) for r in conn.execute(sql, args).fetchall()]


def alert_counts() -> dict:
    with _connect() as conn:
        active = conn.execute("SELECT COUNT(*) FROM alerts WHERE status='active'").fetchone()[0]
        today = conn.execute(
            "SELECT COUNT(*) FROM alerts WHERE date(created_at) = date('now','localtime')"
        ).fetchone()[0]
        return {"active": active, "today": today}


def get_alert(alert_id) -> Optional[dict]:
    with _connect() as conn:
        row = conn.execute("SELECT * FROM alerts WHERE id=?", (alert_id,)).fetchone()
        return dict(row) if row else None


def set_alert_status(alert_id, status, actor, comment="") -> bool:
    col = "ack_at" if status == "acked" else "resolved_at"
    ccol = "ack_comment" if status == "acked" else "resolve_comment"
    allowed = "'active'" if status == "acked" else "'active','acked'"
    with _write_lock, _connect() as conn:
        cur = conn.execute(
            f"UPDATE alerts SET status=?, {col}=?, assigned_to=?, {ccol}=? WHERE id=? AND status IN ({allowed})",
            (status, _now(), actor, comment, alert_id),
        )
        return cur.rowcount > 0


# ============ Phase 3: dashboard 聚合 ============
def dashboard_stats() -> dict:
    with _connect() as conn:
        n_sources = conn.execute("SELECT COUNT(*) FROM data_sources WHERE COALESCE(archived,0)=0").fetchone()[0]
        n_online = conn.execute("SELECT COUNT(*) FROM data_sources WHERE COALESCE(archived,0)=0 AND online=1").fetchone()[0]
        n_streams = conn.execute("SELECT COUNT(*) FROM data_sources WHERE COALESCE(archived,0)=0 AND kind<>'file'").fetchone()[0]
        n_streams_online = conn.execute("SELECT COUNT(*) FROM data_sources WHERE COALESCE(archived,0)=0 AND kind<>'file' AND online=1").fetchone()[0]
        n_files = conn.execute("SELECT COUNT(*) FROM data_sources WHERE COALESCE(archived,0)=0 AND kind='file'").fetchone()[0]
        n_tasks = conn.execute("SELECT COUNT(*) FROM detection_tasks WHERE status='enabled'").fetchone()[0]
        n_events_today = conn.execute(
            "SELECT COUNT(*) FROM traffic_events WHERE date(created_at) = date('now','localtime') AND event_type<>'Normal'"
        ).fetchone()[0]
        n_pending_review = conn.execute(
            "SELECT COUNT(*) FROM traffic_events WHERE review_status='pending' AND event_type<>'Normal'"
        ).fetchone()[0]
        ac = alert_counts()
        # 各源事件 TOP
        top = conn.execute(
            "SELECT s.id, s.name, s.kind, s.lat, s.lng, s.online, "
            "(SELECT COUNT(*) FROM traffic_events e WHERE e.source_id=s.id AND e.event_type<>'Normal') AS events, "
            "(SELECT COUNT(*) FROM alerts a WHERE a.source_id=s.id AND a.status='active') AS active_alerts, "
            "(SELECT MAX(created_at) FROM traffic_events e WHERE e.source_id=s.id) AS last_event_at "
            "FROM data_sources s WHERE COALESCE(s.archived,0)=0 ORDER BY events DESC LIMIT 50"
        ).fetchall()
        recent_alerts = conn.execute(
            "SELECT id, severity, title, source_id, status, created_at FROM alerts ORDER BY created_at DESC LIMIT 10"
        ).fetchall()
        levels = {row['severity']: row['count'] for row in conn.execute(
            "SELECT severity,COUNT(*) AS count FROM alerts WHERE status='active' GROUP BY severity").fetchall()}
        counts = {row['day']: row['count'] for row in conn.execute(
            "SELECT substr(created_at,1,10) AS day,COUNT(*) AS count FROM traffic_events "
            "WHERE date(created_at) BETWEEN date('now','localtime','-6 days') AND date('now','localtime') AND event_type NOT IN ('Normal','UNKNOWN') GROUP BY day").fetchall()}
        from datetime import timedelta
        days = [(datetime.now().date()-timedelta(days=offset)).isoformat() for offset in range(6,-1,-1)]
        return {
            "sources": n_sources, "online_sources": n_online, "tasks": n_tasks,
            "stream_sources": n_streams, "available_stream_sources": n_streams_online, "file_sources": n_files,
            "events_today": n_events_today, "pending_review": n_pending_review,
            "alerts_active": ac["active"], "alerts_today": ac["today"],
            "source_cards": [dict(r) for r in top],
            "recent_alerts": [dict(r) for r in recent_alerts],
            "alerts_by_level": {level:levels.get(level,0) for level in ('L1','L2','L3')},
            "daily_events": [{'day':day,'count':counts.get(day,0)} for day in days],
        }
