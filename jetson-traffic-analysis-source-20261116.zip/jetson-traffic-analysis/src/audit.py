"""操作审计：写 audit_logs。"""
import logging
from typing import Optional

import db

log = logging.getLogger("traffic.audit")


def log_action(
    actor: Optional[str],
    action: str,
    target_type: Optional[str] = None,
    target_id=None,
    detail=None,
    ip: Optional[str] = None,
) -> None:
    try:
        db.insert_audit(actor, action, target_type, target_id, detail, ip)
    except Exception as e:
        log.warning("审计写入失败 action=%s: %s", action, e)
    log.info("AUDIT actor=%s action=%s target=%s/%s ip=%s", actor, action, target_type, target_id, ip)
