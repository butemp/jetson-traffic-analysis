import atexit
import base64
import binascii
from collections import deque
import io
import ipaddress
import json
import math
import os
import threading
import time
from urllib.parse import urlsplit
import warnings

import httpx


_MAX_MESSAGES = 32
_MAX_PARTS = 128
_MAX_TEXT_CHARS = 65536
_MAX_IMAGE_BYTES = 6 * 1024 * 1024
_MAX_IMAGE_PIXELS = 4 * 1024 * 1024
_MAX_TOTAL_PIXELS = 12 * 1024 * 1024
_MAX_OUTPUT_TOKENS = 4096
_MAX_RESPONSE_BYTES = 4 * 1024 * 1024
_MAX_SSE_BYTES = 8 * 1024 * 1024
_MAX_ERROR_BYTES = 64 * 1024
_IMAGE_PREFIX = "data:image/jpeg;base64,"


class InputError(ValueError):
    pass


def _check_messages(messages, max_images):
    if not isinstance(messages, list) or not 1 <= len(messages) <= _MAX_MESSAGES:
        raise InputError(f"messages 必须为 1–{_MAX_MESSAGES} 条消息")
    clean = []
    text_chars = image_count = part_count = 0
    for message in messages:
        if not isinstance(message, dict) or set(message) != {"role", "content"}:
            raise InputError("消息仅支持 role 和 content")
        role, content = message["role"], message["content"]
        if role not in ("system", "user", "assistant"):
            raise InputError("仅支持 system/user/assistant 消息")
        if isinstance(content, str):
            text_chars += len(content)
            clean.append({"role": role, "content": content})
        elif isinstance(content, list) and content:
            parts = []
            part_count += len(content)
            if part_count > _MAX_PARTS:
                raise InputError("消息内容块过多")
            for part in content:
                if not isinstance(part, dict):
                    raise InputError("消息内容块必须为对象")
                if part.get("type") == "text" and set(part) == {"type", "text"}:
                    if not isinstance(part["text"], str):
                        raise InputError("text 必须为字符串")
                    text_chars += len(part["text"])
                    parts.append({"type": "text", "text": part["text"]})
                elif part.get("type") == "image_url" and set(part) == {"type", "image_url"}:
                    image_count += 1
                    if role != "user" or image_count > max_images:
                        raise InputError(f"图片仅支持 user 消息，最多 {max_images} 张")
                    image_url = part["image_url"]
                    if not isinstance(image_url, dict) or set(image_url) - {"url", "detail"}:
                        raise InputError("image_url 必须包含本地 JPEG data URL")
                    url = image_url.get("url")
                    if not isinstance(url, str) or not url.startswith(_IMAGE_PREFIX):
                        raise InputError("只接受 data:image/jpeg;base64, 数据；不读取文件或外部 URL")
                    limit = len(_IMAGE_PREFIX) + 4 * ((_MAX_IMAGE_BYTES + 2) // 3)
                    if not len(_IMAGE_PREFIX) < len(url) <= limit:
                        raise InputError("JPEG 数据为空或超过 6 MiB")
                    if not url.isascii():
                        raise InputError("JPEG base64 数据必须为 ASCII")
                    parts.append({"type": "image_url", "image_url": {"url": url}})
                else:
                    raise InputError("仅支持 text 和 image_url 内容块")
            clean.append({"role": role, "content": parts})
        else:
            raise InputError("content 必须为文本或非空内容块列表")
        if text_chars > _MAX_TEXT_CHARS:
            raise InputError(f"输入文本超过 {_MAX_TEXT_CHARS} 字符")
    if clean[-1]["role"] != "user":
        raise InputError("最后一条消息必须来自 user")
    _check_images(clean)
    return clean


def _check_images(messages):
    from PIL import Image

    total_pixels = 0
    for message in messages:
        content = message["content"]
        if isinstance(content, str):
            continue
        for part in content:
            if part["type"] != "image_url":
                continue
            try:
                encoded = part["image_url"]["url"][len(_IMAGE_PREFIX):]
                data = base64.b64decode(encoded, validate=True)
                if len(data) > _MAX_IMAGE_BYTES:
                    raise InputError("JPEG 超过字节限制")
                with warnings.catch_warnings():
                    warnings.simplefilter("error", Image.DecompressionBombWarning)
                    with Image.open(io.BytesIO(data)) as source:
                        pixels = source.width * source.height
                        total_pixels += pixels
                        if source.format != "JPEG" or getattr(source, "n_frames", 1) != 1:
                            raise InputError("图片数据必须为单帧 JPEG")
                        if (pixels > _MAX_IMAGE_PIXELS or max(source.size) > 8192
                                or total_pixels > _MAX_TOTAL_PIXELS):
                            raise InputError("图片超过单图 4MP / 总计 12MP / 单边 8192 像素限制")
                        source.verify()
            except (ValueError, OSError, binascii.Error, Image.DecompressionBombWarning,
                    Image.DecompressionBombError) as exc:
                raise InputError(f"JPEG 解码失败: {exc}") from exc


def _check_base_url(value):
    if not isinstance(value, str) or not value.strip():
        raise ValueError("VLM_BASE_URL 不能为空")
    parsed = urlsplit(value.strip())
    if (parsed.scheme != "http" or parsed.username or parsed.password or parsed.query
            or parsed.fragment or parsed.path.rstrip("/") != "/v1"):
        raise ValueError("VLM_BASE_URL 必须是无凭证、无查询参数的 loopback HTTP /v1 地址")
    try:
        address = ipaddress.ip_address(parsed.hostname or "")
    except ValueError as exc:
        raise ValueError("VLM_BASE_URL 必须使用数字 loopback 地址") from exc
    if not address.is_loopback or parsed.port is None or not 1 <= parsed.port <= 65535:
        raise ValueError("VLM_BASE_URL 必须显式使用有效的 loopback 端口")
    return value.strip().rstrip("/")


def _read_http_error(response):
    raw = bytearray()
    try:
        for chunk in response.iter_bytes():
            remaining = _MAX_ERROR_BYTES - len(raw)
            if remaining <= 0:
                break
            raw.extend(chunk[:remaining])
    except httpx.HTTPError:
        pass
    text = raw.decode("utf-8", "replace")
    try:
        detail = json.loads(text)
        if isinstance(detail, dict):
            detail = detail.get("error", detail)
            if isinstance(detail, dict):
                detail = detail.get("message", detail)
        text = str(detail)
    except Exception:
        pass
    return text.replace("\n", " ")[:1000]


class VLMBusy(TimeoutError):
    pass


class VLMCancelled(InputError):
    pass


PRIORITIES = ("realtime", "interactive", "batch")


class _SlotGate:
    """Priority admission: realtime may use every slot, interactive leaves one for realtime,
    batch is capped and yields whenever a higher priority request is waiting."""

    def __init__(self, slots, batch_limit=2):
        self.slots = max(1, int(slots))
        self.batch_limit = max(1, int(batch_limit))
        self.cond = threading.Condition()
        self.active = dict.fromkeys(PRIORITIES, 0)
        self.waiting = dict.fromkeys(PRIORITIES, 0)

    def _limit(self, priority):
        if priority == "realtime":
            return self.slots
        return max(1, self.slots - 1)

    def _admissible(self, priority):
        total = sum(self.active.values())
        if total >= self._limit(priority):
            return False
        if priority == "interactive":
            return not self.waiting["realtime"] or total + 1 < self.slots
        if priority == "batch":
            if self.active["batch"] >= self.batch_limit:
                return False
            return not (self.waiting["realtime"] or self.waiting["interactive"])
        return True

    def acquire(self, priority, timeout, cancelled):
        deadline = time.monotonic() + timeout
        with self.cond:
            self.waiting[priority] += 1
            try:
                while not self._admissible(priority):
                    if cancelled():
                        raise VLMCancelled("请求已取消，未调用模型")
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        raise VLMBusy("VLM 忙，排队超时")
                    self.cond.wait(min(.2, remaining))
                if cancelled():
                    raise VLMCancelled("请求已取消，未调用模型")
                self.active[priority] += 1
            finally:
                self.waiting[priority] -= 1
                self.cond.notify_all()

    def release(self, priority):
        with self.cond:
            self.active[priority] -= 1
            self.cond.notify_all()

    def wake(self):
        with self.cond:
            self.cond.notify_all()

    def snapshot(self):
        with self.cond:
            return {"slots": self.slots, "active": dict(self.active), "waiting": dict(self.waiting)}


class VLLMModel:
    QUEUE_TIMEOUTS = {"realtime": float(os.getenv("VLM_REALTIME_QUEUE_SEC", "6")),
                      "interactive": float(os.getenv("VLM_INTERACTIVE_QUEUE_SEC", "30")),
                      "batch": float(os.getenv("VLM_BATCH_QUEUE_SEC", "600"))}

    def __init__(self, base_url, model, api_key="", timeout=60.0, queue_timeout=5.0,
                 max_images=6, max_inflight=1, batch_limit=2):
        for name, value in (("timeout", timeout), ("queue_timeout", queue_timeout)):
            if not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
                raise ValueError(f"{name} 必须为有限正数")
        if not isinstance(model, str) or not model.strip() or len(model) > 200:
            raise ValueError("VLM_MODEL 必须为非空模型名称")
        if type(max_images) is not int or not 1 <= max_images <= 6:
            raise ValueError("max_images 必须为 1–6")
        if type(max_inflight) is not int or not 1 <= max_inflight <= 16:
            raise ValueError("VLM_MAX_INFLIGHT 必须为 1–16")
        if not isinstance(api_key, str):
            raise ValueError("VLM_API_KEY 必须为字符串")
        if api_key and (not api_key.isascii() or any(not 33 <= ord(char) <= 126 for char in api_key)):
            raise ValueError("VLM_API_KEY 只能包含可见 ASCII 字符")
        self.base_url = _check_base_url(base_url)
        self.model = model.strip()
        self._api_key = api_key
        self.timeout = float(timeout)
        self.queue_timeout = float(queue_timeout)
        self.max_images = max_images
        self.max_inflight = max_inflight
        self._gate = _SlotGate(max_inflight, batch_limit)
        self._state_lock = threading.RLock()
        self._closed = False
        self._active = {}
        self._generation_requests = 0
        self._cancelled_owners = deque(maxlen=1024)
        self._state = "not_checked"
        self._error = ""
        headers = {"Accept": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        self._client = httpx.Client(
            base_url=self.base_url + "/",
            headers=headers,
            trust_env=False,
            follow_redirects=False,
            limits=httpx.Limits(max_connections=max_inflight + 4, max_keepalive_connections=max_inflight + 2),
            timeout=httpx.Timeout(self.timeout, connect=min(5.0, self.timeout)),
        )
        atexit.register(self.shutdown)

    def _remaining_timeout(self, deadline):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError("VLM 生成超时")
        return httpx.Timeout(remaining, connect=min(5.0, remaining), pool=min(5.0, remaining))

    def _was_cancelled(self, owner):
        return owner is not None and owner in self._cancelled_owners

    def _safe_error(self, exc):
        text = f"{type(exc).__name__}: {exc}"
        return text.replace(self._api_key, "***") if self._api_key else text

    def status(self) -> dict:
        with self._state_lock:
            if self._closed:
                return {
                    "backend": "vllm_http", "base_url": self.base_url, "model": self.model,
                    "reachable": False, "model_loaded": False, "models": [],
                    "state": "closed", "error": self._error,
                    "generation_requests": self._generation_requests,
                    "slots": self._gate.snapshot(),
                }
        transport_error = ""
        model_error = ""
        models = []
        context = None
        try:
            health_url = self.base_url.removesuffix("/v1") + "/health"
            health = self._client.get(health_url, timeout=httpx.Timeout(3.0, connect=1.0))
            health.raise_for_status()
            response = self._client.get("models", timeout=httpx.Timeout(3.0, connect=1.0))
            response.raise_for_status()
            data = response.json()
            if not isinstance(data, dict) or not isinstance(data.get("data"), list):
                raise RuntimeError("vLLM /models 返回非法 JSON")
            for item in data["data"]:
                if isinstance(item, dict) and isinstance(item.get("id"), str):
                    models.append(item["id"])
                    if item["id"] == self.model and isinstance(item.get("max_model_len"), int):
                        context = item["max_model_len"]
            if self.model not in models:
                model_error = f"vLLM 未提供配置的模型: {self.model}"
        except Exception as exc:
            transport_error = self._safe_error(exc)
        error = transport_error or model_error
        with self._state_lock:
            if not self._closed and not self._active:
                self._state = "error" if error else "ready"
                self._error = error
            return {
                "backend": "vllm_http", "base_url": self.base_url, "model": self.model,
                "reachable": not transport_error,
                "model_loaded": not transport_error and self.model in models,
                "models": models, "max_model_len": context,
                "state": "generating" if self._active else self._state, "error": error,
                "generation_requests": self._generation_requests,
                "slots": self._gate.snapshot(),
            }

    def generate(self, messages, max_tokens, temperature=0, owner=None, priority="interactive", on_delta=None, response_schema=None) -> str:
        if type(max_tokens) is not int or not 1 <= max_tokens <= _MAX_OUTPUT_TOKENS:
            raise InputError(f"max_tokens 必须为 1–{_MAX_OUTPUT_TOKENS}")
        if temperature != 0:
            raise InputError("VLM 仅支持 temperature=0 的确定性生成")
        if priority not in PRIORITIES:
            raise ValueError(f"未知 VLM 优先级: {priority}")
        messages = _check_messages(messages, self.max_images)
        if self._closed:
            raise RuntimeError("VLM 客户端已关闭")
        queue_timeout = self.QUEUE_TIMEOUTS[priority]
        if priority == "interactive":
            queue_timeout = max(queue_timeout, self.queue_timeout)
        self._gate.acquire(priority, queue_timeout, lambda: self._closed or self._was_cancelled(owner))
        token = object()
        response = None
        try:
            deadline = time.monotonic() + self.timeout
            with self._state_lock:
                if self._closed:
                    raise RuntimeError("VLM 客户端已关闭")
                if self._was_cancelled(owner):
                    raise VLMCancelled("事件已经停止，不再调用模型")
                self._active[token] = {"owner": owner, "response": None}
                self._generation_requests += 1
                self._error = ""
            payload = {
                "model": self.model,
                "messages": messages,
                "max_tokens": max_tokens,
                "temperature": 0,
                "seed": 0,
                "n": 1,
                "stream": True,
                "chat_template_kwargs": {"enable_thinking": False},
            }
            if response_schema is not None:
                if not isinstance(response_schema, dict):raise InputError("response_schema 必须为对象")
                payload["response_format"] = {"type":"json_schema","json_schema":{"name":"traffic_evidence","strict":True,"schema":response_schema}}
            chunks = []
            output_size = raw_size = 0
            finish_reason = None
            event_lines = []

            def process_event():
                nonlocal output_size, finish_reason
                if not event_lines:
                    return False
                data = "\n".join(event_lines)
                event_lines.clear()
                if data == "[DONE]":
                    return True
                try:
                    event = json.loads(data)
                except json.JSONDecodeError as exc:
                    raise RuntimeError("vLLM SSE 返回非法 JSON") from exc
                if isinstance(event, dict) and event.get("error"):
                    raise RuntimeError(f"vLLM 返回错误: {str(event['error'])[:1000]}")
                choices = event.get("choices") if isinstance(event, dict) else None
                if not isinstance(choices, list):
                    return False
                for choice in choices:
                    if not isinstance(choice, dict):
                        continue
                    content = choice.get("delta", {}).get("content")
                    if isinstance(content, str) and content:
                        output_size += len(content.encode("utf-8"))
                        if output_size > _MAX_RESPONSE_BYTES:
                            raise RuntimeError("vLLM 文本响应超过大小限制")
                        chunks.append(content)
                        if on_delta is not None:
                            on_delta(content)
                    if choice.get("finish_reason") is not None:
                        finish_reason = choice["finish_reason"]
                return False

            with self._client.stream(
                "POST", "chat/completions", json=payload,
                timeout=self._remaining_timeout(deadline),
            ) as response:
                with self._state_lock:
                    self._active[token]["response"] = response
                    cancelled = self._was_cancelled(owner)
                if cancelled:
                    raise VLMCancelled("事件已经停止，模型请求已取消")
                if response.status_code >= 400:
                    message = _read_http_error(response)
                    if response.status_code in (400, 413, 422):
                        raise InputError(f"vLLM 拒绝输入: {message}")
                    raise RuntimeError(f"vLLM HTTP {response.status_code}: {message}")
                done = False
                for line in response.iter_lines():
                    raw_size += len(line.encode("utf-8")) + 1
                    if raw_size > _MAX_SSE_BYTES:
                        raise RuntimeError("vLLM SSE 响应超过大小限制")
                    if time.monotonic() >= deadline:
                        raise TimeoutError("VLM 生成超时")
                    if self._closed:
                        raise RuntimeError("VLM 客户端已关闭")
                    if self._was_cancelled(owner):
                        raise VLMCancelled("事件已经停止，模型请求已取消")
                    if line == "":
                        if process_event():
                            done = True
                            break
                    elif line.startswith("data:"):
                        value = line[5:]
                        event_lines.append(value[1:] if value.startswith(" ") else value)
                if event_lines and not done:
                    process_event()
            if self._was_cancelled(owner):
                raise VLMCancelled("事件已经停止，模型请求已取消")
            text = "".join(chunks).strip()
            if not text:
                raise RuntimeError("vLLM 未返回文本")
            if finish_reason not in ("stop", "length"):
                raise RuntimeError(f"vLLM 非正常结束: {finish_reason}")
            with self._state_lock:
                self._state = "ready"
            return text
        except InputError:
            raise
        except (httpx.TimeoutException, TimeoutError) as exc:
            with self._state_lock:
                if not self._closed:
                    self._state = "error"
                    self._error = self._safe_error(exc)
            raise TimeoutError("VLM 生成超时") from exc
        except BaseException as exc:
            if self._was_cancelled(owner):
                raise VLMCancelled("事件已经停止，模型请求已取消") from exc
            with self._state_lock:
                if not self._closed:
                    self._state = "error"
                    self._error = self._safe_error(exc)
            raise
        finally:
            with self._state_lock:
                self._active.pop(token, None)
            self._gate.release(priority)

    def decide(self, messages, choices=("A", "B"), owner=None, priority="realtime") -> dict:
        """Jev-style typed decision: one generated token, normalized probability over caller-supplied choices."""
        if (not isinstance(choices, (tuple, list)) or len(choices) < 2
                or any(not isinstance(c, str) or not c or len(c) > 8 for c in choices)):
            raise InputError("choices 必须是至少两个短字符串")
        messages = _check_messages(messages, self.max_images)
        if priority not in PRIORITIES:
            raise ValueError(f"未知 VLM 优先级: {priority}")
        queue_timeout = self.QUEUE_TIMEOUTS[priority]
        if priority == "interactive":
            queue_timeout = max(queue_timeout, self.queue_timeout)
        self._gate.acquire(priority, queue_timeout, lambda: self._closed or self._was_cancelled(owner))
        token, response = object(), None
        try:
            deadline = time.monotonic() + self.timeout
            with self._state_lock:
                if self._closed:
                    raise RuntimeError("VLM 客户端已关闭")
                if self._was_cancelled(owner):
                    raise VLMCancelled("事件已经停止，不再调用模型")
                self._active[token] = {"owner": owner, "response": None}
                self._generation_requests += 1
            payload = {"model": self.model, "messages": messages, "max_tokens": 1, "temperature": 0,
                       "seed": 0, "n": 1, "stream": False, "logprobs": True,
                       "top_logprobs": max(10, len(choices) * 2),
                       "chat_template_kwargs": {"enable_thinking": False}}
            response = self._client.post("chat/completions", json=payload, timeout=self._remaining_timeout(deadline))
            with self._state_lock:
                self._active[token]["response"] = response
            if self._was_cancelled(owner):
                raise VLMCancelled("事件已经停止，模型请求已取消")
            if response.status_code >= 400:
                message = _read_http_error(response)
                if response.status_code in (400, 413, 422):
                    raise InputError(f"vLLM 拒绝输入: {message}")
                raise RuntimeError(f"vLLM HTTP {response.status_code}: {message}")
            data = response.json()
            rows = data.get("choices", [{}])[0].get("logprobs", {}).get("content", [])
            if not rows or not isinstance(rows[0].get("top_logprobs"), list):
                raise RuntimeError("vLLM 未返回候选概率")
            raw = {}
            for item in rows[0]["top_logprobs"]:
                candidate = str(item.get("token", "")).strip()
                if candidate in choices:
                    raw[candidate] = max(raw.get(candidate, -math.inf), float(item["logprob"]))
            if len(raw) != len(choices):
                raise RuntimeError("vLLM top_logprobs 未覆盖全部候选")
            maximum = max(raw.values())
            weights = {choice: math.exp(raw[choice] - maximum) for choice in choices}
            total = sum(weights.values())
            probabilities = {choice: weights[choice] / total for choice in choices}
            selected = max(choices, key=probabilities.get)
            return {"choice": selected, "probabilities": probabilities,
                    "token": data.get("choices", [{}])[0].get("message", {}).get("content", "").strip(),
                    "usage": data.get("usage", {})}
        except (httpx.TimeoutException, TimeoutError) as exc:
            raise TimeoutError("VLM 判定超时") from exc
        except BaseException as exc:
            if self._was_cancelled(owner):
                raise VLMCancelled("事件已经停止，模型请求已取消") from exc
            raise
        finally:
            with self._state_lock:
                self._active.pop(token, None)
            self._gate.release(priority)

    def cancel(self, owner):
        if owner is None:
            return
        with self._state_lock:
            self._cancelled_owners.append(owner)
            responses = [item["response"] for item in self._active.values()
                         if item["owner"] == owner and item["response"] is not None]
        for response in responses:
            try:
                response.close()
            except Exception:
                pass
        self._gate.wake()

    def shutdown(self):
        with self._state_lock:
            if self._closed:
                return
            self._closed = True
            self._state = "closed"
            responses = [item["response"] for item in self._active.values() if item["response"] is not None]
        for response in responses:
            try:
                response.close()
            except Exception:
                pass
        self._gate.wake()
        self._client.close()
