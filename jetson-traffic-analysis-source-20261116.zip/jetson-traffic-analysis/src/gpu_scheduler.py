"""Process-wide GPU model hub shared by every stream session and script.

Each model is loaded and warmed once. Detectors serialize their own GPU section with a
per-model lock on a dedicated CUDA stream, so knife/people from different sessions
overlap. X3D clips from all sessions go through one worker thread that micro-batches
scene clips first and region clips for scenes that pass their session threshold.
"""
from concurrent.futures import Future, ThreadPoolExecutor
import atexit
import os
from pathlib import Path
import queue
import threading
import time

import numpy as np

ROOT = Path(__file__).resolve().parent


class ActionJob:
    __slots__ = ("frames", "regions", "threshold", "future", "submitted")

    def __init__(self, frames, regions, threshold):
        self.frames, self.regions, self.threshold = frames, regions, threshold
        self.future = Future()
        self.submitted = time.monotonic()


class ActionWorker:
    def __init__(self, classifier, max_batch=8, window_ms=2.):
        import torch
        self.classifier = classifier
        self.max_batch = max_batch
        self.window = window_ms / 1000.
        self.queue = queue.Queue()
        self.stream = torch.cuda.Stream(device="cuda:0")
        self.stats = {"jobs": 0, "batches": 0, "scene_clips": 0, "region_clips": 0, "busy_ms": 0.}
        self.thread = threading.Thread(target=self._run, name="x3d-worker", daemon=True)
        self.thread.start()

    def submit(self, frames, regions, threshold):
        job = ActionJob(frames, regions, threshold)
        self.queue.put(job)
        return job.future

    def _collect(self):
        job = self.queue.get()
        if job is None:
            return None
        jobs = [job]
        deadline = time.monotonic() + self.window
        while len(jobs) < self.max_batch:
            try:
                item = self.queue.get(timeout=max(0., deadline - time.monotonic()))
            except queue.Empty:
                break
            if item is None:
                self.queue.put(None)
                break
            jobs.append(item)
        return jobs

    def _run(self):
        import torch
        while True:
            jobs = self._collect()
            if jobs is None:
                return
            jobs = [job for job in jobs if job.future.set_running_or_notify_cancel()]
            if not jobs:
                continue
            tick = time.monotonic()
            try:
                with torch.cuda.stream(self.stream):
                    videos = [self.classifier.upload(job.frames) for job in jobs]
                    scenes = self.classifier.score_uploaded([(video, (0., 0., 1., 1.)) for video in videos],
                                                            batch_size=self.max_batch)
                    second = [(index, region) for index, (job, scene) in enumerate(zip(jobs, scenes))
                              if job.regions and scene >= job.threshold for region in job.regions]
                    probabilities = self.classifier.score_uploaded(
                        [(videos[index], region["box"]) for index, region in second],
                        batch_size=self.max_batch) if second else []
                    del videos
                per_job = [[] for _ in jobs]
                for (index, region), probability in zip(second, probabilities):
                    per_job[index].append((region, probability))
                elapsed = (time.monotonic() - tick) * 1000
                self.stats["jobs"] += len(jobs)
                self.stats["batches"] += 1
                self.stats["scene_clips"] += len(jobs)
                self.stats["region_clips"] += len(second)
                self.stats["busy_ms"] += elapsed
                for job, scene, scored in zip(jobs, scenes, per_job):
                    job.future.set_result({"scene": scene, "regions": scored, "batch": len(jobs),
                                           "queue_ms": (tick - job.submitted) * 1000, "compute_ms": elapsed})
            except Exception as error:
                for job in jobs:
                    if not job.future.done():
                        job.future.set_exception(error)

    def depth(self):
        return self.queue.qsize()

    def close(self):
        self.queue.put(None)
        self.thread.join(timeout=2)


class InferenceHub:
    def __init__(self):
        self._lock = threading.RLock()
        self._knives = {}
        self._people = None
        self._fight = None
        self._action = None
        self._warmed = set()
        self.pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="detect")
        self.verify_pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="knife-verify")

    @staticmethod
    def engine_dir():
        return Path(os.environ.get("TRAFFIC_TRT_ENGINE_DIR", "/data/engines"))

    def knife(self, kind, confidence=.3, tiled=True):
        from stream_models import RTDetrKnifeDetector, TensorRTYoloDetector, YoloDetector
        key = kind if kind == "trained-u8" else (kind, confidence, tiled)
        with self._lock:
            model = self._knives.get(key)
            if model is None:
                if kind == "trained-u8":
                    model = TensorRTYoloDetector(ROOT / "models/knife-yolov8n-u8/model.onnx",
                                                 self.engine_dir() / "knife-yolov8n-u8.plan",
                                                 confidence=confidence, tiled=tiled)
                elif kind == "trained":
                    model = YoloDetector(ROOT / "models/knife-yolov8n/model.onnx", confidence=confidence, tiled=tiled)
                elif kind == "yolo":
                    model = YoloDetector(confidence=confidence, tiled=tiled)
                elif kind == "rtdetr":
                    model = RTDetrKnifeDetector(confidence=confidence, tiled=tiled)
                else:
                    raise ValueError("Unknown knife model")
                if not hasattr(model, "lock"):
                    model.lock = threading.Lock()
                self._knives[key] = model
            return model

    def people(self):
        from stream_models import TensorRTYoloDetector
        with self._lock:
            if self._people is None:
                self._people = TensorRTYoloDetector(ROOT / "models/people-yolov8n.onnx",
                                                    self.engine_dir() / "people-yolov8n.plan",
                                                    target_label="person", confidence=.3)
            return self._people

    def fight(self):
        from stream_models import FightClassifier
        with self._lock:
            if self._fight is None:
                self._fight = FightClassifier(batch_size=8)
                self._action = ActionWorker(self._fight, max_batch=int(os.environ.get("X3D_BATCH", "8")),
                                            window_ms=float(os.environ.get("BATCH_WINDOW_MS", "2")))
            return self._fight

    def action(self):
        self.fight()
        return self._action

    def warm(self, name, model):
        with self._lock:
            if name in self._warmed:
                return 0.
            tick = time.monotonic()
            image = np.zeros((1080, 1920, 3), dtype=np.uint8)
            if name == "fight":
                clip = [np.zeros((224, 224, 3), dtype=np.uint8) for _ in range(16)]
                video = model.upload(clip)
                for count in (1, 2, 3, 4, 5, 8):
                    model.score_uploaded([(video, (0., 0., 1., 1.))] * count)
            else:
                model.detect(image)
            self._warmed.add(name)
            return time.monotonic() - tick

    def close(self):
        with self._lock:
            action, self._action = self._action, None
        if action is not None:
            action.close()
        self.pool.shutdown(wait=True, cancel_futures=True)
        self.verify_pool.shutdown(wait=True, cancel_futures=True)

    def stats(self):
        with self._lock:
            action = self._action
        if action is None:
            return {"x3d_queue": 0}
        data = dict(action.stats)
        data["x3d_queue"] = action.depth()
        data["x3d_mean_batch"] = data["jobs"] / data["batches"] if data["batches"] else 0.
        return data


_hub = None
_hub_lock = threading.Lock()


def hub():
    global _hub
    with _hub_lock:
        if _hub is None:
            _hub = InferenceHub()
            atexit.register(_hub.close)
        return _hub
