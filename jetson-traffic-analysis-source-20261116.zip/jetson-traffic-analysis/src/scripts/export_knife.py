#!/usr/bin/env python3
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import sys

ROOT=Path(__file__).resolve().parent.parent


def main():
    parser=argparse.ArgumentParser(description='从已记录的训练结果导出FP16动态批量刀具模型')
    parser.add_argument('--run',type=Path,required=True)
    parser.add_argument('--output',type=Path,default=ROOT/'models/knife-yolov8n')
    parser.add_argument('--gpu-preprocess',action='store_true')
    args=parser.parse_args()
    run_path=args.run.resolve(strict=True)
    training=json.loads((run_path/'run.json').read_text())
    if training['status']!='completed':
        parser.error('训练尚未完成')
    weights=Path(training['best']).resolve(strict=True)
    if hashlib.sha256(weights.read_bytes()).hexdigest()!=training['best_sha256']:
        parser.error('训练检查点SHA256不匹配')
    output=args.output.resolve()
    output.mkdir(parents=True,exist_ok=True)
    if any(output.iterdir()):
        parser.error('导出目录必须为空，以保留旧模型')
    os.environ.update(YOLO_CONFIG_DIR=str(output),YOLO_OFFLINE='true',YOLO_AUTOINSTALL='false')
    import torch
    from ultralytics import YOLO
    from ultralytics.utils import callbacks
    import onnx

    callbacks.add_integration_callbacks=lambda _: None
    def offline(event,arguments):
        if event=='socket.connect' and arguments[0].family in (socket.AF_INET,socket.AF_INET6):
            raise RuntimeError('模型导出不允许联网')
    sys.addaudithook(offline)
    copied=output/'model.pt'
    shutil.copyfile(weights,copied)
    model=YOLO(str(copied))
    if model.names!={0:'knife'}:
        raise RuntimeError('训练模型类别不是单类knife')
    exported=Path(model.export(format='onnx',imgsz=640,half=True,dynamic=True,batch=8,
                               opset=17,simplify=False,device=0,nms=False))
    graph=onnx.load(str(exported))
    if args.gpu_preprocess:
        import numpy as np
        original=graph.graph.input[0].name
        graph.graph.input[0].name='frames'
        graph.graph.input[0].type.tensor_type.elem_type=onnx.TensorProto.UINT8
        graph.graph.initializer.append(onnx.numpy_helper.from_array(np.array(255.,dtype=np.float16),name='pixel_scale'))
        graph.graph.node.insert(0,onnx.helper.make_node('Div',['pixels_fp16','pixel_scale'],[original],name='NormalizePixels'))
        graph.graph.node.insert(0,onnx.helper.make_node('Cast',['frames'],['pixels_fp16'],to=onnx.TensorProto.FLOAT16,name='CastPixels'))
        meta=graph.metadata_props.add();meta.key='input_format';meta.value='RGB_NCHW_UINT8'
        onnx.save(graph,str(exported))
    onnx.checker.check_model(graph)
    def tensor_info(value):
        return {'name':value.name,'dtype':value.type.tensor_type.elem_type,
                'shape':[d.dim_value if d.dim_value else d.dim_param for d in value.type.tensor_type.shape.dim]}
    digest=hashlib.sha256(exported.read_bytes()).hexdigest()
    entry={'path':str(exported.relative_to(ROOT/'models')),'kind':'trained_knife',
           'sha256':digest,'expected_sha256':digest,'classes':{'0':'knife'},
           'precision':'float16','input_dtype':'uint8' if args.gpu_preprocess else 'float16',
           'max_batch':8,'image_size':640,
           'input':tensor_info(graph.graph.input[0]),'output':tensor_info(graph.graph.output[0]),
           'training_run':str(run_path),'training_checkpoint_sha256':training['best_sha256'],
           'training_data_yaml_sha256':training['data_yaml_sha256'],'validation_metrics':training['metrics'],
           'source':'Local source-group fine-tuning of official Ultralytics YOLOv8n',
           'license':'AGPL-3.0 model/code; training data provenance retained separately',
           'runtime_validation':'pending real video execution; dataset metrics are not field accuracy'}
    (output/'export.json').write_text(json.dumps(entry,ensure_ascii=False,indent=2))
    manifest_path=ROOT/'models/manifest.json'
    manifest=json.loads(manifest_path.read_text())
    if any(record.get('path')==entry['path'] for record in manifest['models']):
        raise RuntimeError('Manifest entry already exists; do not overwrite an existing artifact')
    manifest['models'].append(entry)
    manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
    print(json.dumps(entry,ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
