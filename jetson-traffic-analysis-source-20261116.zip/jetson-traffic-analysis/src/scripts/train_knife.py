#!/usr/bin/env python3
import argparse
import hashlib
import json
import os
from pathlib import Path
import socket
import sys
import time

BASE_SHA256 = '31e20dde3def09e2cf938c7be6fe23d9150bbbe503982af13345706515f2ef95'
ROOT = Path(__file__).resolve().parent.parent


def main():
    parser = argparse.ArgumentParser(description='离线微调轻量刀具检测器；不联网、不改变核心模型环境')
    parser.add_argument('--data',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--weights',type=Path,default=ROOT/'models/yolov8n-base/yolov8n.pt')
    parser.add_argument('--epochs',type=int,default=45)
    parser.add_argument('--batch',type=int,default=32)
    parser.add_argument('--imgsz',type=int,default=640)
    parser.add_argument('--workers',type=int,default=4)
    args=parser.parse_args()
    data=args.data.resolve(strict=True)
    dest=args.output.resolve()
    if dest.exists() and any(dest.iterdir()):
        parser.error('输出目录必须不存在或为空，保留之前的训练结果')
    if not 1<=args.epochs<=200 or args.batch<1 or args.imgsz%32 or not 0<=args.workers<=8:
        parser.error('训练参数超出允许范围')
    weights=args.weights.resolve(strict=True)
    if hashlib.sha256(weights.read_bytes()).hexdigest()!=BASE_SHA256:
        parser.error('基础权重必须是记录的官方YOLOv8n检查点')
    dest.mkdir(parents=True,exist_ok=True)
    os.environ.update(YOLO_CONFIG_DIR=str(dest),YOLO_OFFLINE='true',YOLO_AUTOINSTALL='false',WANDB_DISABLED='true')
    import torch
    from ultralytics.nn.modules import Conv,Bottleneck,Detect,Concat,C2f,SPPF,DFL
    from ultralytics.nn.tasks import DetectionModel
    from ultralytics.models.yolo.detect import DetectionTrainer
    from ultralytics.utils import callbacks
    from ultralytics.data import utils as data_utils
    from ultralytics.engine import trainer as trainer_module
    import ultralytics

    if not torch.cuda.is_available():
        raise RuntimeError('训练需要当前分配的GPU')
    torch.set_num_threads(4)
    allowed={f'ultralytics.nn.modules.{cls.__name__}':cls for cls in (Conv,Bottleneck,Detect,Concat,C2f,SPPF,DFL)}
    allowed['ultralytics.nn.tasks.DetectionModel']=DetectionModel
    for cls in (torch.nn.Conv2d,torch.nn.Sequential,torch.nn.SiLU,torch.nn.ModuleList,
                torch.nn.Upsample,torch.nn.BatchNorm2d,torch.nn.MaxPool2d):
        allowed[cls.__module__+'.'+cls.__name__]=cls
    required=set(torch.serialization.get_unsafe_globals_in_checkpoint(weights))
    if not required.issubset(allowed):
        raise RuntimeError('基础模型含未审阅的序列化类型：'+str(sorted(required-set(allowed))))
    with torch.serialization.safe_globals([(allowed[name],name) for name in required]):
        checkpoint=torch.load(weights,map_location='cpu',weights_only=True)
    base_model=checkpoint.get('ema') or checkpoint['model']
    if not isinstance(base_model,DetectionModel):
        raise RuntimeError('基础检查点不是预期检测模型')

    # Third-party training integrations and implicit asset downloads are disabled for this process only.
    callbacks.add_integration_callbacks=lambda _: None
    data_utils.check_font=lambda *a,**kw: None
    check_dataset=trainer_module.check_det_dataset
    trainer_module.check_det_dataset=lambda source: check_dataset(source,autodownload=False)
    def offline(event,arguments):
        if event=='socket.connect' and arguments[0].family in (socket.AF_INET,socket.AF_INET6):
            raise RuntimeError('训练进程禁止联网；请先准备完整本地数据及资源')
    sys.addaudithook(offline)

    options=dict(model='yolov8n.yaml',data=str(data),epochs=args.epochs,batch=args.batch,imgsz=args.imgsz,
                 device=0,workers=args.workers,project=str(dest),name='fit',exist_ok=False,
                 optimizer='AdamW',lr0=.001,weight_decay=.0005,warmup_epochs=3,
                 patience=12,seed=1729,deterministic=True,amp=False,plots=False,save_json=False,
                 cache=False,mosaic=.5,close_mosaic=8,mixup=0.,degrees=5.,scale=.6,verbose=True)
    run={'status':'running','started':time.time(),'base_sha256':BASE_SHA256,'base_path':str(weights),
         'data':str(data),'data_yaml_sha256':hashlib.sha256(data.read_bytes()).hexdigest(),
         'torch':torch.__version__,'ultralytics':ultralytics.__version__,
         'gpu':torch.cuda.get_device_name(0),'options':options,
         'base_checkpoint_load':'weights_only with reviewed neural-network classes',
         'network':'prohibited by process-local audit hook'}
    (dest/'run.json').write_text(json.dumps(run,ensure_ascii=False,indent=2))
    try:
        from contextlib import redirect_stdout,redirect_stderr
        console=sys.stdout
        def epoch_report(trainer):
            message={'epoch':trainer.epoch+1,'epochs':args.epochs,
                     'metrics':{str(key):float(value) for key,value in trainer.metrics.items()},
                     'gpu_allocated_gib':round(torch.cuda.max_memory_allocated()/1024**3,3)}
            print(json.dumps(message,ensure_ascii=False),file=console,flush=True)
        with (dest/'train.log').open('w') as log, redirect_stdout(log), redirect_stderr(log):
            trainer=DetectionTrainer(overrides=options)
            trainer.model=trainer.get_model(cfg=base_model.yaml,weights=base_model,verbose=False)
            trainer.add_callback('on_fit_epoch_end',epoch_report)
            trainer.train()
        run.update(status='completed',finished=time.time(),best=str(trainer.best),last=str(trainer.last),
                   metrics={str(key):float(value) for key,value in trainer.metrics.items()})
        if trainer.best.is_file():
            run['best_sha256']=hashlib.sha256(trainer.best.read_bytes()).hexdigest()
        print(json.dumps(run,ensure_ascii=False),flush=True)
    except Exception as error:
        run.update(status='failed',finished=time.time(),error=str(error))
        raise
    finally:
        (dest/'run.json').write_text(json.dumps(run,ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
