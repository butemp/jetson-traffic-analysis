#!/usr/bin/env python3
import argparse
import json
import os
from pathlib import Path
import sys
import threading
import time

ROOT = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(ROOT/'.vendor'), str(ROOT)]


def main():
    parser = argparse.ArgumentParser(description='逐帧读取当前视频，先保存红框结果，再异步本地描述')
    parser.add_argument('video')
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--scenarios', nargs='+', choices=['knife','fight'], default=['knife','fight'])
    parser.add_argument('--knife-confidence', type=float, default=.3)
    parser.add_argument('--knife-model', choices=['yolo','rtdetr','trained','trained-u8'], default='yolo')
    parser.add_argument('--fight-threshold', type=float, default=.65)
    parser.add_argument('--no-tiles', action='store_true')
    parser.add_argument('--describe', action='store_true')
    parser.add_argument('--as-fast-as-possible', action='store_true')
    parser.add_argument('--max-frames', type=int, default=0)
    parser.add_argument('--ort-profile', action='store_true')
    parser.add_argument('--sync-action', action='store_true', help='在当前帧内同步等待X3D结果（回归对照）')
    args = parser.parse_args()
    dest = args.output.resolve()
    if dest.exists() and any(dest.iterdir()):
        parser.error('输出目录必须不存在或为空')
    dest.mkdir(parents=True,exist_ok=True)
    if args.ort_profile:
        os.environ['TRAFFIC_ORT_PROFILE_DIR']=str(dest)
    os.environ.setdefault('TRAFFIC_DATA_DIR',str(dest/'workspace'))
    os.environ.setdefault('HF_HUB_OFFLINE','1')
    os.environ.setdefault('TRANSFORMERS_OFFLINE','1')
    import cv2
    from streaming import StreamModels, StreamDetector, EventDescriber, render_frame, description_frames
    import vlm

    trace = (dest/'frames.jsonl').open('w')
    description_log = (dest/'descriptions.jsonl').open('w')
    descriptions = []
    write_lock = threading.Lock()
    def describe(result):
        with write_lock:
            description_log.write(json.dumps(result,ensure_ascii=False)+'\n')
            description_log.flush()
            descriptions.append(result)
        print(json.dumps({'description_event':result['id'],'state':result['description_status']},ensure_ascii=False),flush=True)
    describer = EventDescriber(describe,enabled=args.describe)
    capture = writer = None
    summary = {'status':'starting','source':args.video,'scenarios':args.scenarios,
               'delivery':'causal_frame_stream','description_enabled':args.describe}
    costs=[]
    boxes_count=0
    first_red=[]
    started=time.monotonic()
    try:
        models = StreamModels(args.scenarios, args.knife_confidence, tiled=not args.no_tiles, knife_model=args.knife_model)
        models.warmup()
        detector = StreamDetector(models,fight_threshold=args.fight_threshold,async_action=not args.sync_action)
        summary['models']=models.info
        summary['warmup_seconds']=models.warmup_seconds
        summary['model_load_seconds']=time.monotonic()-started
        capture=cv2.VideoCapture(args.video)
        if not capture.isOpened():raise RuntimeError('无法打开视频')
        fps=capture.get(cv2.CAP_PROP_FPS)
        if not fps or fps<=0:raise RuntimeError('文件输入需要有效帧率')
        processing_started=time.monotonic()
        seq=0
        while not args.max_frames or seq<args.max_frames:
            ok,frame=capture.read()
            if not ok:break
            pts=float(capture.get(cv2.CAP_PROP_POS_MSEC))/1000.
            if seq and pts<=detector.last_pts:raise RuntimeError('视频时间戳未递增，停止而非编造时间')
            deadline=processing_started+pts
            if not args.as_fast_as_possible:
                delay=deadline-time.monotonic()
                if delay>0:time.sleep(delay)
            received_at=time.monotonic() if args.as_fast_as_possible else deadline
            result=detector.step(frame,seq,pts,received_at=received_at)
            evidence=result.pop('_event_evidence',{})
            annotated=render_frame(frame,result)
            if writer is None:
                height,width=annotated.shape[:2]
                writer=cv2.VideoWriter(str(dest/'annotated.avi'),cv2.VideoWriter_fourcc(*'MJPG'),fps,(width,height))
                if not writer.isOpened():raise RuntimeError('无法创建流式回放视频')
            writer.write(annotated)
            result['published_at']=time.monotonic()
            trace.write(json.dumps(result,ensure_ascii=False)+'\n')
            trace.flush()
            costs.append(result['metrics']['processing_ms'])
            boxes_count+=bool(result['boxes'])
            if result['boxes'] and not first_red:first_red.append(pts)
            if result['new_events']:
                for event in result['new_events']:
                    source=evidence.get(event['id'])
                    event_frame=source['frame'] if source else frame
                    event_pts=source['pts'] if source else pts
                    event_seq=source['seq'] if source else seq
                    cv2.imwrite(str(dest/f'event-{event_seq:06d}.jpg'),render_frame(event_frame,{'boxes':event['boxes']}))
                    context=description_frames(detector.history,event_pts,event_frame,event['boxes'])
                    describer.submit(event,context,result['published_at'])
            if seq%30==0:
                print(json.dumps({'frame':seq,'pts':round(pts,3),'boxes':len(result['boxes']),
                                  'processing_ms':round(costs[-1],2),'scene_score':result['diagnostics']['scene_fight_score']}),flush=True)
            seq+=1
        processing_seconds=time.monotonic()-processing_started
        if args.ort_profile:
            summary['ort_profiles']=[item.session.end_profiling() for item in (models.knife,models.people) if item is not None and hasattr(item,'session')]
        if not seq:raise RuntimeError('输入视频没有可解码帧')
        if args.describe:
            deadline=time.monotonic()+vlm.config.VLM_TIMEOUT+5
            while describer.pending.unfinished_tasks and time.monotonic()<deadline:
                time.sleep(.1)
        ordered=sorted(costs)
        from gpu_scheduler import hub
        summary['scheduler']=hub().stats()
        summary.update(status='completed',frames=seq,first_red_pts=next((r for r in first_red),None),red_frames=boxes_count,processing_seconds=processing_seconds,
                       processed_fps=seq/processing_seconds,p50_ms=ordered[len(ordered)//2],
                       p95_ms=ordered[min(len(ordered)-1,int(len(ordered)*.95))],
                       descriptions_finished=sum(item['description_status']=='ready' for item in descriptions),
                       model_health=vlm.health_check() if args.describe else None)
        print(json.dumps({key:summary[key] for key in ('status','frames','red_frames','processed_fps','p95_ms')},ensure_ascii=False),flush=True)
    except Exception as error:
        summary.update(status='failed',error=str(error))
        raise
    finally:
        describer.close()
        if 'detector' in locals(): detector.close()
        vlm.shutdown()
        if capture is not None:capture.release()
        if writer is not None:writer.release()
        trace.close()
        description_log.close()
        (dest/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
