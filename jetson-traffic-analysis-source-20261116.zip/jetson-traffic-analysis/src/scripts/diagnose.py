#!/usr/bin/env python3
import argparse
import hashlib
import importlib.metadata
import json
import platform
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def main():
    parser = argparse.ArgumentParser(description="本机模型与Jetson运行环境自检；不调用模型生成")
    parser.add_argument("--source", help="可选：仅检查指定视频源能否解码一帧")
    args = parser.parse_args()
    import config
    import cv2
    import vlm

    device_model = Path("/proc/device-tree/model")
    l4t = Path("/etc/nv_tegra_release")
    result = {
        "host": platform.node(),
        "architecture": platform.machine(),
        "python": sys.version.split()[0],
        "device_model": device_model.read_text().rstrip("\0\n") if device_model.exists() else None,
        "l4t": l4t.read_text().strip() if l4t.exists() else None,
        "data_dir": str(config.DATA_DIR),
        "vlm": vlm.health_check(),
        "generation_requested": False,
        "packages": {},
        "video_backends": [line.strip() for line in cv2.getBuildInformation().splitlines()
                           if any(key in line for key in ("FFMPEG:", "GStreamer:", "NVIDIA CUDA:"))],
    }
    for package in (
        "torch", "torchvision", "transformers", "onnxruntime-gpu", "APScheduler",
        "pytorchvideo", "fvcore", "iopath", "tensorrt", "opencv-python",
        "opencv-python-headless",
    ):
        try:
            result["packages"][package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            result["packages"][package] = None
    try:
        import torch
        result["cuda"] = {"available": torch.cuda.is_available(), "version": torch.version.cuda,
                          "devices": [{"name": torch.cuda.get_device_name(i),
                                       "memory_bytes": torch.cuda.get_device_properties(i).total_memory}
                                      for i in range(torch.cuda.device_count())]}
    except ImportError as error:
        result["cuda"] = {"available": False, "error": str(error)}
    try:
        import onnxruntime as ort
        result["onnxruntime"] = {"version": ort.__version__,
                                 "providers": ort.get_available_providers(),
                                 "cuda_required": True}
    except ImportError as error:
        result["onnxruntime"] = {"providers": [], "cuda_required": True, "error": str(error)}

    model_path = config.BASE_DIR / "models" / "knife-yolov8n-u8" / "model.onnx"
    manifest = json.loads((config.BASE_DIR / "models" / "manifest.json").read_text())
    entry = next((item for item in manifest.get("models", [])
                  if item.get("path") == "knife-yolov8n-u8/model.onnx"), None)
    digest = hashlib.sha256(model_path.read_bytes()).hexdigest() if model_path.is_file() else None
    result["default_detector"] = {
        "name": "trained-u8", "path": str(model_path), "sha256": digest,
        "expected_sha256": entry.get("sha256") if isinstance(entry, dict) else None,
        "verified": bool(entry and digest == entry.get("sha256")),
        "session_created": False,
    }
    if args.source:
        import video
        capture = video.open_capture(args.source)
        try:
            ok, frame = capture.read()
            result["source"] = {"decoded": bool(ok and frame is not None),
                                "shape": list(frame.shape) if ok and frame is not None else None}
        finally:
            capture.release()
    result["jetson_measured"] = bool(result["device_model"] and "Orin" in result["device_model"])
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
