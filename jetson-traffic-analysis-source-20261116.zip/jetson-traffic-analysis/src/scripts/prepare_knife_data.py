#!/usr/bin/env python3
import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil


def source_group(stem):
    match=re.search(r'frame\d+',stem,re.I)
    prefix=stem[:match.start()] if match else re.sub(r'[\d_() -]+$','',stem)
    if re.fullmatch(r'[A-Z]{2}[bms]',prefix):
        return prefix[:2]
    if 'Krav' in prefix:
        return 'KravMaga'
    if '_z3v' in prefix:
        return 'capture_z3'
    if prefix.startswith('img'):
        return 'img'
    return prefix


def read_boxes(path):
    boxes=[]
    for line in path.read_text().splitlines():
        fields=line.split()
        if len(fields)!=5:
            raise ValueError('Invalid YOLO row: '+str(path))
        cls=int(fields[0])
        x,y,w,h=map(float,fields[1:])
        if not 0<=cls<6 or not all(math.isfinite(v) for v in (x,y,w,h)) or not (w>0 and h>0 and min(x-w/2,y-h/2)>=-1e-6 and max(x+w/2,y+h/2)<=1+1e-6):
            raise ValueError('Invalid YOLO box: '+str(path))
        if cls==2:
            boxes.append([x,y,w,h])
    return sorted(boxes)


def main():
    parser=argparse.ArgumentParser(description='校验并按源分组构建单类刀具训练数据，不沿用泄漏的原始拆分')
    parser.add_argument('--source',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--validation-groups',default='DefenseKnifeAttack,sharpenKnife,img,capture_z3')
    parser.add_argument('--extras',type=Path)
    args=parser.parse_args()
    source=args.source.resolve(strict=True)
    output=args.output.resolve()
    if output.exists() and any(output.iterdir()):
        parser.error('输出目录必须为空或不存在')
    record=json.loads((source/'download-record.json').read_text())
    if record['status']!='complete' or record['verified']!=record['total']:
        parser.error('先完成并校验全部下载，不能静默使用不完整样本集')
    validation=set(args.validation_groups.split(','))
    entries=[]
    duplicates=defaultdict(list)
    from PIL import Image
    for item in record['files']:
        relative=Path(item['local'])
        if relative.parts[0]!='images':
            continue
        image=source/'raw'/relative
        label=source/'raw'/'labels'/relative.relative_to('images').with_suffix('.txt')
        data=image.read_bytes()
        digest=hashlib.sha256(data).hexdigest()
        expected=item.get('lfs',{}).get('sha256')
        matches=digest==expected if expected else hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==item['blobId']
        if len(data)!=item['size'] or not matches:
            raise ValueError('Image hash mismatch: '+str(image))
        boxes=read_boxes(label)
        with Image.open(image) as pic:
            width,height=pic.size
            if pic.format!='JPEG' or width<1 or height<1:
                raise ValueError('Invalid source image: '+str(image))
        entry={'source':str(image),'original_split':relative.parts[1],'group':source_group(image.stem),
               'sha256':digest,'width':width,'height':height,'boxes':boxes}
        entries.append(entry)
        duplicates[digest].append(entry)
    parent={entry['group']:entry['group'] for entry in entries}
    def find(group):
        while parent[group]!=group:
            parent[group]=parent[parent[group]]
            group=parent[group]
        return group
    for copies in duplicates.values():
        for entry in copies[1:]:
            if entry['boxes']!=copies[0]['boxes']:
                raise ValueError('Exact duplicate image has conflicting labels: '+entry['source'])
            parent[find(entry['group'])]=find(copies[0]['group'])
    if not validation.issubset(parent):
        raise ValueError('Unknown validation groups: '+str(validation-set(parent)))
    val_components={find(group) for group in validation}
    selected=[]
    for digest,copies in duplicates.items():
        entry=copies[0]
        split='val' if find(entry['group']) in val_components else 'train'
        selected.append({**entry,'split':split,'source_groups':sorted({item['group'] for item in copies})})
    if args.extras:
        extra=json.loads(args.extras.read_text())
        if extra.get('review_status')!='reviewed':
            raise ValueError('Hard examples need explicit visual review before training')
        for item in extra['images']:
            image=Path(item['path']).resolve(strict=True)
            digest=hashlib.sha256(image.read_bytes()).hexdigest()
            if digest in duplicates:
                raise ValueError('Extra frame duplicates main data')
            with Image.open(image) as pic:
                width,height=pic.size
            selected.append({'source':str(image),'sha256':digest,'width':width,'height':height,
                             'group':item['group'],'source_groups':[item['group']],'split':'train','boxes':item['boxes'],
                             'annotation_source':item.get('annotation_source','manual development annotation')})
    counts=Counter((entry['split'],bool(entry['boxes'])) for entry in selected)
    if any(counts[(split,positive)]==0 for split in ('train','val') for positive in (True,False)):
        raise ValueError('Both splits require positive and negative images')
    train_groups={g for entry in selected if entry['split']=='train' for g in entry['source_groups']}
    val_groups={g for entry in selected if entry['split']=='val' for g in entry['source_groups']}
    if train_groups&val_groups:
        raise ValueError('Source group leakage detected')
    output.mkdir(parents=True,exist_ok=True)
    for kind in ('images','labels'):
        for split in ('train','val'):
            (output/kind/split).mkdir(parents=True,exist_ok=True)
    for entry in selected:
        name=entry['sha256'][:20]
        target=output/'images'/entry['split']/(name+'.jpg')
        try:
            os.link(entry['source'],target)
        except OSError:
            shutil.copyfile(entry['source'],target)
        text=''.join('0 '+' '.join(f'{value:.9f}' for value in box)+'\n' for box in entry['boxes'])
        (output/'labels'/entry['split']/(name+'.txt')).write_text(text)
        entry['prepared_image']=str(target)
    yaml='path: '+json.dumps(str(output))+'\ntrain: images/train\nval: images/val\nnames:\n  0: knife\n'
    (output/'dataset.yaml').write_text(yaml)
    audit={'status':'prepared','revision':record['revision'],'classes':{'0':'knife'},
           'mapping':'SOHAS class 2 to knife class 0; all other object classes become negatives',
           'counts':{split:{'positive':counts[(split,True)],'negative':counts[(split,False)]} for split in ('train','val')},
           'train_groups':sorted(train_groups),'validation_groups':sorted(val_groups),'group_overlap':[],
           'duplicate_images_removed':len(entries)-len(duplicates),'images':selected,
           'limits':'Filename/source-group development validation, not independent field accuracy. Generic photo provenance is incomplete; separate outdoor source holdouts are still required.'}
    (output/'dataset-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
    print(json.dumps({key:audit[key] for key in ('status','counts','train_groups','validation_groups','duplicate_images_removed')},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
