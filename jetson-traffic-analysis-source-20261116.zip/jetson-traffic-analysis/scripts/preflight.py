#!/usr/bin/env python3
import argparse,json,platform,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--allow-system-difference',action='store_true');args=p.parse_args()
root=Path(__file__).resolve().parent.parent
if platform.system()!='Linux' or platform.machine()!='aarch64':raise SystemExit('Deployment requires an ARM64 Linux Jetson. This source package may be edited on other systems.')
release=Path('/etc/nv_tegra_release')
text=release.read_text() if release.exists() else ''
if ('R36 (release), REVISION: 4.7' not in text) and not args.allow_system_difference:raise SystemExit('Source system is L4T R36.4.7. Target differs; validate driver/runtime compatibility first. --allow-system-difference only bypasses this check.')
values={}
for line in (root/'.env').read_text().splitlines():
    if line.strip() and not line.lstrip().startswith('#') and '=' in line:
        k,v=line.split('=',1);values[k.strip()]=v.strip().strip('"').strip("'")
image=values.get('TRAFFIC_IMAGE','qjw/traffic-vlm-jetson:20261023')
try:
    subprocess.run(['docker','compose','version'],check=True,stdout=subprocess.DEVNULL)
    info=json.loads(subprocess.check_output(['docker','info','--format','{{json .Runtimes}}'],text=True))
    assert 'nvidia' in info,'NVIDIA container runtime is not installed'
    found=json.loads(subprocess.check_output(['docker','image','inspect',image],text=True))[0]
except Exception as e:raise SystemExit('Docker, Compose, NVIDIA runtime or the offline image is unavailable. Check prerequisites and sudo permissions: '+str(e))
assert found['Architecture']=='arm64','Wrong image architecture'
reference=json.loads((root/'environment/source-system.json').read_text())
if image==reference['image_tag'] and found['Id']!=reference['image_id']:raise SystemExit('Image tag matches but content ID differs from the exported reference.')
print('Image:',image,found['Id'])
print('System:',text.splitlines()[0] if text else 'unidentified')
print('Engine compatibility is checked at startup; mismatched engines are rebuilt on the target.')
