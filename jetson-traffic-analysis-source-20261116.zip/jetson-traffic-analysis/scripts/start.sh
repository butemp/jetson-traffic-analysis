#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
bash scripts/init-data.sh
python3 scripts/preflight.py "$@"
docker compose up -d --pull never
printf 'Use docker compose ps and docker compose logs -f to watch first-start initialization.\n'
