#!/usr/bin/env bash
# Run on the NEW Jetson after copying the archive and its checksum.
set -euo pipefail
archive=${1:?Usage: sudo bash scripts/import-runtime.sh /media/USER/DISK/traffic-runtime.tar.gz}
[[ -f "$archive.sha256" ]] || { echo 'Missing checksum file' >&2; exit 1; }
(cd "$(dirname "$archive")" && sha256sum -c "$(basename "$archive").sha256")
gzip -dc "$archive" | docker image load
docker image inspect qjw/traffic-vlm-jetson:20261023 --format '{{.Id}} {{.Architecture}}'
