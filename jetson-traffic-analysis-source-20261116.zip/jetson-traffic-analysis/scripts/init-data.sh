#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ ! -f .env ]]; then cp .env.example .env; chmod 600 .env; fi
python3 - <<'PYTHON'
from pathlib import Path
values={}
for line in Path('.env').read_text().splitlines():
    if line.strip() and not line.lstrip().startswith('#') and '=' in line:
        key,value=line.split('=',1);values[key.strip()]=value.strip().strip('"').strip("'")
p=Path(values.get('TRAFFIC_DATA_DIR','./data')).expanduser()
for child in ['traffic','engines','secrets','tmp','config','cache']:(p/child).mkdir(parents=True,exist_ok=True)
(p/'secrets').chmod(0o700)
print('Data directory:',p.resolve())
PYTHON
