#!/usr/bin/env bash
# Run on the OLD Jetson. Choose a mounted external disk with at least 30 GB free.
set -euo pipefail
image=${TRAFFIC_IMAGE:-qjw/traffic-vlm-jetson:20261023}
output=${1:?Usage: sudo bash scripts/export-runtime.sh /media/USER/DISK/traffic-runtime.tar.gz}
[[ ! -e "$output" && ! -e "$output.partial" ]] || { echo 'Output already exists; choose a new name.' >&2; exit 1; }
size=$(docker image inspect "$image" --format '{{.Size}}')
python3 - "$output" "$size" <<'PYTHON'
import sys,shutil
from pathlib import Path
p=Path(sys.argv[1]).expanduser();p.parent.mkdir(parents=True,exist_ok=True)
required=int(sys.argv[2])+2*1024**3
if shutil.disk_usage(p.parent).free<required:raise SystemExit('Not enough free space: use an external disk with at least 30 GB free.')
PYTHON
trap 'rm -f -- "$output.partial"' EXIT
docker image save "$image" | gzip -1 > "$output.partial"
mv -- "$output.partial" "$output"
(cd "$(dirname "$output")" && sha256sum "$(basename "$output")" > "$(basename "$output").sha256")
trap - EXIT
echo "Exported $output"
