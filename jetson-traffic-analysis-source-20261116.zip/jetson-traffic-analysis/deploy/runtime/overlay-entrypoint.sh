#!/usr/bin/env bash
set -euo pipefail
project=/opt/qjw/traffic_vlm/work/traffic-vlm-jetson
# Merge the current application over the image. Keep image-supplied weights/vendor libraries.
cp -a /opt/migration-src/. "$project/"
cp -a /opt/migration-runtime/bin/. /opt/qjw/bin/
chmod +x /opt/qjw/bin/*.sh
cp /opt/migration-runtime/env.sh /opt/qjw/env.sh
cp -a /opt/migration-runtime/config/. /opt/qjw/config/
source /opt/qjw/env.sh
export PYTHONPATH="$project/.vendor:$project${PYTHONPATH:+:$PYTHONPATH}"
exec /opt/qjw/bin/entrypoint.sh "$@"
